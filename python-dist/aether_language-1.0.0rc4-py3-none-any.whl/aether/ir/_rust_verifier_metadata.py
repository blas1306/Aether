# Generated from compiler-rs/Cargo.toml by setup.py; do not edit.
RUST_VERIFIER_PACKAGE_VERSION = '0.1.0'
