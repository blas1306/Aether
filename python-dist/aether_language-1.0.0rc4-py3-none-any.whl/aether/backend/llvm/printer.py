from __future__ import annotations

from dataclasses import dataclass, fields, is_dataclass
import re
import struct
from typing import Any, Callable

from aether.ir.model import (
    IREnumConstant,
    IRErasedBoxLayout,
    IRWitnessMethodSlot,
    IRWitnessTable,
)
from aether.interface_abi import (
    box_type_symbol,
    copy_owned_symbol,
    dispatch_thunk_symbol,
    drop_owned_symbol,
    interface_type_symbol,
    witness_symbol,
)
from aether.integer_arithmetic import INT_MAX, INT_MIN, is_aether_int
from aether.string_value import STRING_SPLIT_BUILTIN, STRING_TRIM_BUILTIN
from aether.ir.types import ArrayType, BoolType, ClassRefType, DoubleType, EnumType, ExceptionEventType, FloatType, FunctionType, IntType, InterfaceType, ListType, MatrixType, MethodResultType, NullableType, StringType, StructType, VectorType, VoidType
from aether.ir.erased_layout import align_up, erased_size_alignment
from aether.ssa.model import (
    SSAArrayCopy,
    SSAArrayGet,
    SSAArrayLength,
    SSAArrayNew,
    SSAArraySlice,
    SSAArraySet,
    SSABasicBlock,
    SSABinaryOp,
    SSABranch,
    SSACast,
    SSACall,
    SSACallIndirect,
    SSAClassGet,
    SSAClassNew,
    SSAClassSet,
    SSAInterfaceCall,
    SSAInterfaceConstruct,
    SSAInvoke,
    SSAInvokeIndirect,
    SSAInvokeInterface,
    SSACompareOp,
    SSAConst,
    SSAFunction,
    SSAFunctionRef,
    SSAInstruction,
    SSAJump,
    SSAListGet,
    SSAListCopy,
    SSAListSlice,
    SSAListContains,
    SSAListClear,
    SSAListPop,
    SSAListPush,
    SSAListInsert,
    SSAListRemoveAt,
    SSAListIndexOf,
    SSAListIsEmpty,
    SSAListLength,
    SSAListNew,
    SSAListSet,
    SSAListReverse,
    SSASequenceSort,
    SSAMatrixColumns,
    SSAMatrixAdd,
    SSAMatrixMatMul,
    SSAMatrixVectorMul,
    SSAMatrixScale,
    SSAMatrixSub,
    SSAMatrixGet,
    SSAMatrixNew,
    SSAMatrixRows,
    SSAMatrixSet,
    SSAModule,
    SSAOuterProduct,
    SSAPackException,
    SSAParameter,
    SSAPrint,
    SSAStructGet,
    SSAStructNew,
    SSAStructSet,
    SSAMethodResultNew,
    SSAMethodResultReceiver,
    SSAMethodResultValue,
    SSAPhi,
    SSAPropagate,
    SSARethrow,
    SSAReturn,
    SSACatchEntry,
    SSAExceptionDestroy,
    SSAExceptionMatch,
    SSAExceptionPayload,
    SSAThrow,
    SSAUnaryOp,
    SSAValue,
    SSAVectorGet,
    SSAVectorAdd,
    SSAVectorDot,
    SSAVectorMatrixMul,
    SSAVectorScale,
    SSAVectorSub,
    SSAVectorLength,
    SSAVectorNew,
    SSAVectorSet,
)

from .types import LLVMBackendError, llvm_type
from .layout import LLVMTypeLayouts
from .array_runtime import LLVMArrayRuntime
from .io_runtime import LLVMRuntimeIO
from .integer_runtime import LLVMIntegerRuntime
from .list_runtime import (
    LLVMListRuntime,
    list_contains_helper_name,
    list_index_of_helper_name,
)
from .matrix_runtime import LLVMMatrixRuntime
from .runtime import sequence_sort_helper_name
from .runtime_common import LLVMRuntimeCommon, aggregate_helper_suffix
from .scalar_math_runtime import LLVMScalarMathRuntime
from .vector_runtime import LLVMVectorRuntime
from .string_runtime import LLVMStringRuntime
from .class_runtime import class_new_helper, class_object_type, class_runtime_sections
from .process_runtime import LLVMProcessRuntime
from .text_file_runtime import LLVMTextFileRuntime
from .exception_abi import (
    EXCEPTION_RUNTIME_ABI_VERSION,
    ExceptionLoweringStrategy,
    exception_descriptor_symbol,
)
from .exception_runtime import LLVMExceptionRuntime
from aether.process_arguments import PROCESS_ARGS_BUILTIN
from aether.range_safety import (
    RANGE_STEP_NONZERO_BUILTIN,
    RANGE_STEP_ZERO_MESSAGE,
)
from aether.text_file_io import (
    APPEND_TEXT_BUILTIN,
    FILE_READ_RESULT_TYPE,
    FILE_STATUS_TYPE,
    READ_TEXT_BUILTIN,
    WRITE_TEXT_ATOMIC_BUILTIN,
    WRITE_TEXT_BUILTIN,
)
from aether.text_codec import (
    TEXT_BYTE_AT_BUILTIN,
    TEXT_BYTE_SLICE_BUILTIN,
    TEXT_CONCAT_FRAGMENTS_BUILTIN,
    TEXT_FORMAT_DOUBLE_BUILTIN,
    TEXT_FORMAT_INT_BUILTIN,
    TEXT_CODEC_BUILTINS,
)


@dataclass(frozen=True)
class _StringGlobal:
    name: str
    byte_length: int
    payload_size: int
    initializer: str


class LLVMPrinter:
    """Emit textual LLVM IR for the first minimal SSA subset."""

    _INT_BINARY_OPERATORS = {
        "add": "add",
        "sub": "sub",
        "mul": "mul",
        "div": "sdiv",
        "mod": "srem",
        "rem": "srem",
        "pow": None,
    }
    _DOUBLE_BINARY_OPERATORS = {
        "add": "fadd",
        "sub": "fsub",
        "mul": "fmul",
        "div": "fdiv",
        "rem": "frem",
    }
    _INT_COMPARE_OPERATORS = {
        "lt": "slt",
        "le": "sle",
        "gt": "sgt",
        "ge": "sge",
        "eq": "eq",
        "ne": "ne",
    }
    _DOUBLE_COMPARE_OPERATORS = {
        "lt": "olt",
        "le": "ole",
        "gt": "ogt",
        "ge": "oge",
        "eq": "oeq",
        "ne": "une",
    }
    _IDENTIFIER_RE = re.compile(r"^[A-Za-z_$._][A-Za-z0-9_$._-]*$")
    _LIST_STRUCT_TYPE = "%AetherList"

    def __init__(
        self,
        *,
        exception_runtime_abi_version: int = EXCEPTION_RUNTIME_ABI_VERSION,
        exception_strategy: ExceptionLoweringStrategy | str = ExceptionLoweringStrategy.EVENT_OUT,
        allow_test_exception_strategy: bool = False,
    ) -> None:
        if exception_runtime_abi_version != EXCEPTION_RUNTIME_ABI_VERSION:
            raise LLVMBackendError(
                "LLVM private exception runtime ABI mismatch: "
                f"compiler requires v{EXCEPTION_RUNTIME_ABI_VERSION}, "
                f"requested v{exception_runtime_abi_version}"
            )
        self._exception_runtime_abi_version = exception_runtime_abi_version
        try:
            self._exception_strategy = ExceptionLoweringStrategy(exception_strategy)
        except ValueError as exc:
            raise LLVMBackendError(
                f"LLVM unsupported exception lowering strategy '{exception_strategy}'"
            ) from exc
        if (
            self._exception_strategy
            is ExceptionLoweringStrategy.LLVM_EH_PROTOTYPE
            and not allow_test_exception_strategy
        ):
            raise LLVMBackendError(
                "LLVM EH exception lowering is an internal test-only prototype"
            )

    @property
    def exception_runtime_abi_version(self) -> int:
        return self._exception_runtime_abi_version

    @property
    def exception_strategy(self) -> ExceptionLoweringStrategy:
        return self._exception_strategy

    def print_module(self, module: SSAModule, *, native_entry: bool = False) -> str:
        self._native_entry = native_entry
        self._entry_symbol = "__aether_program_main"
        occupied_symbols = {function.name for function in module.functions if function.name != "main"}
        while self._entry_symbol in occupied_symbols:
            self._entry_symbol += "_entry"
        self._string_globals_by_value: dict[str, _StringGlobal] = {}
        self._next_string_global = 0
        self._uses_array_type = False
        self._uses_array_allocation = False
        self._uses_array_indexing = False
        self._uses_array_slicing = False
        self._uses_array_length_conversion = False
        self._uses_vector_indexing = False
        self._uses_matrix_indexing = False
        self._vector_equality_types: set[object] = set()
        self._matrix_equality_types: set[object] = set()
        self._vector_print_types: set[object] = set()
        self._matrix_print_types: set[object] = set()
        self._uses_list_type = False
        self._uses_list_allocation = False
        self._uses_list_push = False
        self._uses_list_insert = False
        self._uses_list_pop = False
        self._uses_list_remove_at = False
        self._uses_list_reverse = False
        self._uses_list_indexing = False
        self._uses_list_slicing = False
        self._uses_list_length_conversion = False
        self._sequence_sort_types: set[object] = set()
        self._list_contains_types: set[object] = set()
        self._list_index_of_types: set[object] = set()
        self._uses_print = False
        self._uses_string_runtime = native_entry
        self._uses_process_context = native_entry
        self._uses_process_arguments = False
        self._uses_range_step_guard = False
        self._uses_string_parsing = False
        self._uses_string_split = False
        self._uses_text_codec = False
        self._uses_text_file_io = False
        self._checked_int_operators: set[str] = set()
        self._uses_double_pow = False
        self._scalar_math_calls: set[tuple[str, tuple[object, ...], object]] = set()
        self._structs = {definition.name: definition for definition in module.structs}
        self._functions_by_name = {
            function.name: function for function in module.functions
        }
        self._layouts = LLVMTypeLayouts(module.structs)
        self._struct_sequence_equality_types: set[tuple[str, object]] = set()
        self._eq_helper_types: set[object] = set()
        self._struct_sequence_print_types: set[tuple[str, object]] = set()
        self._collection_arc_helpers: set[tuple[str, object, bool]] = set()
        self._collection_object_arc_helpers: set[tuple[str, object, bool]] = set()
        self._collection_copy_helpers: set[tuple[str, object]] = set()
        self._nullable_print_types: set[NullableType] = set()
        self._nullable_arc_helpers: set[tuple[NullableType, bool]] = set()
        self._witnesses: dict[str, IRWitnessTable] = {}
        self._uses_interface_dispatch = False
        self._uses_interface_boxing = False
        self._uses_exceptions = any(
            isinstance(
                instruction,
                (
                    SSAInvoke,
                    SSAInvokeIndirect,
                    SSAInvokeInterface,
                    SSAPackException,
                    SSACatchEntry,
                    SSAExceptionMatch,
                    SSAExceptionPayload,
                    SSAExceptionDestroy,
                    SSAThrow,
                    SSARethrow,
                    SSAPropagate,
                ),
            )
            for function in module.functions
            for block in function.blocks
            for instruction in block.instructions
        )
        if self._uses_exceptions:
            self._uses_interface_dispatch = True
            self._uses_string_runtime = True
        self._exception_nominal_types = self._collect_exception_nominal_types(module)
        for nominal_id, concrete_type in sorted(
            self._exception_nominal_types.items()
        ):
            self._require_error_witness(nominal_id, concrete_type)
        # Discover reference layouts before deciding which common runtime
        # declarations are needed.  Some nested uses surface only while
        # recursively materializing aggregate helpers later in this method.
        class_types, embedded_array, embedded_list = (
            self._collect_embedded_reference_types(module)
        )
        self._uses_array_type |= embedded_array
        self._uses_list_type |= embedded_list
        self._class_types: set[ClassRefType] = set(class_types)
        self._class_alloc_types: set[ClassRefType] = set()

        functions = [self._print_function(function) for function in module.functions]
        self._register_class_payload_lifecycle()
        nullable_types = [
            f"{llvm_type(type_)} = type {{ i1, {llvm_type(type_.inner)} }}"
            for type_ in self._collect_nullable_types(module)
        ]
        interface_types = [
            f"{interface_type_symbol(type_.name)} = type {{ ptr, ptr }}"
            for type_ in self._collect_interface_types(module)
        ]
        struct_types = [
            f"%struct.{definition.name} = type {{ "
            + ", ".join(llvm_type(type_) for _name, type_ in definition.fields)
            + " }"
            for definition in module.structs
        ]
        # Ownership adapters may discover nested ARC helpers and class
        # descriptors.  Materialize them before freezing runtime requirements.
        witness_globals = self._print_witness_metadata()
        exception_descriptors = self._print_exception_descriptors()
        array_runtime = LLVMArrayRuntime(
            uses_type=self._uses_array_type,
            uses_allocation=self._uses_array_allocation,
            uses_indexing=self._uses_array_indexing,
            uses_slicing=self._uses_array_slicing,
            uses_length_conversion=self._uses_array_length_conversion,
        )
        list_runtime = LLVMListRuntime(
            _uses_list_type=self._uses_list_type,
            _uses_list_allocation=self._uses_list_allocation,
            _uses_list_push=self._uses_list_push,
            _uses_list_insert=self._uses_list_insert,
            _uses_list_pop=self._uses_list_pop,
            _uses_list_remove_at=self._uses_list_remove_at,
            _uses_list_reverse=self._uses_list_reverse,
            _uses_list_indexing=self._uses_list_indexing,
            _uses_list_slicing=self._uses_list_slicing,
            _uses_list_length_conversion=self._uses_list_length_conversion,
            _sequence_sort_types=frozenset(self._sequence_sort_types),
            _list_contains_types=frozenset(self._list_contains_types),
            _list_index_of_types=frozenset(self._list_index_of_types),
        )
        uses_list_growth = self._uses_list_push or self._uses_list_insert
        uses_allocation = bool(
            self._uses_array_allocation
            or self._class_alloc_types
            or self._uses_list_allocation
            or self._uses_array_slicing
            or self._uses_list_slicing
            or uses_list_growth
            or self._sequence_sort_types
            or self._uses_interface_boxing
            or self._uses_exceptions
        )
        common_runtime = LLVMRuntimeCommon(
            uses_allocation=uses_allocation,
            uses_checked_allocation_size=bool(
                self._uses_array_allocation
                or self._uses_list_allocation
                or self._uses_array_slicing
                or self._uses_list_slicing
                or self._sequence_sort_types
            ),
            uses_panic=bool(
                uses_allocation
                or self._class_types
                or self._checked_int_operators
                or self._uses_array_indexing
                or self._uses_array_slicing
                or self._uses_list_slicing
                or self._uses_list_indexing
                or self._uses_list_pop
                or self._uses_list_remove_at
                or self._uses_array_length_conversion
                or self._uses_list_length_conversion
                or self._list_index_of_types
                or self._uses_vector_indexing
                or self._uses_matrix_indexing
                or any(
                    instruction.may_trap
                    for function in module.functions
                    for block in function.blocks
                    for instruction in block.instructions
                    if isinstance(instruction, SSACall) and instruction.builtin is not None
                )
                or bool(self._class_types)
                or bool(self._collection_object_arc_helpers)
                or self._uses_exceptions
            ),
            uses_free_and_memcpy=bool(
                self._class_types
                or self._sequence_sort_types
                or uses_list_growth
                or self._uses_array_slicing
                or self._uses_list_slicing
                or any(
                    not retain
                    for _kind, _element, retain in self._collection_object_arc_helpers
                )
                or self._uses_interface_boxing
                or self._uses_exceptions
            ),
            uses_memmove=self._uses_list_insert or self._uses_list_remove_at,
            sequence_sort_types=frozenset(self._sequence_sort_types),
        )
        runtime = list_runtime.declarations(common_runtime, array_runtime)
        if self._uses_range_step_guard:
            message_length = len(RANGE_STEP_ZERO_MESSAGE.encode("utf-8")) + 1
            runtime.append(
                f'@.aether.range.step.zero = private unnamed_addr constant [{message_length} x i8] '
                f'c"{RANGE_STEP_ZERO_MESSAGE}\\00"'
            )
            runtime.append(
                common_runtime.panic_helper(
                    "aether_range_step_zero_panic",
                    ".aether.range.step.zero",
                    message_length,
                )
            )
            runtime.append(
                "\n".join(
                    [
                        "define private void @aether_range_step_nonzero(i32 %step) {",
                        "entry:",
                        "  %is_zero = icmp eq i32 %step, 0",
                        "  br i1 %is_zero, label %panic, label %ok",
                        "panic:",
                        "  call void @aether_range_step_zero_panic()",
                        "  unreachable",
                        "ok:",
                        "  ret void",
                        "}",
                    ]
                )
            )
        for kind, element_type in sorted(
            self._collection_copy_helpers,
            key=lambda item: (item[0], str(item[1])),
        ):
            runtime.append(self._collection_copy_helper(kind, element_type))
        emitted_eq_helpers: set[object] = set()
        while pending_eq := self._eq_helper_types - emitted_eq_helpers:
            for type_ in sorted(pending_eq, key=str):
                runtime.append(self._equality_helper(type_))
                emitted_eq_helpers.add(type_)
        emitted_nullable_print: set[NullableType] = set()
        while pending_nullable_print := self._nullable_print_types - emitted_nullable_print:
            for type_ in sorted(pending_nullable_print, key=str):
                runtime.append(self._nullable_print_helper(type_))
                emitted_nullable_print.add(type_)
        emitted_nullable_arc: set[tuple[NullableType, bool]] = set()
        while pending_nullable_arc := self._nullable_arc_helpers - emitted_nullable_arc:
            for type_, retain in sorted(
                pending_nullable_arc,
                key=lambda item: (str(item[0]), item[1]),
            ):
                runtime.append(self._nullable_arc_helper(type_, retain=retain))
                emitted_nullable_arc.add((type_, retain))
        emitted_sequence_eq_types: set[tuple[str, object]] = set()
        while pending_sequence_eq := (
            self._struct_sequence_equality_types - emitted_sequence_eq_types
        ):
            for kind, element_type in sorted(
                pending_sequence_eq,
                key=lambda item: (item[0], str(item[1])),
            ):
                runtime.append(
                    self._struct_sequence_equality_helper(kind, element_type)
                )
                emitted_sequence_eq_types.add((kind, element_type))
        emitted_sequence_print_types: set[tuple[str, object]] = set()
        while pending := self._struct_sequence_print_types - emitted_sequence_print_types:
            for kind, element_type in sorted(
                pending,
                key=lambda item: (item[0], str(item[1])),
            ):
                runtime.append(self._struct_sequence_print_helper(kind, element_type))
                emitted_sequence_print_types.add((kind, element_type))
        emitted_arc_helpers: set[tuple[str, object, bool]] = set()
        while pending_arc := self._collection_arc_helpers - emitted_arc_helpers:
            for kind, element_type, retain in sorted(
                pending_arc,
                key=lambda item: (item[0], str(item[1]), item[2]),
            ):
                runtime.append(self._collection_arc_helper(kind, element_type, retain=retain))
                emitted_arc_helpers.add((kind, element_type, retain))
        if self._collection_object_arc_helpers:
            runtime.append(
                '@.aether.collection.rc = private unnamed_addr constant [49 x i8] '
                'c"Aether panic: invalid collection reference count\\00"'
            )
            runtime.append("\n".join([
                "define private void @aether_collection_rc_panic() noreturn {",
                "entry:",
                "  %message = getelementptr [49 x i8], ptr @.aether.collection.rc, i64 0, i64 0",
                "  call i32 @puts(ptr %message)",
                "  call void @exit(i32 1)",
                "  unreachable",
                "}",
            ]))
        emitted_object_arc: set[tuple[str, object, bool]] = set()
        while pending_object_arc := self._collection_object_arc_helpers - emitted_object_arc:
            for kind, element_type, retain in sorted(
                pending_object_arc,
                key=lambda item: (item[0], str(item[1]), item[2]),
            ):
                runtime.append(
                    self._collection_object_arc_helper(kind, element_type, retain=retain)
                )
                emitted_object_arc.add((kind, element_type, retain))
        # Aggregate helpers can recursively discover one another.  Reach a
        # fixed point so, for example, printing List<int?> emits both the
        # sequence helper and the nullable element helper regardless of which
        # one was discovered first.
        while True:
            pending_eq = self._eq_helper_types - emitted_eq_helpers
            pending_sequence_eq = (
                self._struct_sequence_equality_types - emitted_sequence_eq_types
            )
            pending_nullable_print = (
                self._nullable_print_types - emitted_nullable_print
            )
            pending_sequence_print = (
                self._struct_sequence_print_types - emitted_sequence_print_types
            )
            pending_nullable_arc = (
                self._nullable_arc_helpers - emitted_nullable_arc
            )
            pending_arc = self._collection_arc_helpers - emitted_arc_helpers
            pending_object_arc = (
                self._collection_object_arc_helpers - emitted_object_arc
            )
            if not any(
                (
                    pending_eq,
                    pending_sequence_eq,
                    pending_nullable_print,
                    pending_sequence_print,
                    pending_nullable_arc,
                    pending_arc,
                    pending_object_arc,
                )
            ):
                break
            for type_ in sorted(pending_eq, key=str):
                runtime.append(self._equality_helper(type_))
                emitted_eq_helpers.add(type_)
            for kind, element_type in sorted(
                pending_sequence_eq,
                key=lambda item: (item[0], str(item[1])),
            ):
                runtime.append(
                    self._struct_sequence_equality_helper(kind, element_type)
                )
                emitted_sequence_eq_types.add((kind, element_type))
            for type_ in sorted(pending_nullable_print, key=str):
                runtime.append(self._nullable_print_helper(type_))
                emitted_nullable_print.add(type_)
            for kind, element_type in sorted(
                pending_sequence_print,
                key=lambda item: (item[0], str(item[1])),
            ):
                runtime.append(self._struct_sequence_print_helper(kind, element_type))
                emitted_sequence_print_types.add((kind, element_type))
            for type_, retain in sorted(
                pending_nullable_arc,
                key=lambda item: (str(item[0]), item[1]),
            ):
                runtime.append(self._nullable_arc_helper(type_, retain=retain))
                emitted_nullable_arc.add((type_, retain))
            for kind, element_type, retain in sorted(
                pending_arc,
                key=lambda item: (item[0], str(item[1]), item[2]),
            ):
                runtime.append(
                    self._collection_arc_helper(kind, element_type, retain=retain)
                )
                emitted_arc_helpers.add((kind, element_type, retain))
            for kind, element_type, retain in sorted(
                pending_object_arc,
                key=lambda item: (item[0], str(item[1]), item[2]),
            ):
                runtime.append(
                    self._collection_object_arc_helper(
                        kind, element_type, retain=retain
                    )
                )
                emitted_object_arc.add((kind, element_type, retain))
        LLVMVectorRuntime(
            self._uses_vector_indexing,
            frozenset(self._vector_equality_types),
            frozenset(self._vector_print_types),
        ).append(runtime, common_runtime)
        LLVMMatrixRuntime(
            self._uses_matrix_indexing,
            frozenset(self._matrix_equality_types),
            frozenset(self._matrix_print_types),
        ).append(runtime, common_runtime)
        if self._uses_double_pow:
            common_runtime.declare(runtime, "declare double @pow(double, double)")
        LLVMIntegerRuntime(frozenset(self._checked_int_operators)).append(runtime, common_runtime)
        LLVMScalarMathRuntime(frozenset(self._scalar_math_calls)).append(runtime, common_runtime)
        LLVMRuntimeIO(enabled=self._uses_print).append(runtime)
        LLVMStringRuntime(
            enabled=self._uses_string_runtime,
            parsing=self._uses_string_parsing,
            splitting=self._uses_string_split,
            codec=self._uses_text_codec,
        ).append(runtime)
        LLVMTextFileRuntime(self._uses_text_file_io).append(runtime)
        LLVMExceptionRuntime(self._uses_exceptions, self._exception_strategy).append(runtime)
        LLVMProcessRuntime(
            self._uses_process_context or self._uses_process_arguments,
            snapshots=self._uses_process_arguments,
        ).append(runtime)
        runtime.extend(
            class_runtime_sections(
                self._class_types,
                self._class_alloc_types,
                self._structs,
                self._emit_class_destroy_value,
            )
        )
        globals_ = [
            rendered
            for global_ in self._string_globals_by_value.values()
            if (rendered := self._print_string_global(global_))
        ]
        # Named aggregate bodies must precede every helper that performs a
        # typed GEP/load.  This also makes collection layout independent of
        # which user function happened to mention a struct first.
        wrappers = (
            [LLVMProcessRuntime.entry_wrapper(self._entry_symbol)]
            if native_entry
            else []
        )
        sections = (
            interface_types
            + nullable_types
            + struct_types
            + witness_globals
            + exception_descriptors
            + runtime
            + globals_
            + functions
            + wrappers
        )
        return "\n\n".join(sections)

    def _collect_exception_nominal_types(
        self,
        module: SSAModule,
    ) -> dict[str, StructType | ClassRefType]:
        """Resolve every concrete Error identity required by native lowering."""

        found: dict[str, StructType | ClassRefType] = {}

        def register(name: str, type_: object) -> None:
            if not isinstance(type_, (StructType, ClassRefType)):
                raise LLVMBackendError(
                    f"LLVM exception descriptor '{name}' has no concrete nominal type"
                )
            if type_.name != name:
                raise LLVMBackendError(
                    f"LLVM malformed exception descriptor identity: '{name}' "
                    f"does not match payload type '{type_.name}'"
                )
            previous = found.get(name)
            if previous is not None and previous != type_:
                raise LLVMBackendError(
                    f"LLVM exception nominal identity '{name}' is both class and struct"
                )
            found[name] = type_

        pending_catches: set[str] = set()
        for function in module.functions:
            for block in function.blocks:
                for instruction in block.instructions:
                    if isinstance(instruction, SSAPackException):
                        if isinstance(instruction.payload.type, InterfaceType):
                            if (
                                instruction.payload.type.name != "Error"
                                or instruction.dynamic_type is not None
                            ):
                                raise LLVMBackendError(
                                    "LLVM exception_pack interface payload must be dynamic Error"
                                )
                        else:
                            if instruction.dynamic_type is None:
                                raise LLVMBackendError(
                                    "LLVM concrete exception_pack requires a canonical descriptor"
                                )
                            register(instruction.dynamic_type, instruction.payload.type)
                    elif isinstance(instruction, SSAExceptionPayload):
                        if instruction.catch_type == "Error":
                            if instruction.result.type != InterfaceType("Error"):
                                raise LLVMBackendError(
                                    "LLVM Error catch payload must use interface Error"
                                )
                        else:
                            register(instruction.catch_type, instruction.result.type)
                    elif isinstance(instruction, SSAExceptionMatch):
                        if not instruction.catch_all:
                            pending_catches.add(instruction.catch_type)

        for name in sorted(pending_catches - found.keys()):
            target = self._functions_by_name.get(f"{name}.message")
            if target is None or not target.parameters:
                raise LLVMBackendError(
                    f"LLVM catch descriptor '{name}' has no canonical Error witness"
                )
            register(name, target.parameters[0].type)
        return found

    def _require_error_witness(
        self,
        nominal_id: str,
        concrete_type: StructType | ClassRefType,
    ) -> IRWitnessTable:
        symbol = witness_symbol("Error", nominal_id)
        existing = self._witnesses.get(symbol)
        if existing is not None:
            if existing.concrete_type_id != nominal_id or existing.interface_id != "Error":
                raise LLVMBackendError(
                    f"LLVM canonical Error witness collision for '{nominal_id}'"
                )
            return existing

        target = self._functions_by_name.get(f"{nominal_id}.message")
        expected_return: object = StringType()
        if isinstance(concrete_type, StructType):
            expected_return = MethodResultType(concrete_type, StringType())
        if (
            target is None
            or tuple(parameter.type for parameter in target.parameters) != (concrete_type,)
            or target.return_type != expected_return
        ):
            raise LLVMBackendError(
                f"LLVM Error witness target '{nominal_id}.message' has an incompatible signature"
            )
        if target.may_throw:
            raise LLVMBackendError(
                f"LLVM Error witness target '{nominal_id}.message' violates the "
                "non-throwing Error.message() contract"
            )

        box_layout = None
        carrier_kind = "class"
        if isinstance(concrete_type, StructType):
            payload_size, payload_alignment = erased_size_alignment(
                concrete_type,
                self._structs,
            )
            payload_offset = align_up(16, payload_alignment)
            carrier_kind = "box"
            box_layout = IRErasedBoxLayout(
                payload_size,
                payload_alignment,
                payload_offset,
                "owned_value",
                copy_owned_symbol("Error", nominal_id),
                drop_owned_symbol("Error", nominal_id),
            )
        slot = IRWitnessMethodSlot(
            0,
            "Error.message",
            (),
            StringType(),
            dispatch_thunk_symbol("Error", nominal_id, 0, "Error.message"),
        )
        witness = IRWitnessTable(
            symbol,
            "Error",
            nominal_id,
            carrier_kind,
            (slot,),
            1,
            box_layout,
        )
        self._witnesses[symbol] = witness
        return witness

    def _print_exception_descriptors(self) -> list[str]:
        if not self._uses_exceptions:
            return []
        sections: list[str] = [
            "%AetherExceptionDescriptorV1 = type { i64, ptr, ptr }",
            "%AetherExceptionEventV1 = type { i64, i32, i32, ptr, ptr, i32, i32 }",
        ]
        for nominal_id, concrete_type in sorted(self._exception_nominal_types.items()):
            witness = self._require_error_witness(nominal_id, concrete_type)
            encoded = nominal_id.encode("utf-8") + b"\0"
            descriptor = exception_descriptor_symbol(nominal_id)
            sections.extend(
                [
                    f"@{descriptor}.name = private unnamed_addr constant "
                    f"[{len(encoded)} x i8] c\"{self._escape_string_initializer(encoded)}\"",
                    f"@{descriptor} = private constant %AetherExceptionDescriptorV1 "
                    f"{{ i64 {EXCEPTION_RUNTIME_ABI_VERSION}, "
                    f"ptr getelementptr ([{len(encoded)} x i8], "
                    f"ptr @{descriptor}.name, i64 0, i64 0), "
                    f"ptr @{witness.symbol} }}",
                ]
            )
        return sections

    @staticmethod
    def _collect_nullable_types(module: SSAModule) -> list[NullableType]:
        """Collect every named nullable body required by an SSA module."""

        found: set[NullableType] = set()
        visited: set[int] = set()

        def visit(value: object) -> None:
            if isinstance(value, NullableType):
                found.add(value)
                visit(value.inner)
                return
            if value is None or isinstance(value, (str, bytes, int, float, bool)):
                return
            if isinstance(value, dict):
                for key, item in value.items():
                    visit(key)
                    visit(item)
                return
            if isinstance(value, (list, tuple, set, frozenset)):
                for item in value:
                    visit(item)
                return
            if not is_dataclass(value):
                return
            identity = id(value)
            if identity in visited:
                return
            visited.add(identity)
            for field in fields(value):
                visit(getattr(value, field.name))

        visit(module)
        return sorted(found, key=str)

    @staticmethod
    def _collect_interface_types(module: SSAModule) -> list[InterfaceType]:
        """Collect every named two-word interface body required by a module."""

        found: set[InterfaceType] = set()
        visited: set[int] = set()

        def visit(value: object) -> None:
            if isinstance(value, InterfaceType):
                found.add(value)
                return
            if value is None or isinstance(value, (str, bytes, int, float, bool)):
                return
            if isinstance(value, dict):
                for key, item in value.items():
                    visit(key)
                    visit(item)
                return
            if isinstance(value, (list, tuple, set, frozenset)):
                for item in value:
                    visit(item)
                return
            if not is_dataclass(value):
                return
            identity = id(value)
            if identity in visited:
                return
            visited.add(identity)
            for field in fields(value):
                visit(getattr(value, field.name))

        visit(module)
        return sorted(found, key=str)

    @staticmethod
    def _collect_embedded_reference_types(
        module: SSAModule,
    ) -> tuple[list[ClassRefType], bool, bool]:
        """Collect handles that may be discovered late by aggregate helpers."""

        found: set[ClassRefType] = set()
        has_array = False
        has_list = False
        visited: set[int] = set()

        def visit(value: object) -> None:
            nonlocal has_array, has_list
            if isinstance(value, ClassRefType):
                found.add(value)
                return
            if isinstance(value, ArrayType):
                has_array = True
            elif isinstance(value, ListType):
                has_list = True
            if value is None or isinstance(value, (str, bytes, int, float, bool)):
                return
            if isinstance(value, dict):
                for key, item in value.items():
                    visit(key)
                    visit(item)
                return
            if isinstance(value, (list, tuple, set, frozenset)):
                for item in value:
                    visit(item)
                return
            if not is_dataclass(value):
                return
            identity = id(value)
            if identity in visited:
                return
            visited.add(identity)
            for field in fields(value):
                visit(getattr(value, field.name))

        visit(module)
        return sorted(found, key=str), has_array, has_list

    def _print_function(self, function: SSAFunction) -> str:
        self._current_function = function
        self._current_block = ""
        self._constants: dict[str, str] = {}
        self._function_references: dict[str, str] = {}
        self._function_reference_targets: dict[str, str] = {}
        self._values: dict[str, str] = {
            self._key(parameter): self._parameter_name(parameter)
            for parameter in function.parameters
        }
        self._next_temp = 0
        self._next_synthetic_temp = 0
        self._exception_predecessors: dict[str, list[tuple[str, SSAValue]]] = {
            block.name: [] for block in function.blocks
        }
        self._eh_trampoline_by_block: dict[str, str] = {}
        if self._exception_strategy is ExceptionLoweringStrategy.LLVM_EH_PROTOTYPE:
            self._eh_trampoline_by_block = {
                block.name: f"__ae.eh.{index}"
                for index, block in enumerate(function.blocks)
                if isinstance(
                    block.instructions[-1],
                    (SSAInvoke, SSAInvokeIndirect, SSAInvokeInterface),
                )
            }
        for predecessor in function.blocks:
            terminator = predecessor.instructions[-1]
            if isinstance(terminator, (SSAInvoke, SSAInvokeIndirect, SSAInvokeInterface)):
                if terminator.exceptional_arguments != (terminator.exception,):
                    raise LLVMBackendError(
                        "LLVM invoke exceptional edge must move exactly its event"
                    )
                self._exception_predecessors[terminator.exceptional_target].append(
                    (
                        self._eh_trampoline_by_block.get(
                            predecessor.name, predecessor.name
                        )
                        + (
                            ".caught"
                            if predecessor.name in self._eh_trampoline_by_block
                            else ""
                        ),
                        terminator.exception,
                    )
                )
            elif isinstance(terminator, (SSAThrow, SSARethrow, SSAPropagate)):
                if terminator.target is not None:
                    if terminator.exceptional_arguments != (terminator.event,):
                        raise LLVMBackendError(
                            "LLVM exceptional transfer must move exactly its event"
                        )
                    self._exception_predecessors[terminator.target].append(
                        (predecessor.name, terminator.event)
                    )
        self._collect_function_values(function)
        self._exception_pack_copy_required = self._find_exception_pack_copies(
            function
        )

        return_type = llvm_type(function.return_type)
        rendered_parameters = [
            f"{llvm_type(parameter.type)} {self._parameter_name(parameter)}"
            for parameter in function.parameters
        ]
        if self._function_uses_exception_out(function):
            rendered_parameters.append("ptr %__ae_exception_out")
        parameters = ", ".join(rendered_parameters)
        linkage = (
            "private "
            if function.name.startswith("__ae_m")
            or (function.may_throw and function.name != "main")
            else ""
        )
        personality = (
            " personality ptr @__gxx_personality_v0"
            if self._exception_strategy
            is ExceptionLoweringStrategy.LLVM_EH_PROTOTYPE
            and function.may_throw
            else ""
        )
        error_message_attribute = (
            " nounwind"
            if function.name.endswith(".message")
            and function.name.rsplit(".", 1)[0] in self._exception_nominal_types
            else ""
        )
        lines = [
            f"define {linkage}{return_type} {self._global_name(function.name)}"
            f"({parameters}){personality}{error_message_attribute} {{"
        ]

        for block in function.blocks:
            lines.extend(self._print_block(block, function))
            terminator = block.instructions[-1]
            if (
                block.name in self._eh_trampoline_by_block
                and isinstance(
                    terminator,
                    (SSAInvoke, SSAInvokeIndirect, SSAInvokeInterface),
                )
            ):
                lines.extend(
                    self._print_eh_trampoline(
                        self._eh_trampoline_by_block[block.name],
                        terminator.exception,
                        terminator.exceptional_target,
                    )
                )

        lines.append("}")
        return "\n".join(lines)

    def _find_exception_pack_copies(self, function: SSAFunction) -> set[str]:
        """Find payload owners that remain live after an exception pack.

        Initial IR permits pack to move a temporary or copy a still-live
        owner.  SSA makes the distinction observable through later uses on the
        exceptional continuation.  The native box must acquire ARC ownership
        only in the latter case.
        """

        blocks = {block.name: block for block in function.blocks}
        successors: dict[str, tuple[str, ...]] = {}
        for block in function.blocks:
            terminator = block.instructions[-1]
            if isinstance(terminator, SSAJump):
                successors[block.name] = (terminator.target,)
            elif isinstance(terminator, SSABranch):
                successors[block.name] = (
                    terminator.true_target,
                    terminator.false_target,
                )
            elif isinstance(
                terminator,
                (SSAInvoke, SSAInvokeIndirect, SSAInvokeInterface),
            ):
                successors[block.name] = (
                    terminator.normal_target,
                    terminator.exceptional_target,
                )
            elif isinstance(terminator, (SSAThrow, SSARethrow, SSAPropagate)):
                successors[block.name] = (
                    () if terminator.target is None else (terminator.target,)
                )
            else:
                successors[block.name] = ()

        copies: set[str] = set()
        for block in function.blocks:
            for index, instruction in enumerate(block.instructions):
                if not isinstance(instruction, SSAPackException):
                    continue
                key = self._key(instruction.payload)
                if any(
                    self._instruction_uses_value(item, key)
                    for item in block.instructions[index + 1 :]
                    if not isinstance(item, (SSAThrow, SSARethrow, SSAPropagate))
                ):
                    copies.add(key)
                    continue
                pending = list(successors[block.name])
                visited: set[str] = set()
                while pending:
                    name = pending.pop()
                    if name in visited:
                        continue
                    visited.add(name)
                    candidate = blocks[name]
                    if any(
                        self._instruction_uses_value(item, key)
                        for item in candidate.instructions
                    ):
                        copies.add(key)
                        break
                    pending.extend(successors[name])
        return copies

    def _instruction_uses_value(
        self,
        instruction: SSAInstruction,
        key: str,
    ) -> bool:
        def contains(value: object) -> bool:
            if isinstance(value, SSAValue):
                return self._key(value) == key
            if isinstance(value, (tuple, list)):
                return any(contains(item) for item in value)
            if is_dataclass(value):
                return any(contains(getattr(value, item.name)) for item in fields(value))
            return False

        for item in fields(instruction):
            if item.name == "result" or item.metadata.get("ir_definition", False):
                continue
            if contains(getattr(instruction, item.name)):
                return True
        return False

    def _print_eh_trampoline(
        self,
        label: str,
        event_value: SSAValue,
        exceptional_target: str,
    ) -> list[str]:
        """Extract our event and resume any foreign native exception."""

        landing = self._synthetic_temp("eh.landing")
        native_exception = self._synthetic_temp("eh.native.exception")
        selector = self._synthetic_temp("eh.selector")
        expected = self._synthetic_temp("eh.expected.selector")
        ours = self._synthetic_temp("eh.is.aether")
        caught = f"{label}.caught"
        foreign = f"{label}.foreign"
        wrapper = self._synthetic_temp("eh.wrapper")
        event = self._new_temp(event_value)
        return [
            self._label_definition(label),
            f"  {landing} = landingpad {{ ptr, i32 }} catch ptr @_ZTIPv",
            f"  {native_exception} = extractvalue {{ ptr, i32 }} {landing}, 0",
            f"  {selector} = extractvalue {{ ptr, i32 }} {landing}, 1",
            f"  {expected} = call i32 @llvm.eh.typeid.for(ptr @_ZTIPv)",
            f"  {ours} = icmp eq i32 {selector}, {expected}",
            f"  br i1 {ours}, {self._label_operand(caught)}, {self._label_operand(foreign)}",
            self._label_definition(caught),
            f"  {wrapper} = call ptr @__cxa_begin_catch(ptr {native_exception})",
            # For a C++ ``void*`` exception, begin_catch returns the pointer
            # value stored in the native wrapper, i.e. our opaque event.
            f"  {event} = getelementptr i8, ptr {wrapper}, i64 0",
            "  call void @__cxa_end_catch()",
            f"  br {self._label_operand(exceptional_target)}",
            self._label_definition(foreign),
            f"  resume {{ ptr, i32 }} {landing}",
        ]

    def _collect_function_values(self, function: SSAFunction) -> None:
        for block in function.blocks:
            for instruction in block.instructions:
                if isinstance(instruction, SSAConst):
                    self._record_const(instruction)
                    continue
                if isinstance(instruction, SSAFunctionRef):
                    self._function_references[self._key(instruction.result)] = self._global_name(
                        instruction.function
                    )
                    self._function_reference_targets[
                        self._key(instruction.result)
                    ] = instruction.function
                    continue

                if isinstance(instruction, (SSAInvoke, SSAInvokeIndirect, SSAInvokeInterface)):
                    if instruction.result is not None:
                        self._reserve_temp(instruction.result)
                    self._reserve_temp(instruction.exception)
                    continue
                if isinstance(instruction, SSACatchEntry):
                    self._reserve_temp(instruction.event)
                    continue

                result = self._instruction_result(instruction)
                if result is not None:
                    self._reserve_temp(result)

    def _print_block(self, block: SSABasicBlock, function: SSAFunction) -> list[str]:
        self._current_block = block.name
        lines = [self._label_definition(block.name)]
        for instruction in block.instructions:
            emitted = self._print_instruction(instruction, function)
            if emitted is not None:
                lines.append(f"  {emitted}")
        return lines

    def _print_instruction(
        self,
        instruction: SSAInstruction,
        function: SSAFunction,
    ) -> str | None:
        if isinstance(instruction, SSAConst):
            self._record_const(instruction)
            return None
        if isinstance(instruction, SSABinaryOp):
            return self._print_binary_op(instruction)
        if isinstance(instruction, SSAUnaryOp):
            return self._print_unary_op(instruction)
        if isinstance(instruction, SSACompareOp):
            return self._print_compare_op(instruction)
        if isinstance(instruction, SSACast):
            return self._print_cast(instruction)
        if isinstance(instruction, SSAInvoke):
            return "\n  ".join(self._print_direct_invoke(instruction))
        if isinstance(instruction, SSAInvokeIndirect):
            return "\n  ".join(self._print_indirect_invoke(instruction))
        if isinstance(instruction, SSAInvokeInterface):
            return "\n  ".join(self._print_interface_invoke(instruction))
        if isinstance(instruction, SSAPackException):
            return "\n  ".join(self._print_exception_pack(instruction))
        if isinstance(instruction, SSACatchEntry):
            return self._print_catch_entry(instruction)
        if isinstance(instruction, SSAExceptionMatch):
            return self._print_exception_match(instruction)
        if isinstance(instruction, SSAExceptionPayload):
            return "\n  ".join(self._print_exception_payload(instruction))
        if isinstance(instruction, SSAExceptionDestroy):
            return (
                "call void @__ae_exception_destroy_v1(ptr "
                f"{self._operand(instruction.event)})"
            )
        if isinstance(instruction, (SSAThrow, SSARethrow, SSAPropagate)):
            return self._print_exception_transfer(instruction, function)
        if isinstance(instruction, SSAReturn):
            return self._print_return(instruction, function)
        if isinstance(instruction, SSAPhi):
            return self._print_phi(instruction)
        if isinstance(instruction, SSABranch):
            return self._print_branch(instruction)
        if isinstance(instruction, SSAJump):
            return self._print_jump(instruction)
        if isinstance(instruction, SSACall):
            return self._print_call(instruction)
        if isinstance(instruction, SSAFunctionRef):
            self._function_references[self._key(instruction.result)] = self._global_name(
                instruction.function
            )
            self._function_reference_targets[
                self._key(instruction.result)
            ] = instruction.function
            return None
        if isinstance(instruction, SSACallIndirect):
            return self._print_indirect_call(instruction)
        if isinstance(instruction, SSAPrint):
            return self._print_print(instruction)
        if isinstance(instruction, SSAStructNew):
            return "\n  ".join(self._print_struct_new(instruction))
        if isinstance(instruction, SSAClassNew):
            if not isinstance(instruction.result.type, ClassRefType):
                raise LLVMBackendError(
                    "LLVM class_new requires a class reference result"
                )
            self._class_types.add(instruction.result.type)
            self._class_alloc_types.add(instruction.result.type)
            result = self._new_temp(instruction.result)
            return f"{result} = call ptr @{class_new_helper(instruction.result.type)}()"
        if isinstance(instruction, SSAClassGet):
            return "\n  ".join(self._print_class_get(instruction))
        if isinstance(instruction, SSAClassSet):
            return "\n  ".join(self._print_class_set(instruction))
        if isinstance(instruction, SSAInterfaceConstruct):
            return "\n  ".join(self._print_interface_construct(instruction))
        if isinstance(instruction, SSAInterfaceCall):
            return "\n  ".join(self._print_interface_call(instruction))
        if isinstance(instruction, SSAStructGet):
            return self._print_struct_get(instruction)
        if isinstance(instruction, SSAStructSet):
            return self._print_struct_set(instruction)
        if isinstance(instruction, SSAMethodResultNew):
            return "\n  ".join(self._print_method_result_new(instruction))
        if isinstance(instruction, SSAMethodResultReceiver):
            return self._print_method_result_receiver(instruction)
        if isinstance(instruction, SSAMethodResultValue):
            return self._print_method_result_value(instruction)
        if isinstance(instruction, SSAArrayNew):
            return self._print_array_new(instruction)
        if isinstance(instruction, SSAListNew):
            return self._print_list_new(instruction)
        if isinstance(instruction, SSAArrayCopy):
            return self._print_array_copy(instruction)
        if isinstance(instruction, SSAListCopy):
            return self._print_list_copy(instruction)
        if isinstance(instruction, SSAListContains):
            return self._print_list_contains(instruction)
        if isinstance(instruction, SSAListIndexOf):
            return self._print_list_index_of(instruction)
        if isinstance(instruction, SSAListClear):
            return self._print_list_clear(instruction)
        if isinstance(instruction, SSAListPush):
            return "\n  ".join(self._print_list_push(instruction))
        if isinstance(instruction, SSAListInsert):
            return "\n  ".join(self._print_list_insert(instruction))
        if isinstance(instruction, SSAListPop):
            return "\n  ".join(self._print_list_pop(instruction))
        if isinstance(instruction, SSAListRemoveAt):
            return "\n  ".join(self._print_list_remove_at(instruction))
        if isinstance(instruction, SSAListReverse):
            return self._print_list_reverse(instruction)
        if isinstance(instruction, SSASequenceSort):
            return self._print_sequence_sort(instruction)
        if isinstance(instruction, SSAVectorNew):
            return self._print_vector_new(instruction)
        if isinstance(instruction, SSAMatrixNew):
            return self._print_matrix_new(instruction)
        if isinstance(instruction, SSAVectorAdd):
            return "\n  ".join(self._print_vector_add(instruction))
        if isinstance(instruction, SSAVectorSub):
            return "\n  ".join(self._print_vector_sub(instruction))
        if isinstance(instruction, SSAVectorScale):
            return "\n  ".join(self._print_vector_scale(instruction))
        if isinstance(instruction, SSAVectorDot):
            return "\n".join(self._print_vector_dot(instruction))
        if isinstance(instruction, SSAOuterProduct):
            return "\n".join(self._print_outer_product(instruction))
        if isinstance(instruction, SSAMatrixAdd):
            return "\n  ".join(self._print_matrix_add(instruction))
        if isinstance(instruction, SSAMatrixSub):
            return "\n  ".join(self._print_matrix_sub(instruction))
        if isinstance(instruction, SSAMatrixScale):
            return "\n  ".join(self._print_matrix_scale(instruction))
        if isinstance(instruction, SSAMatrixMatMul):
            return "\n  ".join(self._print_matrix_matmul(instruction))
        if isinstance(instruction, SSAMatrixVectorMul):
            return "\n".join(self._print_matrix_vector_mul(instruction))
        if isinstance(instruction, SSAVectorMatrixMul):
            return "\n".join(self._print_vector_matrix_mul(instruction))
        if isinstance(instruction, SSAArrayGet):
            return "\n  ".join(self._print_array_get(instruction))
        if isinstance(instruction, SSAArraySlice):
            return self._print_array_slice(instruction)
        if isinstance(instruction, SSAListSlice):
            return self._print_list_slice(instruction)
        if isinstance(instruction, SSAListGet):
            return "\n  ".join(self._print_list_get(instruction))
        if isinstance(instruction, SSAVectorGet):
            return "\n  ".join(self._print_vector_get(instruction))
        if isinstance(instruction, SSAMatrixGet):
            return "\n  ".join(self._print_matrix_get(instruction))
        if isinstance(instruction, SSAVectorLength):
            return "\n  ".join(self._print_vector_length(instruction))
        if isinstance(instruction, SSAMatrixRows):
            return self._print_matrix_rows(instruction)
        if isinstance(instruction, SSAMatrixColumns):
            return self._print_matrix_columns(instruction)
        if isinstance(instruction, SSAArraySet):
            return "\n  ".join(self._print_array_set(instruction))
        if isinstance(instruction, SSAListSet):
            return "\n  ".join(self._print_list_set(instruction))
        if isinstance(instruction, SSAVectorSet):
            return "\n  ".join(self._print_vector_set(instruction))
        if isinstance(instruction, SSAMatrixSet):
            return "\n  ".join(self._print_matrix_set(instruction))
        if isinstance(instruction, SSAArrayLength):
            return "\n  ".join(self._print_array_length(instruction))
        if isinstance(instruction, SSAListLength):
            return "\n  ".join(self._print_list_length(instruction))
        if isinstance(instruction, SSAListIsEmpty):
            return "\n  ".join(self._print_list_is_empty(instruction))
        self._unsupported(type(instruction).__name__)

    def _record_const(self, instruction: SSAConst) -> None:
        llvm_type(instruction.result.type)
        self._constants[self._key(instruction.result)] = self._literal(
            instruction.value,
            instruction.result,
        )

    @staticmethod
    def _instruction_result(instruction: SSAInstruction) -> SSAValue | None:
        if isinstance(instruction, SSABinaryOp | SSAUnaryOp | SSACompareOp | SSACast | SSAPhi | SSAPackException | SSAExceptionMatch | SSAExceptionPayload):
            return instruction.result
        if isinstance(instruction, SSACall):
            return instruction.result
        if isinstance(instruction, SSAFunctionRef):
            return instruction.result
        if isinstance(instruction, SSACallIndirect):
            return instruction.result
        if isinstance(instruction, SSAInterfaceCall):
            return instruction.result
        if isinstance(
            instruction,
            (
                SSAArrayNew,
                SSAClassNew,
                SSAClassGet,
                SSAInterfaceConstruct,
                SSAArrayCopy,
                SSAArrayGet,
                SSAArraySlice,
                SSAListNew,
                SSAListGet,
                SSAListCopy,
                SSAListSlice,
                SSAListContains,
                SSAListIndexOf,
                SSAListPop,
                SSAListRemoveAt,
                SSAVectorGet,
                SSAMatrixGet,
                SSAArrayLength,
                SSAListLength,
                SSAListIsEmpty,
                SSAVectorLength,
                SSAMatrixRows,
                SSAMatrixColumns,
                SSAVectorNew,
                SSAMatrixNew,
                SSAVectorAdd,
                SSAVectorDot,
                SSAOuterProduct,
                SSAVectorScale,
                SSAMatrixAdd,
                SSAMatrixMatMul,
                SSAMatrixVectorMul,
                SSAVectorMatrixMul,
                SSAMatrixScale,
                SSAVectorSub,
                SSAMatrixSub,
                SSAStructNew,
                SSAStructGet,
                SSAStructSet,
                SSAMethodResultNew,
                SSAMethodResultReceiver,
                SSAMethodResultValue,
            ),
        ):
            return instruction.result
        return None

    def _print_binary_op(self, instruction: SSABinaryOp) -> str:
        if isinstance(instruction.left.type, StringType) or isinstance(
            instruction.right.type, StringType
        ):
            if not (
                instruction.operator == "add"
                and isinstance(instruction.left.type, StringType)
                and isinstance(instruction.right.type, StringType)
                and isinstance(instruction.result.type, StringType)
            ):
                raise LLVMBackendError("LLVM string concatenation requires string + string -> string")
            self._uses_string_runtime = True
            result = self._new_temp(instruction.result)
            return (
                f"{result} = call ptr @aether_string_concat("
                f"ptr {self._operand(instruction.left)}, ptr {self._operand(instruction.right)})"
            )

        if (
            isinstance(instruction.left.type, IntType)
            and isinstance(instruction.right.type, IntType)
        ):
            if instruction.operator not in self._INT_BINARY_OPERATORS:
                operator = None
            else:
                if instruction.operator == "div" and not isinstance(instruction.result.type, DoubleType):
                    raise LLVMBackendError("LLVM checked int division result must be double")
                if instruction.operator != "div" and not isinstance(instruction.result.type, IntType):
                    raise LLVMBackendError("LLVM checked int arithmetic result must be int")
                self._checked_int_operators.add(instruction.operator)
                helper = LLVMIntegerRuntime.helper_name(instruction.operator)
                result_type = llvm_type(instruction.result.type)
                result = self._new_temp(instruction.result)
                left = self._operand(instruction.left)
                right = self._operand(instruction.right)
                return f"{result} = call {result_type} @{helper}(i32 {left}, i32 {right})"
        elif (
            isinstance(instruction.result.type, DoubleType)
            and isinstance(instruction.left.type, DoubleType)
            and isinstance(instruction.right.type, DoubleType)
        ):
            if instruction.operator == "pow":
                self._uses_double_pow = True
                result = self._new_temp(instruction.result)
                left = self._operand(instruction.left)
                right = self._operand(instruction.right)
                return f"{result} = call double @pow(double {left}, double {right})"
            operator = self._DOUBLE_BINARY_OPERATORS.get(instruction.operator)
            result_type = "double"
        elif (
            isinstance(instruction.result.type, FloatType)
            and isinstance(instruction.left.type, FloatType)
            and isinstance(instruction.right.type, FloatType)
        ):
            operator = self._DOUBLE_BINARY_OPERATORS.get(instruction.operator)
            result_type = "float"
        else:
            raise LLVMBackendError(
                "LLVM backend only supports homogeneous i32 or double binary operations"
            )

        if operator is None:
            raise LLVMBackendError(
                f"LLVM backend does not support binary operator '{instruction.operator}'"
            )

        result = self._new_temp(instruction.result)
        left = self._operand(instruction.left)
        right = self._operand(instruction.right)
        return f"{result} = {operator} {result_type} {left}, {right}"

    def _print_unary_op(self, instruction: SSAUnaryOp) -> str:
        if (
            instruction.operator == "neg"
            and isinstance(instruction.operand.type, DoubleType)
            and isinstance(instruction.result.type, DoubleType)
        ):
            result = self._new_temp(instruction.result)
            operand = self._operand(instruction.operand)
            return f"{result} = fneg double {operand}"
        if (
            instruction.operator != "not"
            or not isinstance(instruction.operand.type, BoolType)
            or not isinstance(instruction.result.type, BoolType)
        ):
            raise LLVMBackendError(
                "LLVM backend only supports unary not on bool/i1 values"
            )
        result = self._new_temp(instruction.result)
        operand = self._operand(instruction.operand)
        return f"{result} = xor i1 {operand}, true"

    def _print_compare_op(self, instruction: SSACompareOp) -> str:
        if isinstance(instruction.left.type, NullableType):
            if (
                instruction.left.type != instruction.right.type
                or instruction.operator not in {"eq", "ne"}
            ):
                raise LLVMBackendError(
                    "LLVM nullable comparison requires homogeneous eq/ne operands"
                )
            helper = self._require_equality_helper(instruction.left.type)
            llvm = llvm_type(instruction.left.type)
            equal = self._synthetic_temp("nullable.equal")
            result = self._new_temp(instruction.result)
            lines = [
                f"{equal} = call i1 @{helper}({llvm} {self._operand(instruction.left)}, "
                f"{llvm} {self._operand(instruction.right)})"
            ]
            lines.append(
                f"{result} = and i1 {equal}, true"
                if instruction.operator == "eq"
                else f"{result} = xor i1 {equal}, true"
            )
            return "\n  ".join(lines)
        if isinstance(instruction.left.type, ClassRefType):
            if (
                instruction.left.type != instruction.right.type
                or instruction.operator not in {"eq", "ne"}
                or not isinstance(instruction.result.type, BoolType)
            ):
                raise LLVMBackendError(
                    "LLVM class identity comparison requires homogeneous eq/ne operands"
                )
            result = self._new_temp(instruction.result)
            predicate = "eq" if instruction.operator == "eq" else "ne"
            return (
                f"{result} = icmp {predicate} ptr "
                f"{self._operand(instruction.left)}, {self._operand(instruction.right)}"
            )
        if isinstance(instruction.left.type, (ArrayType, ListType, StructType)):
            if instruction.left.type != instruction.right.type or instruction.operator not in {"eq", "ne"}:
                raise LLVMBackendError("LLVM structural comparison requires homogeneous eq/ne")
            helper = self._require_equality_helper(instruction.left.type)
            llvm = llvm_type(instruction.left.type)
            equal = self._synthetic_temp("structural.equal")
            result = self._new_temp(instruction.result)
            lines = [
                f"{equal} = call i1 @{helper}({llvm} {self._operand(instruction.left)}, {llvm} {self._operand(instruction.right)})"
            ]
            lines.append(
                f"{result} = and i1 {equal}, true"
                if instruction.operator == "eq"
                else f"{result} = xor i1 {equal}, true"
            )
            return "\n  ".join(lines)
        if instruction.aggregate_shape is not None:
            self._uses_array_type = True
            if isinstance(instruction.left.type, VectorType):
                prefix = "vector"
                element_type = instruction.left.type.element
                self._vector_equality_types.add(element_type)
            elif isinstance(instruction.left.type, MatrixType):
                prefix = "matrix"
                element_type = instruction.left.type.element
                self._matrix_equality_types.add(element_type)
            else:
                raise LLVMBackendError("LLVM aggregate compare expects VectorType or MatrixType")
            if isinstance(element_type, StringType):
                self._uses_string_runtime = True
            length = 1
            for size in instruction.aggregate_shape:
                length *= size
            result = self._new_temp(instruction.result)
            helper = f"aether_{prefix}_equal_{aggregate_helper_suffix(element_type)}"
            left = self._operand(instruction.left)
            right = self._operand(instruction.right)
            if instruction.operator == "eq":
                return f"{result} = call i1 @{helper}(ptr {left}, ptr {right}, i64 {length})"
            if instruction.operator == "ne":
                equal = self._synthetic_temp(f"{prefix}.equal")
                return "\n  ".join(
                    [
                        f"{equal} = call i1 @{helper}(ptr {left}, ptr {right}, i64 {length})",
                        f"{result} = xor i1 {equal}, true",
                    ]
                )
            raise LLVMBackendError("LLVM aggregate compare only supports eq/ne")

        if (
            isinstance(instruction.left.type, StringType)
            or isinstance(instruction.right.type, StringType)
        ):
            if (
                instruction.left.type != instruction.right.type
                or instruction.operator not in {"eq", "ne"}
                or not isinstance(instruction.result.type, BoolType)
            ):
                raise LLVMBackendError("LLVM string comparison only supports homogeneous eq/ne")
            self._uses_string_runtime = True
            result = self._new_temp(instruction.result)
            equal = self._synthetic_temp("string.equal")
            lines = [
                f"{equal} = call i1 @aether_string_equal(ptr {self._operand(instruction.left)}, ptr {self._operand(instruction.right)})"
            ]
            lines.append(
                f"{result} = and i1 {equal}, true"
                if instruction.operator == "eq"
                else f"{result} = xor i1 {equal}, true"
            )
            return "\n  ".join(lines)

        if (
            isinstance(instruction.result.type, BoolType)
            and (
                isinstance(instruction.left.type, IntType)
                and isinstance(instruction.right.type, IntType)
                or isinstance(instruction.left.type, EnumType)
                and instruction.left.type == instruction.right.type
                and instruction.operator in {"eq", "ne"}
            )
        ):
            operation = "icmp"
            predicate = self._INT_COMPARE_OPERATORS.get(instruction.operator)
            operand_type = "i32"
        elif (
            isinstance(instruction.result.type, BoolType)
            and isinstance(instruction.left.type, (FloatType, DoubleType))
            and instruction.left.type == instruction.right.type
        ):
            operation = "fcmp"
            predicate = self._DOUBLE_COMPARE_OPERATORS.get(instruction.operator)
            operand_type = llvm_type(instruction.left.type)
        else:
            raise LLVMBackendError(
                "LLVM backend only supports i32 or double comparisons producing i1"
            )

        if predicate is None:
            raise LLVMBackendError(
                f"LLVM backend does not support compare operator '{instruction.operator}'"
            )

        result = self._new_temp(instruction.result)
        left = self._operand(instruction.left)
        right = self._operand(instruction.right)
        return f"{result} = {operation} {predicate} {operand_type} {left}, {right}"

    def _print_struct_compare(self, instruction: SSACompareOp) -> list[str]:
        if instruction.operator not in {"eq", "ne"} or instruction.left.type != instruction.right.type:
            raise LLVMBackendError("LLVM struct comparison only supports equal nominal types with eq/ne")
        struct_type = instruction.left.type
        definition = self._structs.get(struct_type.name)
        if definition is None:
            raise LLVMBackendError(f"LLVM has no layout for struct {struct_type.name}")
        lines: list[str] = []
        comparisons: list[str] = []
        for index, (_name, field_type) in enumerate(definition.fields):
            left_field = self._synthetic_temp("struct.compare.left")
            right_field = self._synthetic_temp("struct.compare.right")
            lines.extend([
                f"{left_field} = extractvalue {llvm_type(struct_type)} {self._operand(instruction.left)}, {index}",
                f"{right_field} = extractvalue {llvm_type(struct_type)} {self._operand(instruction.right)}, {index}",
            ])
            comparisons.append(
                self._emit_struct_field_equality(lines, left_field, right_field, field_type)
            )
        equal = comparisons[0] if comparisons else "true"
        for comparison in comparisons[1:]:
            combined = self._synthetic_temp("struct.compare.and")
            lines.append(f"{combined} = and i1 {equal}, {comparison}")
            equal = combined
        result = self._new_temp(instruction.result)
        if instruction.operator == "eq":
            lines.append(f"{result} = and i1 {equal}, true")
        else:
            lines.append(f"{result} = xor i1 {equal}, true")
        return lines

    def _require_equality_helper(self, type_: object) -> str:
        self._eq_helper_types.add(type_)
        if isinstance(type_, StringType):
            self._uses_string_runtime = True
        if isinstance(type_, ArrayType):
            self._uses_array_type = True
        if isinstance(type_, ListType):
            self._uses_list_type = True
        return f"__ae_eq_{aggregate_helper_suffix(type_)}"

    def _equality_compare_line(
        self,
        type_: object,
        result: str,
        left: str,
        right: str,
    ) -> str:
        llvm = llvm_type(type_)
        if isinstance(type_, (IntType, BoolType, EnumType, ClassRefType)):
            return f"  {result} = icmp eq {llvm} {left}, {right}"
        if isinstance(type_, (FloatType, DoubleType)):
            return f"  {result} = fcmp oeq {llvm} {left}, {right}"
        helper = self._require_equality_helper(type_)
        return f"  {result} = call i1 @{helper}({llvm} {left}, {llvm} {right})"

    def _equality_helper(self, type_: object) -> str:
        name = self._require_equality_helper(type_)
        llvm = llvm_type(type_)
        if isinstance(type_, (IntType, BoolType, EnumType, ClassRefType)):
            return "\n".join([
                f"define private i1 @{name}({llvm} %left, {llvm} %right) {{",
                "entry:",
                f"  %equal = icmp eq {llvm} %left, %right",
                "  ret i1 %equal",
                "}",
            ])
        if isinstance(type_, NullableType):
            inner = type_.inner
            compare = self._equality_compare_line(
                inner,
                "%payload.equal",
                "%left.payload",
                "%right.payload",
            )
            return "\n".join([
                f"define private i1 @{name}({llvm} %left, {llvm} %right) {{",
                "entry:",
                f"  %left.present = extractvalue {llvm} %left, 0",
                f"  %right.present = extractvalue {llvm} %right, 0",
                "  %same.tag = icmp eq i1 %left.present, %right.present",
                "  br i1 %same.tag, label %same_case, label %different",
                "same_case:",
                "  br i1 %left.present, label %present, label %equal",
                "present:",
                f"  %left.payload = extractvalue {llvm} %left, 1",
                f"  %right.payload = extractvalue {llvm} %right, 1",
                compare,
                "  br i1 %payload.equal, label %equal, label %different",
                "equal:",
                "  ret i1 true",
                "different:",
                "  ret i1 false",
                "}",
            ])
        if isinstance(type_, (FloatType, DoubleType)):
            return "\n".join([
                f"define private i1 @{name}({llvm} %left, {llvm} %right) {{",
                "entry:",
                f"  %equal = fcmp oeq {llvm} %left, %right",
                "  ret i1 %equal",
                "}",
            ])
        if isinstance(type_, StringType):
            self._uses_string_runtime = True
            return "\n".join([
                f"define private i1 @{name}(ptr %left, ptr %right) {{",
                "entry:",
                "  %equal = call i1 @aether_string_equal(ptr %left, ptr %right)",
                "  ret i1 %equal",
                "}",
            ])
        if isinstance(type_, StructType):
            definition = self._structs.get(type_.name)
            if definition is None:
                raise LLVMBackendError(f"LLVM has no layout for struct {type_.name}")
            lines = [
                f"define private i1 @{name}({llvm} %left, {llvm} %right) {{",
                "entry:",
            ]
            if not definition.fields:
                lines.extend(["  ret i1 true", "}"])
                return "\n".join(lines)
            lines.append("  br label %field.0")
            for index, (_field_name, field_type) in enumerate(definition.fields):
                next_label = f"field.{index + 1}" if index + 1 < len(definition.fields) else "equal"
                lines.extend([
                    f"field.{index}:",
                    f"  %left.{index} = extractvalue {llvm} %left, {index}",
                    f"  %right.{index} = extractvalue {llvm} %right, {index}",
                    self._equality_compare_line(
                        field_type,
                        f"%same.{index}",
                        f"%left.{index}",
                        f"%right.{index}",
                    ),
                    f"  br i1 %same.{index}, label %{next_label}, label %different",
                ])
            lines.extend([
                "equal:",
                "  ret i1 true",
                "different:",
                "  ret i1 false",
                "}",
            ])
            return "\n".join(lines)
        if isinstance(type_, (ArrayType, ListType)):
            layout = "%AetherArray" if isinstance(type_, ArrayType) else "%AetherList"
            data_index = 1 if isinstance(type_, ArrayType) else 2
            element = type_.element
            element_llvm = llvm_type(element)
            compare = self._equality_compare_line(
                element, "%same.element", "%left.value", "%right.value"
            )
            return "\n".join([
                f"define private i1 @{name}(ptr %left, ptr %right) {{",
                "entry:",
                "  %same.handle = icmp eq ptr %left, %right",
                "  br i1 %same.handle, label %equal, label %lengths",
                "lengths:",
                f"  %left.length.field = getelementptr {layout}, ptr %left, i32 0, i32 0",
                "  %left.length = load i64, ptr %left.length.field",
                f"  %right.length.field = getelementptr {layout}, ptr %right, i32 0, i32 0",
                "  %right.length = load i64, ptr %right.length.field",
                "  %same.length = icmp eq i64 %left.length, %right.length",
                "  br i1 %same.length, label %prepare, label %different",
                "prepare:",
                f"  %left.data.field = getelementptr {layout}, ptr %left, i32 0, i32 {data_index}",
                "  %left.data = load ptr, ptr %left.data.field",
                f"  %right.data.field = getelementptr {layout}, ptr %right, i32 0, i32 {data_index}",
                "  %right.data = load ptr, ptr %right.data.field",
                "  br label %loop",
                "loop:",
                "  %index = phi i64 [ 0, %prepare ], [ %next, %advance ]",
                "  %done = icmp eq i64 %index, %left.length",
                "  br i1 %done, label %equal, label %compare",
                "compare:",
                f"  %left.element = getelementptr {element_llvm}, ptr %left.data, i64 %index",
                f"  %left.value = load {element_llvm}, ptr %left.element",
                f"  %right.element = getelementptr {element_llvm}, ptr %right.data, i64 %index",
                f"  %right.value = load {element_llvm}, ptr %right.element",
                compare,
                "  br i1 %same.element, label %advance, label %different",
                "advance:",
                "  %next = add i64 %index, 1",
                "  br label %loop",
                "equal:",
                "  ret i1 true",
                "different:",
                "  ret i1 false",
                "}",
            ])
        raise LLVMBackendError(f"LLVM cannot emit Eq({type_})")

    def _emit_struct_field_equality(
        self,
        lines: list[str],
        left: str,
        right: str,
        field_type: object,
    ) -> str:
        result = self._synthetic_temp("struct.compare.field")
        if isinstance(field_type, (IntType, BoolType, EnumType, ClassRefType)):
            if isinstance(field_type, ClassRefType):
                self._class_types.add(field_type)
            lines.append(f"{result} = icmp eq {llvm_type(field_type)} {left}, {right}")
            return result
        if isinstance(field_type, DoubleType):
            lines.append(f"{result} = fcmp oeq double {left}, {right}")
            return result
        if isinstance(field_type, StringType):
            self._uses_string_runtime = True
            lines.append(f"{result} = call i1 @aether_string_equal(ptr {left}, ptr {right})")
            return result
        if isinstance(field_type, StructType):
            definition = self._structs.get(field_type.name)
            if definition is None:
                raise LLVMBackendError(f"LLVM has no layout for nested struct {field_type.name}")
            nested: list[str] = []
            for index, (_name, nested_type) in enumerate(definition.fields):
                left_field = self._synthetic_temp("struct.compare.nested.left")
                right_field = self._synthetic_temp("struct.compare.nested.right")
                lines.extend([
                    f"{left_field} = extractvalue {llvm_type(field_type)} {left}, {index}",
                    f"{right_field} = extractvalue {llvm_type(field_type)} {right}, {index}",
                ])
                nested.append(self._emit_struct_field_equality(lines, left_field, right_field, nested_type))
            equal = nested[0] if nested else "true"
            for comparison in nested[1:]:
                combined = self._synthetic_temp("struct.compare.nested.and")
                lines.append(f"{combined} = and i1 {equal}, {comparison}")
                equal = combined
            lines.append(f"{result} = and i1 {equal}, true")
            return result
        if isinstance(field_type, (ArrayType, ListType)):
            kind = "array" if isinstance(field_type, ArrayType) else "list"
            if kind == "array":
                self._uses_array_type = True
            else:
                self._uses_list_type = True
            self._struct_sequence_equality_types.add((kind, field_type.element))
            helper = self._struct_sequence_equality_helper_name(kind, field_type.element)
            lines.append(f"{result} = call i1 @{helper}(ptr {left}, ptr {right})")
            return result
        raise LLVMBackendError(f"LLVM struct equality does not support field type {field_type}")

    @staticmethod
    def _struct_sequence_equality_helper_name(kind: str, element_type: object) -> str:
        return f"aether_struct_{kind}_equal_{aggregate_helper_suffix(element_type)}"

    def _struct_sequence_equality_helper(self, kind: str, element_type: object) -> str:
        name = self._struct_sequence_equality_helper_name(kind, element_type)
        layout = "%AetherArray" if kind == "array" else "%AetherList"
        data_index = 1 if kind == "array" else 2
        element_llvm = llvm_type(element_type)
        compare_lines: list[str]
        if isinstance(element_type, (IntType, BoolType, ClassRefType)):
            if isinstance(element_type, ClassRefType):
                self._class_types.add(element_type)
            compare_lines = [f"  %equal = icmp eq {element_llvm} %left.value, %right.value"]
        elif isinstance(element_type, DoubleType):
            compare_lines = ["  %equal = fcmp oeq double %left.value, %right.value"]
        elif isinstance(element_type, StringType):
            self._uses_string_runtime = True
            compare_lines = [
                "  %equal = call i1 @aether_string_equal(ptr %left.value, ptr %right.value)",
            ]
        else:
            raise LLVMBackendError(
                f"LLVM struct sequence equality does not support element type {element_type}"
            )
        return "\n".join([
            f"define private i1 @{name}(ptr %left, ptr %right) {{",
            "entry:",
            f"  %left.length.field = getelementptr {layout}, ptr %left, i32 0, i32 0",
            "  %left.length = load i64, ptr %left.length.field",
            f"  %right.length.field = getelementptr {layout}, ptr %right, i32 0, i32 0",
            "  %right.length = load i64, ptr %right.length.field",
            "  %same.length = icmp eq i64 %left.length, %right.length",
            "  br i1 %same.length, label %prepare, label %not.equal",
            "prepare:",
            f"  %left.data.field = getelementptr {layout}, ptr %left, i32 0, i32 {data_index}",
            "  %left.data = load ptr, ptr %left.data.field",
            f"  %right.data.field = getelementptr {layout}, ptr %right, i32 0, i32 {data_index}",
            "  %right.data = load ptr, ptr %right.data.field",
            "  br label %loop",
            "loop:",
            "  %index = phi i64 [ 0, %prepare ], [ %next, %advance ]",
            "  %done = icmp eq i64 %index, %left.length",
            "  br i1 %done, label %all.equal, label %compare",
            "compare:",
            f"  %left.element = getelementptr {element_llvm}, ptr %left.data, i64 %index",
            f"  %left.value = load {element_llvm}, ptr %left.element",
            f"  %right.element = getelementptr {element_llvm}, ptr %right.data, i64 %index",
            f"  %right.value = load {element_llvm}, ptr %right.element",
            *compare_lines,
            "  br i1 %equal, label %advance, label %not.equal",
            "advance:",
            "  %next = add i64 %index, 1",
            "  br label %loop",
            "all.equal:",
            "  ret i1 true",
            "not.equal:",
            "  ret i1 false",
            "}",
        ])

    def _print_cast(self, instruction: SSACast) -> str:
        if isinstance(instruction.result.type, NullableType):
            target = instruction.result.type
            target_llvm = llvm_type(target)
            result = self._new_temp(instruction.result)
            source_operand = self._operand(instruction.value)
            if isinstance(instruction.value.type, NullableType):
                source = instruction.value.type
                source_llvm = llvm_type(source)
                present = self._synthetic_temp("nullable.cast.present")
                payload = self._synthetic_temp("nullable.cast.payload")
                converted = payload
                lines = [
                    f"{present} = extractvalue {source_llvm} {source_operand}, 0",
                    f"{payload} = extractvalue {source_llvm} {source_operand}, 1",
                ]
                if source.inner != target.inner:
                    if isinstance(source.inner, IntType) and isinstance(
                        target.inner, (FloatType, DoubleType)
                    ):
                        converted = self._synthetic_temp("nullable.cast.converted")
                        lines.append(
                            f"{converted} = sitofp i32 {payload} to {llvm_type(target.inner)}"
                        )
                    else:
                        raise LLVMBackendError(
                            f"LLVM nullable cast does not support {source} to {target}"
                        )
                tagged = self._synthetic_temp("nullable.cast.tagged")
                lines.extend([
                    f"{tagged} = insertvalue {target_llvm} zeroinitializer, i1 {present}, 0",
                    f"{result} = insertvalue {target_llvm} {tagged}, "
                    f"{llvm_type(target.inner)} {converted}, 1",
                ])
                return "\n  ".join(lines)
            if instruction.value.type != target.inner:
                raise LLVMBackendError(
                    f"LLVM nullable construction requires {target.inner}, "
                    f"got {instruction.value.type}"
                )
            tagged = self._synthetic_temp("nullable.present")
            return "\n  ".join([
                f"{tagged} = insertvalue {target_llvm} zeroinitializer, i1 true, 0",
                f"{result} = insertvalue {target_llvm} {tagged}, "
                f"{llvm_type(target.inner)} {source_operand}, 1",
            ])
        if instruction.value.type == instruction.result.type:
            result = self._new_temp(instruction.result)
            type_name = llvm_type(instruction.result.type)
            value = self._operand(instruction.value)
            return f"{result} = select i1 true, {type_name} {value}, {type_name} {value}"
        if isinstance(instruction.value.type, IntType) and isinstance(
            instruction.result.type,
            DoubleType,
        ):
            operator = "sitofp"
        elif isinstance(instruction.value.type, DoubleType) and isinstance(
            instruction.result.type,
            IntType,
        ):
            operator = "fptosi"
        elif isinstance(instruction.value.type, DoubleType) and isinstance(
            instruction.result.type, FloatType
        ):
            operator = "fptrunc"
        elif isinstance(instruction.value.type, FloatType) and isinstance(
            instruction.result.type, DoubleType
        ):
            operator = "fpext"
        elif isinstance(instruction.value.type, IntType) and isinstance(
            instruction.result.type, FloatType
        ):
            operator = "sitofp"
        elif isinstance(instruction.value.type, FloatType) and isinstance(
            instruction.result.type, IntType
        ):
            operator = "fptosi"
        else:
            raise LLVMBackendError(
                "LLVM backend only supports casts from i32 to double "
                "or double to i32"
            )

        result = self._new_temp(instruction.result)
        source_type = llvm_type(instruction.value.type)
        target_type = llvm_type(instruction.result.type)
        value = self._operand(instruction.value)
        return f"{result} = {operator} {source_type} {value} to {target_type}"

    def _print_phi(self, instruction: SSAPhi) -> str:
        if not instruction.incoming:
            raise LLVMBackendError("LLVM backend does not support phi with no incoming values")

        result_type = llvm_type(instruction.result.type)
        result = self._new_temp(instruction.result)
        incoming = ", ".join(
            f"[ {self._operand(value)}, %{self._label_name(block)} ]"
            for block, value in instruction.incoming
        )
        return f"{result} = phi {result_type} {incoming}"

    def _print_return(self, instruction: SSAReturn, function: SSAFunction) -> str:
        if instruction.value is None:
            if not isinstance(function.return_type, VoidType):
                raise LLVMBackendError(
                    "LLVM backend does not support empty return from non-void function"
                )
            return "ret void"

        if isinstance(function.return_type, VoidType):
            raise LLVMBackendError(
                "LLVM backend does not support value return from void function"
            )

        return_type = llvm_type(function.return_type)
        value_type = llvm_type(instruction.value.type)
        if value_type != return_type:
            raise LLVMBackendError(
                "LLVM backend does not support return type mismatches"
            )
        return f"ret {return_type} {self._operand(instruction.value)}"

    def _print_branch(self, instruction: SSABranch) -> str:
        if not isinstance(instruction.condition.type, BoolType):
            raise LLVMBackendError(
                "LLVM backend only supports bool/i1 branch conditions"
            )

        condition = self._operand(instruction.condition)
        true_target = self._label_operand(instruction.true_target)
        false_target = self._label_operand(instruction.false_target)
        return f"br i1 {condition}, {true_target}, {false_target}"

    def _print_jump(self, instruction: SSAJump) -> str:
        return f"br {self._label_operand(instruction.target)}"

    def _function_uses_exception_out(self, function: SSAFunction) -> bool:
        return (
            self._exception_strategy is ExceptionLoweringStrategy.EVENT_OUT
            and function.may_throw
            and function.name != "main"
        )

    @staticmethod
    def _exceptional_return(return_type: object) -> str:
        if isinstance(return_type, VoidType):
            return "ret void"
        rendered = llvm_type(return_type)
        if isinstance(return_type, (IntType, EnumType, BoolType)):
            return f"ret {rendered} 0"
        if isinstance(return_type, (DoubleType, FloatType)):
            return f"ret {rendered} 0.000000e+00"
        if isinstance(
            return_type,
            (StringType, ClassRefType, FunctionType, ArrayType, ListType, VectorType, MatrixType),
        ):
            return f"ret {rendered} null"
        return f"ret {rendered} zeroinitializer"

    def _invoke_call_lines(
        self,
        *,
        callee: str,
        arguments: tuple[SSAValue, ...],
        return_type: object,
        result_value: SSAValue | None,
        exception_value: SSAValue,
        normal_target: str,
        exceptional_target: str,
        prefix: str,
    ) -> list[str]:
        if self._exception_strategy is ExceptionLoweringStrategy.LLVM_EH_PROTOTYPE:
            rendered_arguments = [
                f"{llvm_type(argument.type)} {self._operand(argument)}"
                for argument in arguments
            ]
            rendered_return = llvm_type(return_type)
            trampoline = self._eh_trampoline_by_block.get(self._current_block)
            if trampoline is None:
                raise LLVMBackendError("LLVM EH invoke has no landing-pad trampoline")
            invoke = (
                f"invoke {rendered_return} {callee}({', '.join(rendered_arguments)}) "
                f"to {self._label_operand(normal_target)} "
                f"unwind {self._label_operand(trampoline)}"
            )
            if isinstance(return_type, VoidType):
                if result_value is not None:
                    raise LLVMBackendError("LLVM void invoke cannot define a normal result")
                return [invoke]
            if result_value is None:
                raise LLVMBackendError("LLVM non-void invoke requires a normal result")
            return [f"{self._new_temp(result_value)} = {invoke}"]

        slot = self._synthetic_temp(f"{prefix}.event.out")
        failed = self._synthetic_temp(f"{prefix}.failed")
        rendered_arguments = [
            f"{llvm_type(argument.type)} {self._operand(argument)}"
            for argument in arguments
        ]
        rendered_arguments.append(f"ptr {slot}")
        lines = [
            f"{slot} = alloca ptr, align 8",
            f"store ptr null, ptr {slot}, align 8",
        ]
        rendered_return = llvm_type(return_type)
        call = f"call {rendered_return} {callee}({', '.join(rendered_arguments)})"
        if isinstance(return_type, VoidType):
            if result_value is not None:
                raise LLVMBackendError("LLVM void invoke cannot define a normal result")
            lines.append(call)
        else:
            if result_value is None:
                raise LLVMBackendError("LLVM non-void invoke requires a normal result")
            lines.append(f"{self._new_temp(result_value)} = {call}")
        event = self._new_temp(exception_value)
        lines.extend(
            [
                f"{event} = load ptr, ptr {slot}, align 8",
                f"{failed} = icmp ne ptr {event}, null",
                f"br i1 {failed}, {self._label_operand(exceptional_target)}, "
                f"{self._label_operand(normal_target)}",
            ]
        )
        return lines

    def _print_direct_invoke(self, instruction: SSAInvoke) -> list[str]:
        target = self._functions_by_name.get(instruction.function)
        if target is None or not target.may_throw:
            raise LLVMBackendError(
                f"LLVM call/invoke mismatch for '{instruction.function}'"
            )
        if instruction.function == "main":
            raise LLVMBackendError(
                "LLVM raw-C containment forbids invoking the process entry as a throwing callable"
            )
        return self._invoke_call_lines(
            callee=self._global_name(instruction.function),
            arguments=instruction.arguments,
            return_type=target.return_type,
            result_value=instruction.result,
            exception_value=instruction.exception,
            normal_target=instruction.normal_target,
            exceptional_target=instruction.exceptional_target,
            prefix="invoke.direct",
        )

    def _print_indirect_invoke(self, instruction: SSAInvokeIndirect) -> list[str]:
        if not isinstance(instruction.callee.type, FunctionType):
            raise LLVMBackendError("LLVM indirect invoke requires a callable callee")
        known_target = self._function_reference_targets.get(
            self._key(instruction.callee)
        )
        if known_target is not None:
            target = self._functions_by_name.get(known_target)
            if target is None or not target.may_throw:
                raise LLVMBackendError(
                    f"LLVM call/invoke mismatch for indirect target '{known_target}'"
                )
        return self._invoke_call_lines(
            callee=self._operand(instruction.callee),
            arguments=instruction.arguments,
            return_type=instruction.callee.type.return_type,
            result_value=instruction.result,
            exception_value=instruction.exception,
            normal_target=instruction.normal_target,
            exceptional_target=instruction.exceptional_target,
            prefix="invoke.indirect",
        )

    def _print_interface_invoke(self, instruction: SSAInvokeInterface) -> list[str]:
        if not isinstance(instruction.receiver.type, InterfaceType):
            raise LLVMBackendError("LLVM interface invoke requires an interface receiver")
        if not instruction.slot.may_throw:
            raise LLVMBackendError(
                f"LLVM interface invoke target '{instruction.slot.method_id}' is not may_throw"
            )
        self._uses_interface_dispatch = True
        rendered = llvm_type(instruction.receiver.type)
        receiver = self._operand(instruction.receiver)
        carrier = self._synthetic_temp("invoke.interface.carrier")
        witness = self._synthetic_temp("invoke.interface.witness")
        slots = self._synthetic_temp("invoke.interface.slots")
        slot_pointer = self._synthetic_temp("invoke.interface.slot")
        thunk_pointer = self._synthetic_temp("invoke.interface.thunk.ptr")
        thunk = self._synthetic_temp("invoke.interface.thunk")
        lines = [
            f"{carrier} = extractvalue {rendered} {receiver}, 0",
            f"{witness} = extractvalue {rendered} {receiver}, 1",
            f"{slots} = getelementptr %AetherWitnessHeader, ptr {witness}, i32 1",
            f"{slot_pointer} = getelementptr %AetherWitnessSlot, ptr {slots}, i64 {instruction.slot.index}",
            f"{thunk_pointer} = getelementptr %AetherWitnessSlot, ptr {slot_pointer}, i32 0, i32 2",
            f"{thunk} = load ptr, ptr {thunk_pointer}",
        ]
        arguments = [
            f"ptr {carrier}",
            *[
                f"{llvm_type(argument.type)} {self._operand(argument)}"
                for argument in instruction.arguments
            ],
        ]
        return_type = instruction.slot.return_type
        if self._exception_strategy is ExceptionLoweringStrategy.LLVM_EH_PROTOTYPE:
            trampoline = self._eh_trampoline_by_block.get(self._current_block)
            if trampoline is None:
                raise LLVMBackendError("LLVM EH interface invoke has no landing-pad trampoline")
            call = (
                f"invoke {llvm_type(return_type)} {thunk}({', '.join(arguments)}) "
                f"to {self._label_operand(instruction.normal_target)} "
                f"unwind {self._label_operand(trampoline)}"
            )
            if isinstance(return_type, VoidType):
                if instruction.result is not None:
                    raise LLVMBackendError("LLVM void interface invoke cannot define a result")
                lines.append(call)
            else:
                if instruction.result is None:
                    raise LLVMBackendError("LLVM interface invoke requires a normal result")
                lines.append(f"{self._new_temp(instruction.result)} = {call}")
            return lines

        slot = self._synthetic_temp("invoke.interface.event.out")
        failed = self._synthetic_temp("invoke.interface.failed")
        lines.extend([f"{slot} = alloca ptr, align 8", f"store ptr null, ptr {slot}, align 8"])
        arguments.append(f"ptr {slot}")
        call = f"call {llvm_type(return_type)} {thunk}({', '.join(arguments)})"
        if isinstance(return_type, VoidType):
            if instruction.result is not None:
                raise LLVMBackendError("LLVM void interface invoke cannot define a result")
            lines.append(call)
        else:
            if instruction.result is None:
                raise LLVMBackendError("LLVM interface invoke requires a normal result")
            lines.append(f"{self._new_temp(instruction.result)} = {call}")
        event = self._new_temp(instruction.exception)
        lines.extend(
            [
                f"{event} = load ptr, ptr {slot}, align 8",
                f"{failed} = icmp ne ptr {event}, null",
                f"br i1 {failed}, {self._label_operand(instruction.exceptional_target)}, "
                f"{self._label_operand(instruction.normal_target)}",
            ]
        )
        return lines

    def _print_exception_pack(self, instruction: SSAPackException) -> list[str]:
        payload_type = instruction.payload.type
        payload = self._operand(instruction.payload)
        lines: list[str] = []
        descriptor: str
        carrier: str
        copy_payload = self._key(instruction.payload) in self._exception_pack_copy_required
        if isinstance(payload_type, (StructType, ClassRefType)):
            if instruction.dynamic_type != payload_type.name:
                raise LLVMBackendError(
                    "LLVM exception_pack descriptor does not match its concrete payload"
                )
            witness = self._require_error_witness(payload_type.name, payload_type)
            descriptor = f"@{exception_descriptor_symbol(payload_type.name)}"
            if isinstance(payload_type, ClassRefType):
                if copy_payload:
                    lines.append(f"call void @aether_class_retain(ptr {payload})")
                carrier = payload
            else:
                if witness.box_layout is None:
                    raise LLVMBackendError("LLVM struct Error witness has no box layout")
                self._uses_interface_boxing = True
                box_type = box_type_symbol("Error", payload_type.name)
                carrier = self._synthetic_temp("exception.box")
                size = f"ptrtoint (ptr getelementptr ({box_type}, ptr null, i64 1) to i64)"
                size_ptr = self._synthetic_temp("exception.box.size")
                alignment_ptr = self._synthetic_temp("exception.box.alignment")
                offset_ptr = self._synthetic_temp("exception.box.offset")
                payload_ptr = self._synthetic_temp("exception.box.payload")
                stored_payload = payload
                if copy_payload:
                    stored_payload = self._emit_arc_value(
                        lines, payload, payload_type, retain=True
                    )
                lines.extend(
                    [
                        f"{carrier} = call ptr @aether_alloc(i64 {size})",
                        f"{size_ptr} = getelementptr {box_type}, ptr {carrier}, i32 0, i32 0",
                        f"store i64 {witness.box_layout.payload_size}, ptr {size_ptr}",
                        f"{alignment_ptr} = getelementptr {box_type}, ptr {carrier}, i32 0, i32 1",
                        f"store i32 {witness.box_layout.payload_alignment}, ptr {alignment_ptr}",
                        f"{offset_ptr} = getelementptr {box_type}, ptr {carrier}, i32 0, i32 2",
                        f"store i32 {witness.box_layout.payload_offset}, ptr {offset_ptr}",
                        f"{payload_ptr} = getelementptr {box_type}, ptr {carrier}, i32 0, i32 4",
                        f"store {llvm_type(payload_type)} {stored_payload}, ptr {payload_ptr}",
                    ]
                )
        elif isinstance(payload_type, InterfaceType) and payload_type.name == "Error":
            carrier = self._synthetic_temp("exception.interface.carrier")
            witness_value = self._synthetic_temp("exception.interface.witness")
            lines.extend(
                [
                    f"{carrier} = extractvalue {llvm_type(payload_type)} {payload}, 0",
                    f"{witness_value} = extractvalue {llvm_type(payload_type)} {payload}, 1",
                ]
            )
            if copy_payload:
                copy_pointer = self._synthetic_temp("exception.interface.copy.ptr")
                copy_adapter = self._synthetic_temp("exception.interface.copy")
                copied_carrier = self._synthetic_temp("exception.interface.carrier.copy")
                lines.extend(
                    [
                        f"{copy_pointer} = getelementptr %AetherWitnessHeader, ptr {witness_value}, i32 0, i32 4",
                        f"{copy_adapter} = load ptr, ptr {copy_pointer}",
                        f"{copied_carrier} = call ptr {copy_adapter}(ptr {carrier})",
                    ]
                )
                carrier = copied_carrier
            selected = "null"
            for nominal_id, concrete_type in sorted(self._exception_nominal_types.items()):
                witness = self._require_error_witness(nominal_id, concrete_type)
                matches = self._synthetic_temp("exception.descriptor.match")
                updated = self._synthetic_temp("exception.descriptor.select")
                lines.extend(
                    [
                        f"{matches} = icmp eq ptr {witness_value}, @{witness.symbol}",
                        f"{updated} = select i1 {matches}, ptr @{exception_descriptor_symbol(nominal_id)}, ptr {selected}",
                    ]
                )
                selected = updated
            descriptor = selected
        else:
            raise LLVMBackendError(
                "LLVM exception_pack requires a concrete Error or interface Error payload"
            )
        location = instruction.source_location
        line = getattr(location, "line", 1) if location is not None else 1
        column = getattr(location, "column", 1) if location is not None else 1
        result = self._new_temp(instruction.result)
        lines.append(
            f"{result} = call ptr @__ae_exception_create_v1(ptr {descriptor}, "
            f"ptr {carrier}, i32 {max(1, int(line))}, i32 {max(1, int(column))})"
        )
        return lines

    def _print_catch_entry(self, instruction: SSACatchEntry) -> str:
        incoming = self._exception_predecessors.get(self._current_block, [])
        if not incoming:
            raise LLVMBackendError(
                f"LLVM catch_entry '{instruction.handler_id}' has no exceptional predecessor"
            )
        result = self._new_temp(instruction.event)
        values = ", ".join(
            f"[ {self._operand(event)}, %{self._label_name(predecessor)} ]"
            for predecessor, event in incoming
        )
        return f"{result} = phi ptr {values}"

    def _print_exception_match(self, instruction: SSAExceptionMatch) -> str:
        result = self._new_temp(instruction.result)
        event = self._operand(instruction.event)
        if instruction.catch_all:
            if instruction.catch_type != "Error":
                raise LLVMBackendError("LLVM only Error may be an exception catch-all")
            return f"{result} = icmp ne ptr {event}, null"
        concrete_type = self._exception_nominal_types.get(instruction.catch_type)
        if concrete_type is None:
            raise LLVMBackendError(
                f"LLVM exception match has malformed descriptor '{instruction.catch_type}'"
            )
        descriptor = exception_descriptor_symbol(instruction.catch_type)
        return (
            f"{result} = call i1 @__ae_exception_matches_v1(ptr {event}, "
            f"ptr @{descriptor})"
        )

    def _print_exception_payload(self, instruction: SSAExceptionPayload) -> list[str]:
        event = self._operand(instruction.event)
        carrier = self._synthetic_temp("exception.borrow.carrier")
        lines = [
            f"{carrier} = call ptr @__ae_exception_borrow_carrier_v1(ptr {event})"
        ]
        result = self._new_temp(instruction.result)
        if instruction.catch_type == "Error":
            if instruction.result.type != InterfaceType("Error"):
                raise LLVMBackendError("LLVM Error borrow must produce interface Error")
            witness = self._synthetic_temp("exception.borrow.witness")
            inserted = self._synthetic_temp("exception.borrow.interface")
            rendered = llvm_type(instruction.result.type)
            lines.extend(
                [
                    f"{witness} = call ptr @__ae_exception_borrow_witness_v1(ptr {event})",
                    f"{inserted} = insertvalue {rendered} undef, ptr {carrier}, 0",
                    f"{result} = insertvalue {rendered} {inserted}, ptr {witness}, 1",
                ]
            )
        elif isinstance(instruction.result.type, ClassRefType):
            if instruction.result.type.name != instruction.catch_type:
                raise LLVMBackendError("LLVM class exception borrow descriptor mismatch")
            lines.append(f"{result} = getelementptr i8, ptr {carrier}, i64 0")
        elif isinstance(instruction.result.type, StructType):
            if instruction.result.type.name != instruction.catch_type:
                raise LLVMBackendError("LLVM struct exception borrow descriptor mismatch")
            box_type = box_type_symbol("Error", instruction.catch_type)
            payload_ptr = self._synthetic_temp("exception.borrow.payload")
            lines.extend(
                [
                    f"{payload_ptr} = getelementptr {box_type}, ptr {carrier}, i32 0, i32 4",
                    f"{result} = load {llvm_type(instruction.result.type)}, ptr {payload_ptr}",
                ]
            )
        else:
            raise LLVMBackendError("LLVM exception payload borrow has unsupported type")
        return lines

    def _print_exception_transfer(
        self,
        instruction: SSAThrow | SSARethrow | SSAPropagate,
        function: SSAFunction,
    ) -> str:
        event = self._operand(instruction.event)
        if instruction.target is not None:
            if instruction.exceptional_arguments != (instruction.event,):
                raise LLVMBackendError(
                    "LLVM exceptional transfer has invalid successor arguments"
                )
            return f"br {self._label_operand(instruction.target)}"
        if instruction.exceptional_arguments:
            raise LLVMBackendError("LLVM root propagation cannot carry successor arguments")
        if function.name == "main":
            return (
                f"call void @__ae_exception_root_terminate_v1(ptr {event})\n  "
                "unreachable"
            )
        if not self._function_uses_exception_out(function):
            if (
                self._exception_strategy
                is ExceptionLoweringStrategy.LLVM_EH_PROTOTYPE
            ):
                return (
                    f"call void @__ae_exception_eh_raise_v1(ptr {event})\n  "
                    "unreachable"
                )
            raise LLVMBackendError(
                f"LLVM function '{function.name}' propagates without private event-out ABI"
            )
        return (
            f"store ptr {event}, ptr %__ae_exception_out, align 8\n  "
            f"{self._exceptional_return(function.return_type)}"
        )

    def _print_call(self, instruction: SSACall) -> str:
        if instruction.builtin == RANGE_STEP_NONZERO_BUILTIN:
            if (
                instruction.result is not None
                or len(instruction.arguments) != 1
                or not isinstance(instruction.arguments[0].type, IntType)
            ):
                raise LLVMBackendError("LLVM range-step guard requires int -> void")
            self._uses_range_step_guard = True
            return (
                "call void @aether_range_step_nonzero(i32 "
                f"{self._operand(instruction.arguments[0])})"
            )
        if instruction.builtin == PROCESS_ARGS_BUILTIN:
            if (
                instruction.result is None
                or instruction.arguments
                or instruction.result.type != ArrayType(StringType())
            ):
                raise LLVMBackendError("LLVM System.args requires () -> owned Array<string>")
            self._uses_process_arguments = True
            self._uses_array_type = True
            self._uses_array_allocation = True
            self._uses_string_runtime = True
            result = self._new_temp(instruction.result)
            return f"{result} = call ptr @aether_process_args_snapshot()"
        if instruction.builtin == STRING_TRIM_BUILTIN:
            if (
                instruction.result is None
                or len(instruction.arguments) != 1
                or not isinstance(instruction.arguments[0].type, StringType)
                or not isinstance(instruction.result.type, StringType)
            ):
                raise LLVMBackendError("LLVM string trim requires string -> owned string")
            self._uses_string_runtime = True
            result = self._new_temp(instruction.result)
            return (
                f"{result} = call ptr @aether_string_trim("
                f"ptr {self._operand(instruction.arguments[0])})"
            )
        if instruction.builtin == STRING_SPLIT_BUILTIN:
            if (
                instruction.result is None
                or len(instruction.arguments) != 2
                or any(not isinstance(argument.type, StringType) for argument in instruction.arguments)
                or instruction.result.type != ArrayType(StringType())
            ):
                raise LLVMBackendError(
                    "LLVM string split requires (string, string) -> owned Array<string>"
                )
            self._uses_string_runtime = True
            self._uses_string_split = True
            self._uses_array_type = True
            self._uses_array_allocation = True
            result = self._new_temp(instruction.result)
            return (
                f"{result} = call ptr @aether_string_split("
                f"ptr {self._operand(instruction.arguments[0])}, "
                f"ptr {self._operand(instruction.arguments[1])})"
            )
        if instruction.builtin == READ_TEXT_BUILTIN:
            if (
                instruction.result is None
                or len(instruction.arguments) != 1
                or not isinstance(instruction.arguments[0].type, StringType)
                or instruction.result.type != StructType(FILE_READ_RESULT_TYPE)
            ):
                raise LLVMBackendError("LLVM io.readText requires string -> FileReadResult")
            self._uses_string_runtime = True
            self._uses_text_file_io = True
            result = self._new_temp(instruction.result)
            return (
                f"{result} = call %struct.{FILE_READ_RESULT_TYPE} "
                f"@aether_read_text(ptr {self._operand(instruction.arguments[0])})"
            )
        if instruction.builtin in {
            WRITE_TEXT_BUILTIN,
            WRITE_TEXT_ATOMIC_BUILTIN,
            APPEND_TEXT_BUILTIN,
        }:
            if (
                instruction.result is None
                or len(instruction.arguments) != 2
                or any(not isinstance(argument.type, StringType) for argument in instruction.arguments)
                or not isinstance(instruction.result.type, EnumType)
                or instruction.result.type.name != FILE_STATUS_TYPE
            ):
                raise LLVMBackendError("LLVM text-file write requires (string, string) -> FileStatus")
            self._uses_string_runtime = True
            self._uses_text_file_io = True
            result = self._new_temp(instruction.result)
            if instruction.builtin == WRITE_TEXT_ATOMIC_BUILTIN:
                return (
                    f"{result} = call i32 @aether_write_text_atomic("
                    f"ptr {self._operand(instruction.arguments[0])}, "
                    f"ptr {self._operand(instruction.arguments[1])})"
                )
            append = "true" if instruction.builtin == APPEND_TEXT_BUILTIN else "false"
            return (
                f"{result} = call i32 @aether_write_text("
                f"ptr {self._operand(instruction.arguments[0])}, "
                f"ptr {self._operand(instruction.arguments[1])}, i1 {append})"
            )
        if instruction.builtin in {"parseInt", "parseDouble"}:
            expected = "IntParseResult" if instruction.builtin == "parseInt" else "DoubleParseResult"
            if (
                instruction.result is None
                or len(instruction.arguments) != 1
                or not isinstance(instruction.arguments[0].type, StringType)
                or instruction.result.type != StructType(expected)
            ):
                raise LLVMBackendError(
                    f"LLVM {instruction.builtin} requires string -> struct {expected}"
                )
            self._uses_string_runtime = True
            self._uses_string_parsing = True
            result = self._new_temp(instruction.result)
            helper = "aether_parse_int" if instruction.builtin == "parseInt" else "aether_parse_double"
            return (
                f"{result} = call {llvm_type(instruction.result.type)} "
                f"@{helper}(ptr {self._operand(instruction.arguments[0])})"
            )
        if instruction.builtin == "__aether_string_byte_length":
            if (
                instruction.result is None
                or len(instruction.arguments) != 1
                or not isinstance(instruction.arguments[0].type, StringType)
                or not isinstance(instruction.result.type, IntType)
            ):
                raise LLVMBackendError("LLVM string byteLength requires string -> int")
            self._uses_string_runtime = True
            result = self._new_temp(instruction.result)
            length64 = self._synthetic_temp("string.byte_length64")
            return "\n  ".join(
                [
                    f"{length64} = call i64 @aether_string_byte_length(ptr {self._operand(instruction.arguments[0])})",
                    f"{result} = call i32 @aether_string_byte_length_to_int(i64 {length64})",
                ]
            )
        if instruction.builtin in TEXT_CODEC_BUILTINS:
            if instruction.result is None:
                raise LLVMBackendError("LLVM text codec builtin requires a result")
            signatures = {
                TEXT_BYTE_AT_BUILTIN: ((StringType(), IntType()), IntType(), "aether_text_byte_at"),
                TEXT_BYTE_SLICE_BUILTIN: ((StringType(), IntType(), IntType()), StringType(), "aether_text_byte_slice"),
                TEXT_FORMAT_INT_BUILTIN: ((IntType(),), StringType(), "aether_text_format_int"),
                TEXT_FORMAT_DOUBLE_BUILTIN: ((DoubleType(),), StringType(), "aether_text_format_double"),
                TEXT_CONCAT_FRAGMENTS_BUILTIN: ((ListType(StringType()),), StringType(), "aether_text_concat_fragments"),
            }
            expected_arguments, expected_result, helper = signatures[instruction.builtin]
            if (
                tuple(argument.type for argument in instruction.arguments) != expected_arguments
                or instruction.result.type != expected_result
            ):
                raise LLVMBackendError(
                    f"LLVM text codec builtin '{instruction.builtin}' has an invalid signature"
                )
            self._uses_string_runtime = True
            self._uses_text_codec = True
            if instruction.builtin == TEXT_CONCAT_FRAGMENTS_BUILTIN:
                self._uses_list_type = True
            result = self._new_temp(instruction.result)
            arguments = ", ".join(
                f"{llvm_type(argument.type)} {self._operand(argument)}"
                for argument in instruction.arguments
            )
            return (
                f"{result} = call {llvm_type(instruction.result.type)} "
                f"@{helper}({arguments})"
            )
        if instruction.builtin in {"__aether_retain", "__aether_release"}:
            if instruction.result is not None or len(instruction.arguments) != 1:
                raise LLVMBackendError("LLVM lifecycle builtin requires one argument and no result")
            argument = instruction.arguments[0]
            lines: list[str] = []
            self._emit_arc_value(
                lines,
                self._operand(argument),
                argument.type,
                retain=instruction.builtin == "__aether_retain",
            )
            return "\n  ".join(lines) if lines else "; trivial lifecycle"
        if instruction.builtin == "__aether_interface_copy_owned":
            if (
                instruction.result is None
                or len(instruction.arguments) != 1
                or instruction.result.type != instruction.arguments[0].type
            ):
                raise LLVMBackendError(
                    "LLVM copy_owned requires one same-typed owned result"
                )
            argument = instruction.arguments[0]
            if isinstance(argument.type, InterfaceType):
                return "\n  ".join(
                    self._print_interface_copy_owned(argument, instruction.result)
                )
            lines: list[str] = []
            copied = self._emit_arc_value(
                lines, self._operand(argument), argument.type, retain=True
            )
            result = self._new_temp(instruction.result)
            lines.append(
                f"{result} = freeze {llvm_type(argument.type)} {copied}"
            )
            return "\n  ".join(lines)
        if instruction.builtin is not None:
            return self._print_scalar_math_call(instruction)
        arguments = ", ".join(
            f"{llvm_type(argument.type)} {self._operand(argument)}"
            for argument in instruction.arguments
        )
        callee = self._global_name(instruction.function)
        if instruction.result is None:
            return f"call void {callee}({arguments})"

        return_type = llvm_type(instruction.result.type)
        if isinstance(instruction.result.type, VoidType):
            raise LLVMBackendError(
                "LLVM backend does not support assigning void call results"
            )
        result = self._new_temp(instruction.result)
        return f"{result} = call {return_type} {callee}({arguments})"

    def _emit_arc_value(
        self,
        lines: list[str],
        operand: str,
        type_: object,
        *,
        retain: bool,
    ) -> str:
        if isinstance(type_, NullableType):
            self._nullable_arc_helpers.add((type_, retain))
            operation = "retain" if retain else "release"
            if retain:
                copied = self._synthetic_temp("nullable.copy")
                lines.append(
                    f"{copied} = call {llvm_type(type_)} "
                    f"@__ae_nullable_{operation}_{aggregate_helper_suffix(type_)}("
                    f"{llvm_type(type_)} {operand})"
                )
                return copied
            lines.append(
                f"call void @__ae_nullable_{operation}_{aggregate_helper_suffix(type_)}("
                f"{llvm_type(type_)} {operand})"
            )
            return operand
        if isinstance(type_, StringType):
            self._uses_string_runtime = True
            operation = "retain" if retain else "release"
            lines.append(f"call void @aether_string_{operation}(ptr {operand})")
            return operand
        if isinstance(type_, ClassRefType):
            self._class_types.add(type_)
            operation = "retain" if retain else "release"
            lines.append(f"call void @aether_class_{operation}(ptr {operand})")
            return operand
        if isinstance(type_, InterfaceType):
            self._uses_interface_dispatch = True
            operation = "copy_owned" if retain else "drop_owned"
            carrier = self._synthetic_temp(f"interface.{operation}.carrier")
            witness = self._synthetic_temp(f"interface.{operation}.witness")
            adapter_pointer = self._synthetic_temp(
                f"interface.{operation}.adapter.ptr"
            )
            adapter = self._synthetic_temp(f"interface.{operation}.adapter")
            lines.append(
                f"{carrier} = extractvalue {llvm_type(type_)} {operand}, 0"
            )
            lines.append(
                f"{witness} = extractvalue {llvm_type(type_)} {operand}, 1"
            )
            adapter_index = 4 if retain else 5
            lines.append(
                f"{adapter_pointer} = getelementptr %AetherWitnessHeader, "
                f"ptr {witness}, i32 0, i32 {adapter_index}"
            )
            lines.append(f"{adapter} = load ptr, ptr {adapter_pointer}")
            if retain:
                copied = self._synthetic_temp("interface.copy_owned.carrier")
                lines.append(f"{copied} = call ptr {adapter}(ptr {carrier})")
                inserted = self._synthetic_temp("interface.copy_owned.inserted")
                result = self._synthetic_temp("interface.copy_owned.value")
                rendered = llvm_type(type_)
                lines.extend(
                    [
                        f"{inserted} = insertvalue {rendered} undef, ptr {copied}, 0",
                        f"{result} = insertvalue {rendered} {inserted}, ptr {witness}, 1",
                    ]
                )
                return result
            else:
                lines.append(f"call void {adapter}(ptr {carrier})")
            return operand
        if isinstance(type_, (ArrayType, ListType)):
            kind = "array" if isinstance(type_, ArrayType) else "list"
            helper = self._require_collection_object_arc_helper(
                kind,
                type_.element,
                retain=retain,
            )
            lines.append(f"call void @{helper}(ptr {operand})")
            return operand
        if isinstance(type_, StructType):
            definition = self._structs.get(type_.name)
            if definition is None:
                raise LLVMBackendError(f"LLVM has no lifecycle layout for struct {type_.name}")
            fields = list(enumerate(definition.fields))
            if not retain:
                fields.reverse()
            current = operand
            for index, (_name, field_type) in fields:
                if not self._layouts.layout(field_type).needs_destroy:
                    continue
                field = self._synthetic_temp("arc.field")
                lines.append(
                    f"{field} = extractvalue {llvm_type(type_)} {current}, {index}"
                )
                copied_field = self._emit_arc_value(
                    lines, field, field_type, retain=retain
                )
                if retain and copied_field != field:
                    updated = self._synthetic_temp("arc.struct.copy")
                    lines.append(
                        f"{updated} = insertvalue {llvm_type(type_)} {current}, "
                        f"{llvm_type(field_type)} {copied_field}, {index}"
                    )
                    current = updated
            return current
        if isinstance(type_, MethodResultType):
            fields = ((0, type_.receiver), (1, type_.value))
            ordered = fields if retain else tuple(reversed(fields))
            current = operand
            for index, field_type in ordered:
                if not self._layouts.layout(field_type).needs_destroy:
                    continue
                field = self._synthetic_temp("arc.method.field")
                lines.append(
                    f"{field} = extractvalue {llvm_type(type_)} {current}, {index}"
                )
                copied_field = self._emit_arc_value(
                    lines, field, field_type, retain=retain
                )
                if retain and copied_field != field:
                    updated = self._synthetic_temp("arc.method.copy")
                    lines.append(
                        f"{updated} = insertvalue {llvm_type(type_)} {current}, "
                        f"{llvm_type(field_type)} {copied_field}, {index}"
                    )
                    current = updated
            return current
        raise LLVMBackendError(
            f"LLVM lifecycle builtin does not support type {type_}"
        )

    def _register_class_payload_lifecycle(self) -> None:
        """Discover helpers needed only by descriptor-driven field teardown."""

        for class_type in sorted(self._class_types, key=lambda item: item.name):
            definition = self._structs.get(class_type.name)
            if definition is None:
                continue
            for _name, field_type in definition.fields:
                if not self._layouts.layout(field_type).needs_destroy:
                    continue
                self._emit_arc_value([], "undef", field_type, retain=False)

    def _emit_class_destroy_value(
        self,
        lines: list[str],
        operand: str,
        type_: object,
    ) -> None:
        if self._layouts.layout(type_).needs_destroy:
            self._emit_arc_value(lines, operand, type_, retain=False)

    def _nullable_arc_helper(
        self,
        type_: NullableType,
        *,
        retain: bool,
    ) -> str:
        operation = "retain" if retain else "release"
        name = f"__ae_nullable_{operation}_{aggregate_helper_suffix(type_)}"
        llvm = llvm_type(type_)
        return_type = llvm if retain else "void"
        lines = [
            f"define private {return_type} @{name}({llvm} %value) {{",
            "entry:",
            f"  %present = extractvalue {llvm} %value, 0",
            "  br i1 %present, label %payload, label %done",
            "payload:",
            f"  %inner = extractvalue {llvm} %value, 1",
        ]
        payload_lines: list[str] = []
        copied_inner = self._emit_arc_value(
            payload_lines,
            "%inner",
            type_.inner,
            retain=retain,
        )
        lines.extend(f"  {line}" for line in payload_lines)
        if retain:
            lines.append(
                f"  %updated = insertvalue {llvm} %value, "
                f"{llvm_type(type_.inner)} {copied_inner}, 1"
            )
        lines.extend([
            "  br label %done",
            "done:",
            (
                f"  %result = phi {llvm} [ %value, %entry ], [ %updated, %payload ]\n"
                f"  ret {llvm} %result"
                if retain
                else "  ret void"
            ),
            "}",
        ])
        return "\n".join(lines)

    def _require_collection_object_arc_helper(
        self,
        kind: str,
        element_type: object,
        *,
        retain: bool,
    ) -> str:
        self._collection_object_arc_helpers.add((kind, element_type, retain))
        operation = "retain" if retain else "release"
        return f"aether_{kind}_{operation}_{aggregate_helper_suffix(element_type)}"

    def _collection_object_arc_helper(
        self,
        kind: str,
        element_type: object,
        *,
        retain: bool,
    ) -> str:
        name = self._require_collection_object_arc_helper(
            kind,
            element_type,
            retain=retain,
        )
        layout = "%AetherArray" if kind == "array" else "%AetherList"
        strong_index = 2 if kind == "array" else 3
        data_index = 1 if kind == "array" else 2
        if retain:
            return "\n".join([
                f"define private void @{name}(ptr %object) {{",
                "entry:",
                f"  %strong_field = getelementptr {layout}, ptr %object, i32 0, i32 {strong_index}",
                "  %strong = load i64, ptr %strong_field",
                "  %valid = icmp ugt i64 %strong, 0",
                "  %overflow = icmp eq i64 %strong, 9223372036854775807",
                "  %not_overflow = xor i1 %overflow, true",
                "  %can_retain = and i1 %valid, %not_overflow",
                "  br i1 %can_retain, label %increment, label %panic",
                "panic:",
                "  call void @aether_collection_rc_panic()",
                "  unreachable",
                "increment:",
                "  %next = add nuw i64 %strong, 1",
                "  store i64 %next, ptr %strong_field",
                "  ret void",
                "}",
            ])

        rendered = llvm_type(element_type)
        element_destroy: list[str] = []
        if self._layouts.layout(element_type).needs_destroy:
            self._emit_arc_value(element_destroy, "%element", element_type, retain=False)
        destroy_region = [
            "destroy.entry:",
            f"  %length_field = getelementptr {layout}, ptr %object, i32 0, i32 0",
            "  %length = load i64, ptr %length_field",
            f"  %data_field = getelementptr {layout}, ptr %object, i32 0, i32 {data_index}",
            "  %data = load ptr, ptr %data_field",
        ]
        if element_destroy:
            destroy_region.extend([
                "  br label %destroy.loop",
                "destroy.loop:",
                "  %remaining = phi i64 [ %length, %destroy.entry ], [ %previous, %destroy.body ]",
                "  %done = icmp eq i64 %remaining, 0",
                "  br i1 %done, label %free, label %destroy.body",
                "destroy.body:",
                "  %previous = sub i64 %remaining, 1",
                f"  %element_ptr = getelementptr {rendered}, ptr %data, i64 %previous",
                f"  %element = load {rendered}, ptr %element_ptr",
                *(f"  {line}" for line in element_destroy),
                "  br label %destroy.loop",
            ])
        else:
            destroy_region.append("  br label %free")
        destroy_region.extend([
            "free:",
            "  call void @free(ptr %data)",
            "  call void @free(ptr %object)",
            "  ret void",
        ])
        return "\n".join([
            f"define private void @{name}(ptr %object) {{",
            "entry:",
            f"  %strong_field = getelementptr {layout}, ptr %object, i32 0, i32 {strong_index}",
            "  %strong = load i64, ptr %strong_field",
            "  %valid = icmp ugt i64 %strong, 0",
            "  br i1 %valid, label %decrement, label %panic",
            "panic:",
            "  call void @aether_collection_rc_panic()",
            "  unreachable",
            "decrement:",
            "  %next = sub i64 %strong, 1",
            "  store i64 %next, ptr %strong_field",
            "  %last = icmp eq i64 %next, 0",
            "  br i1 %last, label %destroy.entry, label %exit",
            *destroy_region,
            "exit:",
            "  ret void",
            "}",
        ])

    def _require_collection_copy_helper(self, kind: str, element_type: object) -> str:
        self._collection_copy_helpers.add((kind, element_type))
        return f"aether_{kind}_copy_{aggregate_helper_suffix(element_type)}"

    def _collection_copy_helper(self, kind: str, element_type: object) -> str:
        """Emit a typed element-by-element copy into a fresh RC object."""

        name = self._require_collection_copy_helper(kind, element_type)
        collection = "Array" if kind == "array" else "List"
        layout = "%AetherArray" if kind == "array" else "%AetherList"
        data_index = 1 if kind == "array" else 2
        element_layout = self._layouts.collection_element(collection, element_type)
        rendered = element_layout.llvm_type
        size = element_layout.size_operand
        assert size is not None
        allocation = "aether_array_new" if kind == "array" else "aether_list_new"
        copy_lines: list[str] = []
        copied_element = "%element"
        if element_layout.needs_retain:
            copied_element = self._emit_arc_value(
                copy_lines, "%element", element_type, retain=True
            )
        return "\n".join([
            f"define private ptr @{name}(ptr %source) {{",
            "entry:",
            f"  %source_length_field = getelementptr {layout}, ptr %source, i32 0, i32 0",
            "  %length = load i64, ptr %source_length_field",
            f"  %copy = call ptr @{allocation}(i64 {size}, i64 %length)",
            f"  %source_data_field = getelementptr {layout}, ptr %source, i32 0, i32 {data_index}",
            "  %source_data = load ptr, ptr %source_data_field",
            f"  %copy_data_field = getelementptr {layout}, ptr %copy, i32 0, i32 {data_index}",
            "  %copy_data = load ptr, ptr %copy_data_field",
            "  br label %copy.loop",
            "copy.loop:",
            "  %index = phi i64 [ 0, %entry ], [ %next, %copy.body ]",
            "  %done = icmp eq i64 %index, %length",
            "  br i1 %done, label %exit, label %copy.body",
            "copy.body:",
            f"  %source_element_ptr = getelementptr {rendered}, ptr %source_data, i64 %index",
            f"  %element = load {rendered}, ptr %source_element_ptr",
            *(f"  {line}" for line in copy_lines),
            f"  %copy_element_ptr = getelementptr {rendered}, ptr %copy_data, i64 %index",
            f"  store {rendered} {copied_element}, ptr %copy_element_ptr",
            "  %next = add i64 %index, 1",
            "  br label %copy.loop",
            "exit:",
            "  ret ptr %copy",
            "}",
        ])

    def _require_collection_arc_helper(
        self,
        kind: str,
        element_type: object,
        *,
        retain: bool,
    ) -> str:
        self._collection_arc_helpers.add((kind, element_type, retain))
        operation = "retain" if retain else "release"
        return f"aether_{kind}_{operation}_elements_{aggregate_helper_suffix(element_type)}"

    def _collection_arc_helper(
        self,
        kind: str,
        element_type: object,
        *,
        retain: bool,
    ) -> str:
        name = self._require_collection_arc_helper(kind, element_type, retain=retain)
        layout = "%AetherArray" if kind == "array" else "%AetherList"
        data_index = 1 if kind == "array" else 2
        rendered = llvm_type(element_type)
        arc_lines: list[str] = []
        updated_element = self._emit_arc_value(
            arc_lines, "%element", element_type, retain=retain
        )
        return "\n".join([
            f"define private void @{name}(ptr %sequence) {{",
            "entry:",
            f"  %length_field = getelementptr {layout}, ptr %sequence, i32 0, i32 0",
            "  %length = load i64, ptr %length_field",
            f"  %data_field = getelementptr {layout}, ptr %sequence, i32 0, i32 {data_index}",
            "  %data = load ptr, ptr %data_field",
            "  br label %loop",
            "loop:",
            "  %index = phi i64 [ 0, %entry ], [ %next, %advance ]",
            "  %done = icmp eq i64 %index, %length",
            "  br i1 %done, label %exit, label %body",
            "body:",
            f"  %element_ptr = getelementptr {rendered}, ptr %data, i64 %index",
            f"  %element = load {rendered}, ptr %element_ptr",
            *(f"  {line}" for line in arc_lines),
            *(
                [f"  store {rendered} {updated_element}, ptr %element_ptr"]
                if retain and updated_element != "%element"
                else []
            ),
            "  br label %advance",
            "advance:",
            "  %next = add i64 %index, 1",
            "  br label %loop",
            "exit:",
            "  ret void",
            "}",
        ])

    def _print_indirect_call(self, instruction: SSACallIndirect) -> str:
        if not isinstance(instruction.callee.type, FunctionType):
            raise LLVMBackendError("LLVM indirect call requires a callable callee")
        known_target = self._function_reference_targets.get(
            self._key(instruction.callee)
        )
        if known_target is not None:
            target = self._functions_by_name.get(known_target)
            if target is None or target.may_throw:
                raise LLVMBackendError(
                    f"LLVM call/invoke mismatch for indirect target '{known_target}'"
                )
        arguments = ", ".join(
            f"{llvm_type(argument.type)} {self._operand(argument)}"
            for argument in instruction.arguments
        )
        callee = self._operand(instruction.callee)
        return_type = llvm_type(instruction.callee.type.return_type)
        if instruction.result is None:
            return f"call {return_type} {callee}({arguments})"
        if isinstance(instruction.result.type, VoidType):
            raise LLVMBackendError("LLVM indirect call cannot assign a void result")
        result = self._new_temp(instruction.result)
        return f"{result} = call {return_type} {callee}({arguments})"

    def _print_scalar_math_call(self, instruction: SSACall) -> str:
        if instruction.result is None:
            raise LLVMBackendError("LLVM scalar builtin call must produce a result")
        name = instruction.builtin
        if name is None or name != instruction.function:
            raise LLVMBackendError("LLVM scalar builtin call lost its canonical identity")
        self._scalar_math_calls.add(
            (name, tuple(argument.type for argument in instruction.arguments), instruction.result.type)
        )
        result = self._new_temp(instruction.result)
        lines: list[str] = []

        if name in {"sin", "cos", "tan", "exp", "ln", "log", "sqrt"}:
            argument = self._scalar_math_as_double(instruction.arguments[0], lines)
            symbol = {
                "ln": "log",
                "log": "log10",
                "sqrt": "llvm.sqrt.f64",
            }.get(name, name)
            lines.append(f"{result} = call double @{symbol}(double {argument})")
            return "\n  ".join(lines)

        if name == "abs":
            argument = instruction.arguments[0]
            if isinstance(argument.type, IntType):
                lines.append(
                    f"{result} = call i32 @aether_checked_abs_i32(i32 {self._operand(argument)})"
                )
            elif isinstance(argument.type, DoubleType):
                lines.append(
                    f"{result} = call double @llvm.fabs.f64(double {self._operand(argument)})"
                )
            else:
                raise LLVMBackendError(f"LLVM abs does not support type {argument.type}")
            return "\n  ".join(lines)

        if name == "Math.factorial":
            argument = instruction.arguments[0]
            if not isinstance(argument.type, IntType):
                raise LLVMBackendError("LLVM Math.factorial expects i32")
            return (
                f"{result} = call i32 @aether_checked_factorial_i32(i32 {self._operand(argument)})"
            )

        if name in {"Math.floor", "Math.ceil"}:
            argument = instruction.arguments[0]
            if isinstance(argument.type, IntType):
                return f"{result} = add i32 {self._operand(argument)}, 0"
            value = self._scalar_math_as_double(argument, lines)
            operation = name.rsplit(".", 1)[1]
            lines.append(f"{result} = call i32 @aether_{operation}_to_i32(double {value})")
            return "\n  ".join(lines)

        if name == "Math.mod":
            left, right = instruction.arguments
            if isinstance(left.type, IntType) and isinstance(right.type, IntType):
                return (
                    f"{result} = call i32 @aether_floor_mod_i32("
                    f"i32 {self._operand(left)}, i32 {self._operand(right)})"
                )
            left_value = self._scalar_math_as_double(left, lines)
            right_value = self._scalar_math_as_double(right, lines)
            lines.append(
                f"{result} = call double @aether_floor_mod_f64("
                f"double {left_value}, double {right_value})"
            )
            return "\n  ".join(lines)

        raise LLVMBackendError(f"LLVM has no scalar math lowering for '{name}'")

    def _scalar_math_as_double(self, value: SSAValue, lines: list[str]) -> str:
        operand = self._operand(value)
        if isinstance(value.type, DoubleType):
            return operand
        if isinstance(value.type, IntType):
            converted = self._synthetic_temp("math.to.double")
            lines.append(f"{converted} = sitofp i32 {operand} to double")
            return converted
        raise LLVMBackendError(
            f"LLVM/native scalar math supports int/double arguments, got {value.type}"
        )

    def _print_print(self, instruction: SSAPrint) -> str:
        self._uses_print = True
        value = self._operand(instruction.value)
        call_result = self._synthetic_temp("print.result")

        if isinstance(instruction.value.type, NullableType):
            nullable_type = instruction.value.type
            self._nullable_print_types.add(nullable_type)
            newline = "true" if instruction.newline else "false"
            return (
                f"call void @{self._nullable_print_helper_name(nullable_type)}("
                f"{llvm_type(nullable_type)} {value}, i1 {newline})"
            )

        if isinstance(instruction.value.type, StructType):
            return "\n  ".join(
                self._print_struct_value(
                    instruction.value.type,
                    value,
                    newline=instruction.newline,
                )
            )

        if isinstance(instruction.value.type, (ArrayType, ListType)):
            kind = "array" if isinstance(instruction.value.type, ArrayType) else "list"
            if kind == "array":
                self._uses_array_type = True
            else:
                self._uses_list_type = True
            element_type = instruction.value.type.element
            self._layouts.collection_element(kind.capitalize(), element_type)
            self._struct_sequence_print_types.add((kind, element_type))
            helper = self._struct_sequence_print_helper_name(kind, element_type)
            newline = "true" if instruction.newline else "false"
            return f"call void @{helper}(ptr {value}, i1 {newline})"

        if isinstance(instruction.value.type, EnumType):
            lines, selected = self._enum_text_selection(instruction.value.type, value)
            lines.append(f"call void @aether_string_print(ptr {selected})")
            if instruction.newline:
                lines.append(f"{call_result} = call i32 @putchar(i32 10)")
            return "\n  ".join(lines)

        if isinstance(instruction.value.type, VectorType):
            self._uses_array_type = True
            if instruction.aggregate_shape is None or len(instruction.aggregate_shape) != 1:
                raise LLVMBackendError("LLVM Vector print requires a known length")
            element_type = instruction.value.type.element
            self._vector_print_types.add(element_type)
            if isinstance(element_type, StringType):
                self._uses_string_runtime = True
            helper = f"aether_vector_print_{aggregate_helper_suffix(element_type)}"
            column = "true" if instruction.value.type.orientation == "column" else "false"
            newline = "true" if instruction.newline else "false"
            return (
                f"call void @{helper}(ptr {value}, i64 {instruction.aggregate_shape[0]}, "
                f"i1 {column}, i1 {newline})"
            )
        if isinstance(instruction.value.type, MatrixType):
            self._uses_array_type = True
            if instruction.aggregate_shape is None or len(instruction.aggregate_shape) != 2:
                raise LLVMBackendError("LLVM Matrix print requires known dimensions")
            element_type = instruction.value.type.element
            self._matrix_print_types.add(element_type)
            if isinstance(element_type, StringType):
                self._uses_string_runtime = True
            helper = f"aether_matrix_print_{aggregate_helper_suffix(element_type)}"
            rows, columns = instruction.aggregate_shape
            newline = "true" if instruction.newline else "false"
            return (
                f"call void @{helper}(ptr {value}, i64 {rows}, i64 {columns}, i1 {newline})"
            )

        if isinstance(instruction.value.type, IntType):
            suffix = "ln" if instruction.newline else ""
            return (
                f"{call_result} = call i32 (ptr, ...) @printf("
                f"ptr @.aether.io.int{suffix}, i32 {value})"
            )
        if isinstance(instruction.value.type, DoubleType):
            newline = "true" if instruction.newline else "false"
            return f"call void @aether_print_double(double {value}, i1 {newline})"
        if isinstance(instruction.value.type, StringType):
            self._uses_string_runtime = True
            lines = [f"call void @aether_string_print(ptr {value})"]
            if instruction.newline:
                lines.append(f"{call_result} = call i32 @putchar(i32 10)")
            return "\n  ".join(lines)
        if isinstance(instruction.value.type, BoolType):
            selected = self._synthetic_temp("print.bool")
            stream = self._synthetic_temp("print.bool.stream")
            lines = [
                f"{selected} = select i1 {value}, ptr @.aether.io.true, ptr @.aether.io.false",
                f"{stream} = load ptr, ptr @stdout",
                f"{call_result} = call i32 @fputs(ptr {selected}, ptr {stream})",
            ]
            if instruction.newline:
                lines.append(f"{self._synthetic_temp('print.bool.newline')} = call i32 @putchar(i32 10)")
            return "\n  ".join(
                lines
            )
        raise LLVMBackendError(
            "LLVM print only supports int, boolean, string, and double; "
            f"got {instruction.value.type}"
        )

    def _print_struct_value(
        self,
        struct_type: StructType,
        operand: str,
        *,
        newline: bool,
    ) -> list[str]:
        definition = self._structs.get(struct_type.name)
        if definition is None:
            raise LLVMBackendError(f"LLVM has no layout for struct {struct_type.name}")
        lines: list[str] = []
        self._emit_text(lines, f"{struct_type.name}(")
        for index, (field_name, field_type) in enumerate(definition.fields):
            if index:
                self._emit_text(lines, ", ")
            self._emit_text(lines, f"{field_name}=")
            field = self._synthetic_temp("struct.print.field")
            lines.append(
                f"{field} = extractvalue {llvm_type(struct_type)} {operand}, {index}"
            )
            self._emit_printed_value(lines, field, field_type)
        self._emit_text(lines, ")\n" if newline else ")")
        return lines

    def _emit_text(self, lines: list[str], text: str) -> None:
        global_ = self._string_global(text)
        lines.append(f"call void @aether_string_print(ptr {global_.name})")

    def _emit_printed_value(self, lines: list[str], value: str, type_: object) -> None:
        result = self._synthetic_temp("struct.print.value")
        if isinstance(type_, IntType):
            lines.append(f"{result} = call i32 (ptr, ...) @printf(ptr @.aether.io.int, i32 {value})")
            return
        if isinstance(type_, DoubleType):
            lines.append(f"call void @aether_print_double(double {value}, i1 false)")
            return
        if isinstance(type_, StringType):
            self._uses_string_runtime = True
            lines.append(f"call void @aether_string_print(ptr {value})")
            return
        if isinstance(type_, BoolType):
            selected = self._synthetic_temp("struct.print.bool")
            stream = self._synthetic_temp("struct.print.stream")
            lines.extend([
                f"{selected} = select i1 {value}, ptr @.aether.io.true, ptr @.aether.io.false",
                f"{stream} = load ptr, ptr @stdout",
                f"{result} = call i32 @fputs(ptr {selected}, ptr {stream})",
            ])
            return
        if isinstance(type_, NullableType):
            self._nullable_print_types.add(type_)
            lines.append(
                f"call void @{self._nullable_print_helper_name(type_)}("
                f"{llvm_type(type_)} {value}, i1 false)"
            )
            return
        if isinstance(type_, EnumType):
            enum_lines, selected = self._enum_text_selection(type_, value)
            lines.extend(enum_lines)
            lines.append(f"call void @aether_string_print(ptr {selected})")
            return
        if isinstance(type_, StructType):
            lines.extend(self._print_struct_value(type_, value, newline=False))
            return
        if isinstance(type_, (ArrayType, ListType)):
            kind = "array" if isinstance(type_, ArrayType) else "list"
            if kind == "array":
                self._uses_array_type = True
            else:
                self._uses_list_type = True
            self._struct_sequence_print_types.add((kind, type_.element))
            helper = self._struct_sequence_print_helper_name(kind, type_.element)
            lines.append(f"call void @{helper}(ptr {value}, i1 false)")
            return
        raise LLVMBackendError(f"LLVM struct print does not support field type {type_}")

    @staticmethod
    def _nullable_print_helper_name(type_: NullableType) -> str:
        return f"__ae_print_{aggregate_helper_suffix(type_)}"

    def _nullable_print_helper(self, type_: NullableType) -> str:
        name = self._nullable_print_helper_name(type_)
        llvm = llvm_type(type_)
        lines = [
            f"define private void @{name}({llvm} %value, i1 %newline) {{",
            "entry:",
            f"  %present = extractvalue {llvm} %value, 0",
            "  br i1 %present, label %some, label %none",
            "none:",
        ]
        self._emit_text(lines, "null")
        lines.extend([
            "  br label %finish",
            "some:",
            f"  %payload = extractvalue {llvm} %value, 1",
        ])
        payload_lines: list[str] = []
        self._emit_printed_value(payload_lines, "%payload", type_.inner)
        lines.extend(f"  {line}" for line in payload_lines)
        lines.extend([
            "  br label %finish",
            "finish:",
            "  br i1 %newline, label %line, label %done",
            "line:",
            "  %newline.result = call i32 @putchar(i32 10)",
            "  br label %done",
            "done:",
            "  ret void",
            "}",
        ])
        return "\n".join(lines)

    @staticmethod
    def _struct_sequence_print_helper_name(kind: str, element_type: object) -> str:
        return f"aether_struct_{kind}_print_{aggregate_helper_suffix(element_type)}"

    def _struct_sequence_print_helper(self, kind: str, element_type: object) -> str:
        name = self._struct_sequence_print_helper_name(kind, element_type)
        layout = "%AetherArray" if kind == "array" else "%AetherList"
        data_index = 1 if kind == "array" else 2
        element_llvm = llvm_type(element_type)
        if isinstance(element_type, IntType):
            print_lines = [
                "  %printed = call i32 (ptr, ...) @printf(ptr @.aether.io.int, i32 %value)"
            ]
        elif isinstance(element_type, DoubleType):
            print_lines = [
                "  call void @aether_print_double(double %value, i1 false)"
            ]
        elif isinstance(element_type, StringType):
            self._uses_string_runtime = True
            print_lines = [
                "  %quote.open = call i32 @putchar(i32 34)",
                "  call void @aether_string_print_escaped(ptr %value)",
                "  %quote.close = call i32 @putchar(i32 34)",
            ]
        elif isinstance(element_type, BoolType):
            print_lines = [
                "  %text = select i1 %value, ptr @.aether.io.true, ptr @.aether.io.false",
                "  %stream = load ptr, ptr @stdout",
                "  %printed = call i32 @fputs(ptr %text, ptr %stream)",
            ]
        elif isinstance(element_type, EnumType):
            enum_lines, selected = self._enum_text_selection(element_type, "%value")
            print_lines = [
                *(f"  {line}" for line in enum_lines),
                f"  call void @aether_string_print(ptr {selected})",
            ]
        elif isinstance(element_type, StructType):
            print_lines = [
                f"  {line}"
                for line in self._print_struct_value(
                    element_type,
                    "%value",
                    newline=False,
                )
            ]
        elif isinstance(element_type, NullableType):
            self._nullable_print_types.add(element_type)
            print_lines = [
                f"  call void @{self._nullable_print_helper_name(element_type)}("
                f"{llvm_type(element_type)} %value, i1 false)"
            ]
        else:
            raise LLVMBackendError(
                f"LLVM sequence print does not support element type {element_type}"
            )
        return "\n".join([
            f"define private void @{name}(ptr %sequence, i1 %newline) {{",
            "entry:",
            "  %open = call i32 @putchar(i32 123)",
            f"  %length.field = getelementptr {layout}, ptr %sequence, i32 0, i32 0",
            "  %length = load i64, ptr %length.field",
            f"  %data.field = getelementptr {layout}, ptr %sequence, i32 0, i32 {data_index}",
            "  %data = load ptr, ptr %data.field",
            "  br label %loop",
            "loop:",
            "  %index = phi i64 [ 0, %entry ], [ %next, %advance ]",
            "  %done = icmp eq i64 %index, %length",
            "  br i1 %done, label %exit, label %separator",
            "separator:",
            "  %first = icmp eq i64 %index, 0",
            "  br i1 %first, label %print, label %comma",
            "comma:",
            "  %comma.char = call i32 @putchar(i32 44)",
            "  %space.char = call i32 @putchar(i32 32)",
            "  br label %print",
            "print:",
            f"  %element = getelementptr {element_llvm}, ptr %data, i64 %index",
            f"  %value = load {element_llvm}, ptr %element",
            *print_lines,
            "  br label %advance",
            "advance:",
            "  %next = add i64 %index, 1",
            "  br label %loop",
            "exit:",
            "  %close = call i32 @putchar(i32 125)",
            "  br i1 %newline, label %linebreak, label %finish",
            "linebreak:",
            "  %newline.char = call i32 @putchar(i32 10)",
            "  br label %finish",
            "finish:",
            "  ret void",
            "}",
        ])

    def _print_struct_new(self, instruction: SSAStructNew) -> list[str]:
        if not isinstance(instruction.result.type, StructType):
            raise LLVMBackendError("LLVM struct_new result must be a StructType")
        aggregate_type = llvm_type(instruction.result.type)
        result = self._new_temp(instruction.result)
        if not instruction.fields:
            return [f"{result} = freeze {aggregate_type} undef"]
        lines: list[str] = []
        current = "undef"
        for index, field in enumerate(instruction.fields):
            target = result if index == len(instruction.fields) - 1 else self._synthetic_temp("struct.new")
            lines.append(
                f"{target} = insertvalue {aggregate_type} {current}, "
                f"{llvm_type(field.type)} {self._operand(field)}, {index}"
            )
            current = target
        return lines

    def _print_struct_get(self, instruction: SSAStructGet) -> str:
        result = self._new_temp(instruction.result)
        return (
            f"{result} = extractvalue {llvm_type(instruction.struct.type)} "
            f"{self._operand(instruction.struct)}, {instruction.field_index}"
        )

    def _print_class_get(self, instruction: SSAClassGet) -> list[str]:
        if not isinstance(instruction.object.type, ClassRefType):
            raise LLVMBackendError("LLVM class_get requires a class reference")
        definition = self._structs.get(instruction.object.type.name)
        if definition is None or not 0 <= instruction.field_index < len(definition.fields):
            raise LLVMBackendError("LLVM class_get requires a canonical class field")
        pointer = self._synthetic_temp("class.field.ptr")
        result = self._new_temp(instruction.result)
        return [
            f"{pointer} = getelementptr "
            f"{class_object_type(instruction.object.type)}, "
            f"ptr {self._operand(instruction.object)}, i32 0, "
            f"i32 {instruction.field_index + 1}",
            f"{result} = load {llvm_type(instruction.result.type)}, ptr {pointer}",
        ]

    def _print_class_set(self, instruction: SSAClassSet) -> list[str]:
        if not isinstance(instruction.object.type, ClassRefType):
            raise LLVMBackendError("LLVM class_set requires a class reference")
        definition = self._structs.get(instruction.object.type.name)
        if definition is None or not 0 <= instruction.field_index < len(definition.fields):
            raise LLVMBackendError("LLVM class_set requires a canonical class field")
        field_type = definition.fields[instruction.field_index][1]
        pointer = self._synthetic_temp("class.field.ptr")
        lines = [
            f"{pointer} = getelementptr "
            f"{class_object_type(instruction.object.type)}, "
            f"ptr {self._operand(instruction.object)}, i32 0, "
            f"i32 {instruction.field_index + 1}"
        ]
        needs_destroy = self._layouts.layout(field_type).needs_destroy
        stored_value = self._operand(instruction.value)
        if needs_destroy:
            stored_value = self._emit_arc_value(
                lines,
                stored_value,
                field_type,
                retain=True,
            )
        old: str | None = None
        if needs_destroy and not instruction.initialize:
            old = self._synthetic_temp("class.field.old")
            lines.append(f"{old} = load {llvm_type(field_type)}, ptr {pointer}")
        lines.append(
            f"store {llvm_type(field_type)} {stored_value}, "
            f"ptr {pointer}"
        )
        if instruction.initialize:
            initialized_pointer = self._synthetic_temp("class.field.initialized.ptr")
            lines.extend(
                [
                    f"{initialized_pointer} = getelementptr "
                    f"{class_object_type(instruction.object.type)}, "
                    f"ptr {self._operand(instruction.object)}, i32 0, "
                    f"i32 {len(definition.fields) + 1}, "
                    f"i32 {instruction.field_index}",
                    f"store i1 true, ptr {initialized_pointer}",
                ]
            )
        if old is not None:
            self._emit_arc_value(lines, old, field_type, retain=False)
        return lines

    def _print_interface_construct(
        self,
        instruction: SSAInterfaceConstruct,
    ) -> list[str]:
        if not isinstance(instruction.result.type, InterfaceType):
            raise LLVMBackendError(
                "LLVM interface_construct result must be an InterfaceType"
            )
        if not isinstance(instruction.carrier.type, (ClassRefType, StructType)):
            raise LLVMBackendError(
                "LLVM interface_construct requires a class or struct carrier"
            )
        existing = self._witnesses.get(instruction.witness.symbol)
        if existing is not None and existing != instruction.witness:
            raise LLVMBackendError(
                f"LLVM witness symbol collision for {instruction.witness.symbol}"
            )
        self._witnesses[instruction.witness.symbol] = instruction.witness
        result_type = llvm_type(instruction.result.type)
        carrier = self._operand(instruction.carrier)
        lines: list[str] = []
        if isinstance(instruction.carrier.type, StructType):
            layout = instruction.witness.box_layout
            if instruction.witness.carrier_kind != "box" or layout is None:
                raise LLVMBackendError(
                    "LLVM struct-backed interface requires canonical box metadata"
                )
            self._uses_interface_boxing = True
            box_type = box_type_symbol(
                instruction.witness.interface_id,
                instruction.witness.concrete_type_id,
            )
            box_size = (
                f"ptrtoint (ptr getelementptr ({box_type}, ptr null, i64 1) to i64)"
            )
            box = self._synthetic_temp("interface.box")
            size_ptr = self._synthetic_temp("interface.box.size.ptr")
            alignment_ptr = self._synthetic_temp("interface.box.alignment.ptr")
            offset_ptr = self._synthetic_temp("interface.box.offset.ptr")
            payload_ptr = self._synthetic_temp("interface.box.payload.ptr")
            lines.extend(
                [
                    f"{box} = call ptr @aether_alloc(i64 {box_size})",
                    f"{size_ptr} = getelementptr {box_type}, ptr {box}, i32 0, i32 0",
                    f"store i64 {layout.payload_size}, ptr {size_ptr}",
                    f"{alignment_ptr} = getelementptr {box_type}, ptr {box}, i32 0, i32 1",
                    f"store i32 {layout.payload_alignment}, ptr {alignment_ptr}",
                    f"{offset_ptr} = getelementptr {box_type}, ptr {box}, i32 0, i32 2",
                    f"store i32 {layout.payload_offset}, ptr {offset_ptr}",
                ]
            )
            carrier = self._emit_arc_value(
                lines, carrier, instruction.carrier.type, retain=True
            )
            lines.extend(
                [
                    f"{payload_ptr} = getelementptr {box_type}, ptr {box}, i32 0, i32 4",
                    f"store {llvm_type(instruction.carrier.type)} {carrier}, ptr {payload_ptr}",
                ]
            )
            carrier = box
        carrier_insert = self._synthetic_temp("interface.carrier")
        result = self._new_temp(instruction.result)
        lines.extend([
            f"{carrier_insert} = insertvalue {result_type} undef, "
            f"ptr {carrier}, 0",
            f"{result} = insertvalue {result_type} {carrier_insert}, "
            f"ptr @{instruction.witness.symbol}, 1",
        ])
        return lines

    def _print_interface_copy_owned(
        self,
        source: SSAValue,
        result_value: SSAValue,
    ) -> list[str]:
        rendered = llvm_type(source.type)
        source_operand = self._operand(source)
        carrier = self._synthetic_temp("interface.copy.carrier")
        witness = self._synthetic_temp("interface.copy.witness")
        adapter_pointer = self._synthetic_temp("interface.copy.adapter.ptr")
        adapter = self._synthetic_temp("interface.copy.adapter")
        copied_carrier = self._synthetic_temp("interface.copy.carrier.new")
        inserted = self._synthetic_temp("interface.copy.inserted")
        result = self._new_temp(result_value)
        self._uses_interface_dispatch = True
        return [
            f"{carrier} = extractvalue {rendered} {source_operand}, 0",
            f"{witness} = extractvalue {rendered} {source_operand}, 1",
            f"{adapter_pointer} = getelementptr %AetherWitnessHeader, "
            f"ptr {witness}, i32 0, i32 4",
            f"{adapter} = load ptr, ptr {adapter_pointer}",
            f"{copied_carrier} = call ptr {adapter}(ptr {carrier})",
            f"{inserted} = insertvalue {rendered} undef, ptr {copied_carrier}, 0",
            f"{result} = insertvalue {rendered} {inserted}, ptr {witness}, 1",
        ]

    def _print_interface_call(
        self,
        instruction: SSAInterfaceCall,
    ) -> list[str]:
        if not isinstance(instruction.receiver.type, InterfaceType):
            raise LLVMBackendError(
                "LLVM interface_call receiver must have interface type"
            )
        self._uses_interface_dispatch = True
        if instruction.slot.may_throw:
            raise LLVMBackendError(
                f"LLVM call/invoke mismatch for potentially throwing interface slot "
                f"'{instruction.slot.method_id}'"
            )
        if instruction.slot.receiver_ownership != "borrowed":
            raise LLVMBackendError(
                "LLVM interface_call receiver must use borrowed erased ABI"
            )
        rendered_interface = llvm_type(instruction.receiver.type)
        receiver = self._operand(instruction.receiver)
        carrier = self._synthetic_temp("interface.call.carrier")
        witness = self._synthetic_temp("interface.call.witness")
        slots = self._synthetic_temp("interface.call.slots")
        slot_pointer = self._synthetic_temp("interface.call.slot")
        thunk_pointer = self._synthetic_temp("interface.call.thunk.ptr")
        thunk = self._synthetic_temp("interface.call.thunk")
        lines = [
            f"{carrier} = extractvalue {rendered_interface} {receiver}, 0",
            f"{witness} = extractvalue {rendered_interface} {receiver}, 1",
            f"{slots} = getelementptr %AetherWitnessHeader, "
            f"ptr {witness}, i32 1",
            f"{slot_pointer} = getelementptr %AetherWitnessSlot, "
            f"ptr {slots}, i64 {instruction.slot.index}",
            f"{thunk_pointer} = getelementptr %AetherWitnessSlot, "
            f"ptr {slot_pointer}, i32 0, i32 2",
            f"{thunk} = load ptr, ptr {thunk_pointer}",
        ]
        arguments = ", ".join(
            [
                f"ptr {carrier}",
                *[
                    f"{llvm_type(argument.type)} {self._operand(argument)}"
                    for argument in instruction.arguments
                ],
            ]
        )
        return_type = llvm_type(instruction.slot.return_type)
        if instruction.result is None:
            lines.append(f"call {return_type} {thunk}({arguments})")
        else:
            result = self._new_temp(instruction.result)
            lines.append(f"{result} = call {return_type} {thunk}({arguments})")
        return lines

    def _print_struct_set(self, instruction: SSAStructSet) -> str:
        result = self._new_temp(instruction.result)
        return (
            f"{result} = insertvalue {llvm_type(instruction.struct.type)} "
            f"{self._operand(instruction.struct)}, {llvm_type(instruction.value.type)} "
            f"{self._operand(instruction.value)}, {instruction.field_index}"
        )

    def _print_method_result_new(self, instruction: SSAMethodResultNew) -> list[str]:
        if not isinstance(instruction.result.type, MethodResultType):
            raise LLVMBackendError("LLVM method_result requires MethodResultType")
        result_type = llvm_type(instruction.result.type)
        receiver_insert = (
            self._new_temp(instruction.result)
            if instruction.value is None
            else self._synthetic_temp("method.result.receiver")
        )
        lines = [
            f"{receiver_insert} = insertvalue {result_type} undef, "
            f"{llvm_type(instruction.receiver.type)} {self._operand(instruction.receiver)}, 0"
        ]
        if instruction.value is not None:
            result = self._new_temp(instruction.result)
            lines.append(
                f"{result} = insertvalue {result_type} {receiver_insert}, "
                f"{llvm_type(instruction.value.type)} {self._operand(instruction.value)}, 1"
            )
        return lines

    def _print_method_result_receiver(self, instruction: SSAMethodResultReceiver) -> str:
        result = self._new_temp(instruction.result)
        return (
            f"{result} = extractvalue {llvm_type(instruction.method_result.type)} "
            f"{self._operand(instruction.method_result)}, 0"
        )

    def _print_method_result_value(self, instruction: SSAMethodResultValue) -> str:
        result = self._new_temp(instruction.result)
        return (
            f"{result} = extractvalue {llvm_type(instruction.method_result.type)} "
            f"{self._operand(instruction.method_result)}, 1"
        )

    def _print_array_new(self, instruction: SSAArrayNew) -> str:
        if not isinstance(instruction.result.type, ArrayType):
            raise LLVMBackendError("LLVM array_new result must be ArrayType")
        return self._print_contiguous_new(
            instruction.result,
            instruction.result.type.element,
            instruction.elements,
        )

    def _print_array_copy(self, instruction: SSAArrayCopy) -> str:
        if not isinstance(instruction.array.type, ArrayType):
            raise LLVMBackendError("LLVM array_copy expects an ArrayType source")
        if instruction.result.type != instruction.array.type:
            raise LLVMBackendError("LLVM array_copy result type must match source type")
        self._uses_array_type = True
        self._uses_array_allocation = True
        result = self._new_temp(instruction.result)
        helper = self._require_collection_copy_helper(
            "array", instruction.array.type.element
        )
        return f"{result} = call ptr @{helper}(ptr {self._operand(instruction.array)})"

    def _print_list_new(self, instruction: SSAListNew) -> str:
        if not isinstance(instruction.result.type, ListType):
            raise LLVMBackendError("LLVM list_new result must be ListType")
        self._uses_list_type = True
        self._uses_list_allocation = True

        layout = self._layouts.collection_element("List", instruction.result.type.element)
        element_type = layout.llvm_type
        element_size = layout.size_operand
        assert element_size is not None
        length = len(instruction.elements)
        result = self._new_temp(instruction.result)
        data = self._synthetic_temp("list.data")
        data_field = self._synthetic_temp("list.data.field")
        lines = [
            f"{result} = call ptr @aether_list_new(i64 {element_size}, i64 {length})",
        ]
        lines.extend(self._load_list_data(data, result, data_field))

        def emit_element(index: int) -> None:
            element = instruction.elements[index]
            element_ptr = self._synthetic_temp("list.elem")
            lines.append(
                self._element_pointer_line(element_ptr, element_type, data, index)
            )
            stored = self._operand(element)
            if layout.needs_retain:
                stored = self._emit_arc_value(
                    lines, stored, element.type, retain=True
                )
            lines.append(self._store_element_line(element_type, stored, element_ptr))

        self._for_each_element(length, emit_element)
        return "\n  ".join(lines)

    def _print_list_copy(self, instruction: SSAListCopy) -> str:
        if not isinstance(instruction.list_value.type, ListType):
            raise LLVMBackendError("LLVM list_copy expects a ListType source")
        if instruction.result.type != instruction.list_value.type:
            raise LLVMBackendError("LLVM list_copy result type must match source type")
        self._uses_list_type = True
        self._uses_list_allocation = True
        result = self._new_temp(instruction.result)
        helper = self._require_collection_copy_helper(
            "list", instruction.list_value.type.element
        )
        return f"{result} = call ptr @{helper}(ptr {self._operand(instruction.list_value)})"

    def _print_list_contains(self, instruction: SSAListContains) -> str:
        if not isinstance(instruction.list_value.type, ListType):
            raise LLVMBackendError("LLVM list_contains expects a ListType source")
        if instruction.value.type != instruction.list_value.type.element:
            raise LLVMBackendError("LLVM list_contains value type must match list element type")
        self._uses_list_type = True
        self._list_contains_types.add(instruction.value.type)
        self._require_equality_helper(instruction.value.type)
        if isinstance(instruction.value.type, StringType):
            self._uses_string_runtime = True
        result = self._new_temp(instruction.result)
        helper = list_contains_helper_name(instruction.value.type)
        value_type = llvm_type(instruction.value.type)
        return (
            f"{result} = call i1 @{helper}(ptr {self._operand(instruction.list_value)}, "
            f"{value_type} {self._operand(instruction.value)})"
        )

    def _print_list_index_of(self, instruction: SSAListIndexOf) -> str:
        if not isinstance(instruction.list_value.type, ListType):
            raise LLVMBackendError("LLVM list_index_of expects a ListType source")
        if instruction.value.type != instruction.list_value.type.element:
            raise LLVMBackendError("LLVM list_index_of value type must match list element type")
        self._uses_list_type = True
        self._list_index_of_types.add(instruction.value.type)
        self._require_equality_helper(instruction.value.type)
        if isinstance(instruction.value.type, StringType):
            self._uses_string_runtime = True
        result = self._new_temp(instruction.result)
        helper = list_index_of_helper_name(instruction.value.type)
        value_type = llvm_type(instruction.value.type)
        return (
            f"{result} = call i32 @{helper}(ptr {self._operand(instruction.list_value)}, "
            f"{value_type} {self._operand(instruction.value)})"
        )

    def _print_list_reverse(self, instruction: SSAListReverse) -> str:
        if not isinstance(instruction.list_value.type, ListType):
            raise LLVMBackendError("LLVM list_reverse expects a ListType source")
        self._uses_list_type = True
        self._uses_list_reverse = True
        size = self._sizeof(instruction.list_value.type.element, collection="List")
        return f"call void @aether_list_reverse(ptr {self._operand(instruction.list_value)}, i64 {size})"

    def _print_list_clear(self, instruction: SSAListClear) -> str:
        if not isinstance(instruction.list_value.type, ListType):
            raise LLVMBackendError("LLVM list_clear expects a ListType source")
        self._uses_list_type = True
        length_field = self._synthetic_temp("list.clear.length_field")
        lines: list[str] = []
        element_type = instruction.list_value.type.element
        if self._layouts.layout(element_type).needs_destroy:
            helper = self._require_collection_arc_helper("list", element_type, retain=False)
            lines.append(f"call void @{helper}(ptr {self._operand(instruction.list_value)})")
        lines.extend(
            self._store_list_length(
                "0", self._operand(instruction.list_value), length_field
            )
        )
        return "\n  ".join(lines)

    def _print_list_push(self, instruction: SSAListPush) -> list[str]:
        if not isinstance(instruction.list_value.type, ListType):
            raise LLVMBackendError("LLVM list_push expects a ListType source")
        if instruction.value.type != instruction.list_value.type.element:
            raise LLVMBackendError("LLVM list_push value type must match list element type")
        self._uses_list_type = True
        self._uses_list_push = True
        list_value = self._operand(instruction.list_value)
        element_type = llvm_type(instruction.value.type)
        element_size = self._sizeof(instruction.value.type, collection="List")
        old_length = self._synthetic_temp("list.push.old_length")
        data_field = self._synthetic_temp("list.push.data_field")
        data = self._synthetic_temp("list.push.data")
        element_ptr = self._synthetic_temp("list.push.element")
        new_length = self._synthetic_temp("list.push.new_length")
        length_field = self._synthetic_temp("list.push.length_field")
        lines = [
            f"{old_length} = call i64 @aether_list_prepare_push(ptr {list_value}, i64 {element_size})",
            *self._load_list_data(data, list_value, data_field),
            f"{element_ptr} = getelementptr {element_type}, ptr {data}, i64 {old_length}",
        ]
        stored = self._operand(instruction.value)
        if self._layouts.layout(instruction.value.type).needs_retain:
            stored = self._emit_arc_value(
                lines, stored, instruction.value.type, retain=True
            )
        lines.extend([
            f"store {element_type} {stored}, ptr {element_ptr}",
            f"{new_length} = add i64 {old_length}, 1",
            *self._store_list_length(new_length, list_value, length_field),
        ])
        return lines

    def _print_list_insert(self, instruction: SSAListInsert) -> list[str]:
        if not isinstance(instruction.list_value.type, ListType):
            raise LLVMBackendError("LLVM list_insert expects a ListType source")
        if not isinstance(instruction.index.type, IntType):
            raise LLVMBackendError("LLVM list_insert index must be int")
        if instruction.value.type != instruction.list_value.type.element:
            raise LLVMBackendError("LLVM list_insert value type must match list element type")
        self._uses_list_type = True
        self._uses_list_insert = True
        list_value = self._operand(instruction.list_value)
        index = self._operand(instruction.index)
        element_type = llvm_type(instruction.value.type)
        element_size = self._sizeof(instruction.value.type, collection="List")
        index64 = self._synthetic_temp("list.insert.index64")
        old_length = self._synthetic_temp("list.insert.old_length")
        data_field = self._synthetic_temp("list.insert.data_field")
        data = self._synthetic_temp("list.insert.data")
        source = self._synthetic_temp("list.insert.source")
        destination = self._synthetic_temp("list.insert.destination")
        elements_to_move = self._synthetic_temp("list.insert.elements_to_move")
        bytes_to_move = self._synthetic_temp("list.insert.bytes_to_move")
        element_ptr = self._synthetic_temp("list.insert.element")
        new_length = self._synthetic_temp("list.insert.new_length")
        length_field = self._synthetic_temp("list.insert.length_field")
        lines = [
            self._list_index64_line(index64, index),
            f"{old_length} = call i64 @aether_list_prepare_insert(ptr {list_value}, i64 {index64}, i64 {element_size})",
            *self._load_list_data(data, list_value, data_field),
            f"{source} = getelementptr {element_type}, ptr {data}, i64 {index64}",
            f"{destination} = getelementptr {element_type}, ptr {source}, i64 1",
            f"{elements_to_move} = sub i64 {old_length}, {index64}",
            f"{bytes_to_move} = mul i64 {elements_to_move}, {element_size}",
            f"call void @llvm.memmove.p0.p0.i64(ptr {destination}, ptr {source}, i64 {bytes_to_move}, i1 false)",
            f"{element_ptr} = getelementptr {element_type}, ptr {data}, i64 {index64}",
        ]
        stored = self._operand(instruction.value)
        if self._layouts.layout(instruction.value.type).needs_retain:
            stored = self._emit_arc_value(
                lines, stored, instruction.value.type, retain=True
            )
        lines.extend([
            f"store {element_type} {stored}, ptr {element_ptr}",
            f"{new_length} = add i64 {old_length}, 1",
            *self._store_list_length(new_length, list_value, length_field),
        ])
        return lines

    def _print_list_pop(self, instruction: SSAListPop) -> list[str]:
        if not isinstance(instruction.list_value.type, ListType):
            raise LLVMBackendError("LLVM list_pop expects a ListType source")
        if instruction.result.type != instruction.list_value.type.element:
            raise LLVMBackendError("LLVM list_pop result type must match list element type")
        self._uses_list_type = True
        self._uses_list_pop = True
        list_value = self._operand(instruction.list_value)
        element_type = llvm_type(instruction.result.type)
        new_length = self._synthetic_temp("list.pop.new_length")
        data_field = self._synthetic_temp("list.pop.data_field")
        data = self._synthetic_temp("list.pop.data")
        element_ptr = self._synthetic_temp("list.pop.element")
        result = self._new_temp(instruction.result)
        length_field = self._synthetic_temp("list.pop.length_field")
        return [
            f"{new_length} = call i64 @aether_list_prepare_pop(ptr {list_value})",
            *self._load_list_data(data, list_value, data_field),
            f"{element_ptr} = getelementptr {element_type}, ptr {data}, i64 {new_length}",
            f"{result} = load {element_type}, ptr {element_ptr}",
            *self._store_list_length(new_length, list_value, length_field),
        ]

    def _print_list_remove_at(self, instruction: SSAListRemoveAt) -> list[str]:
        if not isinstance(instruction.list_value.type, ListType):
            raise LLVMBackendError("LLVM list_remove_at expects a ListType source")
        if not isinstance(instruction.index.type, IntType):
            raise LLVMBackendError("LLVM list_remove_at index must be int")
        if instruction.result.type != instruction.list_value.type.element:
            raise LLVMBackendError("LLVM list_remove_at result type must match list element type")
        self._uses_list_type = True
        self._uses_list_remove_at = True
        list_value = self._operand(instruction.list_value)
        index = self._operand(instruction.index)
        element_type = llvm_type(instruction.result.type)
        element_size = self._sizeof(instruction.result.type, collection="List")
        index64 = self._synthetic_temp("list.remove_at.index64")
        old_length = self._synthetic_temp("list.remove_at.old_length")
        new_length = self._synthetic_temp("list.remove_at.new_length")
        data_field = self._synthetic_temp("list.remove_at.data_field")
        data = self._synthetic_temp("list.remove_at.data")
        removed_ptr = self._synthetic_temp("list.remove_at.removed")
        result = self._new_temp(instruction.result)
        source = self._synthetic_temp("list.remove_at.source")
        elements_to_move = self._synthetic_temp("list.remove_at.elements_to_move")
        bytes_to_move = self._synthetic_temp("list.remove_at.bytes_to_move")
        length_field = self._synthetic_temp("list.remove_at.length_field")
        return [
            self._list_index64_line(index64, index),
            f"{old_length} = call i64 @aether_list_prepare_remove_at(ptr {list_value}, i64 {index64}, i64 {element_size})",
            f"{new_length} = sub i64 {old_length}, 1",
            *self._load_list_data(data, list_value, data_field),
            f"{removed_ptr} = getelementptr {element_type}, ptr {data}, i64 {index64}",
            f"{result} = load {element_type}, ptr {removed_ptr}",
            f"{source} = getelementptr {element_type}, ptr {removed_ptr}, i64 1",
            f"{elements_to_move} = sub i64 {new_length}, {index64}",
            f"{bytes_to_move} = mul i64 {elements_to_move}, {element_size}",
            f"call void @llvm.memmove.p0.p0.i64(ptr {removed_ptr}, ptr {source}, i64 {bytes_to_move}, i1 false)",
            *self._store_list_length(new_length, list_value, length_field),
        ]

    def _print_sequence_sort(self, instruction: SSASequenceSort) -> str:
        sequence_type = instruction.sequence.type
        if not isinstance(sequence_type, (ArrayType, ListType)):
            raise LLVMBackendError("LLVM sequence_sort expects an ArrayType or ListType source")
        element_type = sequence_type.element
        helper = sequence_sort_helper_name(element_type)
        self._sequence_sort_types.add(element_type)
        if isinstance(element_type, StringType):
            self._uses_string_runtime = True
        sequence = self._operand(instruction.sequence)
        data = self._synthetic_temp("sort.data")
        length = self._synthetic_temp("sort.length")
        if isinstance(sequence_type, ArrayType):
            self._uses_array_type = True
            lines = self._array_data_pointer(data, sequence)
            lines.extend(self._array_length64(length, sequence))
        else:
            self._uses_list_type = True
            lines = self._list_data_pointer(data, sequence)
            lines.extend(self._list_length64(length, sequence))
        lines.append(f"call void @{helper}(ptr {data}, i64 {length})")
        return "\n  ".join(lines)

    def _print_vector_new(self, instruction: SSAVectorNew) -> str:
        if not isinstance(instruction.result.type, VectorType):
            raise LLVMBackendError("LLVM vector_new result must be VectorType")
        if instruction.result.type.orientation not in {"row", "column"}:
            raise LLVMBackendError("LLVM vector_new requires row or column orientation")
        if instruction.orientation != instruction.result.type.orientation:
            raise LLVMBackendError("LLVM vector_new instruction orientation must match result type")
        return self._print_contiguous_new(
            instruction.result,
            instruction.result.type.element,
            instruction.elements,
        )

    def _print_matrix_new(self, instruction: SSAMatrixNew) -> str:
        if not isinstance(instruction.result.type, MatrixType):
            raise LLVMBackendError("LLVM matrix_new result must be MatrixType")
        if instruction.rows <= 0 or instruction.cols <= 0:
            raise LLVMBackendError("LLVM matrix_new requires positive dimensions")
        if len(instruction.elements) != instruction.rows * instruction.cols:
            raise LLVMBackendError("LLVM matrix_new element count must match dimensions")
        return self._print_contiguous_new(
            instruction.result,
            instruction.result.type.element,
            instruction.elements,
        )

    def _print_vector_add(self, instruction: SSAVectorAdd) -> list[str]:
        self._validate_vector_binary(instruction, "add")
        return self._print_contiguous_binary(
            instruction.result,
            instruction.left,
            instruction.right,
            instruction.result.type.element,
            instruction.length,
            "add",
        )

    def _print_vector_sub(self, instruction: SSAVectorSub) -> list[str]:
        self._validate_vector_binary(instruction, "sub")
        return self._print_contiguous_binary(
            instruction.result,
            instruction.left,
            instruction.right,
            instruction.result.type.element,
            instruction.length,
            "sub",
        )

    def _validate_vector_binary(
        self,
        instruction: SSAVectorAdd | SSAVectorSub,
        operation: str,
    ) -> None:
        if not isinstance(instruction.result.type, VectorType):
            raise LLVMBackendError(f"LLVM vector_{operation} result must be VectorType")
        if instruction.result.type != instruction.left.type or instruction.result.type != instruction.right.type:
            raise LLVMBackendError(f"LLVM vector_{operation} requires matching vector operand and result types")
        if instruction.length <= 0:
            raise LLVMBackendError(f"LLVM vector_{operation} requires a positive length")
        if instruction.orientation != instruction.result.type.orientation:
            raise LLVMBackendError(f"LLVM vector_{operation} instruction orientation must match result type")

    def _print_vector_scale(self, instruction: SSAVectorScale) -> list[str]:
        self._validate_vector_scale(instruction)
        return self._print_contiguous_scale(
            instruction.result,
            instruction.vector,
            instruction.scalar,
            instruction.result.type.element,
            instruction.length,
            "vector.scale",
        )

    def _validate_vector_scale(self, instruction: SSAVectorScale) -> None:
        if not isinstance(instruction.result.type, VectorType):
            raise LLVMBackendError("LLVM vector_scale result must be VectorType")
        if instruction.result.type != instruction.vector.type:
            raise LLVMBackendError("LLVM vector_scale requires matching vector operand and result types")
        if instruction.scalar.type != instruction.result.type.element:
            raise LLVMBackendError("LLVM vector_scale scalar type must match vector element type")
        if instruction.length <= 0:
            raise LLVMBackendError("LLVM vector_scale requires a positive length")
        if instruction.orientation != instruction.result.type.orientation:
            raise LLVMBackendError("LLVM vector_scale instruction orientation must match result type")

    def _print_vector_dot(self, instruction: SSAVectorDot) -> list[str]:
        self._validate_vector_dot(instruction)
        self._uses_array_type = True

        result = self._new_temp(instruction.result)
        result_type = llvm_type(instruction.result.type)
        left_element_type = llvm_type(instruction.left.type.element)
        right_element_type = llvm_type(instruction.right.type.element)
        multiply_operator = self._element_binary_operator(instruction.result.type, "mul")
        add_operator = self._element_binary_operator(instruction.result.type, "add")
        zero = "0.0" if isinstance(instruction.result.type, DoubleType) else "0"
        labels = self._linear_loop_labels("vector.dot")

        left_field = self._synthetic_temp("vector.dot.left.data.field")
        left_data = self._synthetic_temp("vector.dot.left.data")
        right_data = self._synthetic_temp("vector.dot.right.data")
        acc_ptr = self._synthetic_temp("vector.dot.acc.ptr")
        index_ptr = self._synthetic_temp("vector.dot.index.ptr")
        lines = [
            LLVMArrayRuntime.data_pointer_line(left_field, self._operand(instruction.left), indent="  "),
            f"  {left_data} = load ptr, ptr {left_field}",
        ]
        right_field = self._synthetic_temp("vector.dot.right.data.field")
        lines.extend(
            [
                LLVMArrayRuntime.data_pointer_line(right_field, self._operand(instruction.right), indent="  "),
                f"  {right_data} = load ptr, ptr {right_field}",
                f"  {acc_ptr} = alloca {result_type}",
                f"  store {result_type} {zero}, ptr {acc_ptr}",
                f"  {index_ptr} = alloca i64",
                f"  store i64 0, ptr {index_ptr}",
                f"  br label %{labels.loop}",
                f"{labels.loop}:",
            ]
        )
        index = self._synthetic_temp("vector.dot.index")
        condition = self._synthetic_temp("vector.dot.cond")
        lines.extend(
            self._linear_loop_check(
                index,
                index_ptr,
                condition,
                instruction.length,
                labels,
                indent="  ",
            )
        )

        left_ptr = self._synthetic_temp("vector.dot.left.elem")
        right_ptr = self._synthetic_temp("vector.dot.right.elem")
        loaded_left = self._synthetic_temp("vector.dot.left")
        loaded_right = self._synthetic_temp("vector.dot.right")
        lines.extend(
            [
                self._element_pointer_line(left_ptr, left_element_type, left_data, index, indent="  "),
                self._load_element_line(loaded_left, left_element_type, left_ptr, indent="  "),
                self._element_pointer_line(right_ptr, right_element_type, right_data, index, indent="  "),
                self._load_element_line(loaded_right, right_element_type, right_ptr, indent="  "),
            ]
        )
        left_operand = self._coerce_scalar(lines, loaded_left, instruction.left.type.element, instruction.result.type, "vector.dot.left.cast")
        right_operand = self._coerce_scalar(lines, loaded_right, instruction.right.type.element, instruction.result.type, "vector.dot.right.cast")
        product = self._synthetic_temp("vector.dot.product")
        acc_current = self._synthetic_temp("vector.dot.acc")
        acc_next = self._synthetic_temp("vector.dot.acc.next")
        index_next = self._synthetic_temp("vector.dot.index.next")
        lines.extend(
            [
                f"  {product} = {multiply_operator} {result_type} {left_operand}, {right_operand}",
                f"  {acc_current} = load {result_type}, ptr {acc_ptr}",
                f"  {acc_next} = {add_operator} {result_type} {acc_current}, {product}",
                f"  store {result_type} {acc_next}, ptr {acc_ptr}",
                f"  {index_next} = add i64 {index}, 1",
                f"  store i64 {index_next}, ptr {index_ptr}",
                f"  br label %{labels.loop}",
                f"{labels.exit}:",
                f"  {result} = load {result_type}, ptr {acc_ptr}",
            ]
        )
        return lines

    def _validate_vector_dot(self, instruction: SSAVectorDot) -> None:
        if not isinstance(instruction.left.type, VectorType) or not isinstance(instruction.right.type, VectorType):
            raise LLVMBackendError("LLVM vector_dot expects vector operands")
        if instruction.left.type.orientation != "row" or instruction.right.type.orientation != "column":
            raise LLVMBackendError("LLVM vector_dot is only defined for Vector<Row> * Vector<Column>")
        if instruction.length <= 0:
            raise LLVMBackendError("LLVM vector_dot requires a positive length")
        if not isinstance(instruction.result.type, (IntType, DoubleType)):
            raise LLVMBackendError("LLVM vector_dot only supports int or double results")
        if not isinstance(instruction.left.type.element, (IntType, DoubleType)):
            raise LLVMBackendError("LLVM vector_dot only supports int or double left elements")
        if not isinstance(instruction.right.type.element, (IntType, DoubleType)):
            raise LLVMBackendError("LLVM vector_dot only supports int or double right elements")

    def _print_outer_product(self, instruction: SSAOuterProduct) -> list[str]:
        self._validate_outer_product(instruction)
        self._uses_array_type = True
        self._uses_array_allocation = True

        result = self._new_temp(instruction.result)
        result_element_type = llvm_type(instruction.result.type.element)
        result_element_size = self._sizeof(instruction.result.type.element)
        column_element_type = llvm_type(instruction.column.type.element)
        row_element_type = llvm_type(instruction.row.type.element)
        multiply_operator = self._element_binary_operator(instruction.result.type.element, "mul")
        labels = self._double_loop_labels("outer.product")
        length = instruction.rows * instruction.cols

        column_field = self._synthetic_temp("outer.product.column.data.field")
        column_data = self._synthetic_temp("outer.product.column.data")
        row_field = self._synthetic_temp("outer.product.row.data.field")
        row_data = self._synthetic_temp("outer.product.row.data")
        result_field = self._synthetic_temp("outer.product.result.data.field")
        result_data = self._synthetic_temp("outer.product.result.data")
        row_index_ptr = self._synthetic_temp("outer.product.row.index.ptr")
        col_index_ptr = self._synthetic_temp("outer.product.col.index.ptr")
        lines = [
            f"  {result} = call ptr @aether_array_new(i64 {result_element_size}, i64 {length})",
            LLVMArrayRuntime.data_pointer_line(column_field, self._operand(instruction.column), indent="  "),
            f"  {column_data} = load ptr, ptr {column_field}",
            LLVMArrayRuntime.data_pointer_line(row_field, self._operand(instruction.row), indent="  "),
            f"  {row_data} = load ptr, ptr {row_field}",
            LLVMArrayRuntime.data_pointer_line(result_field, result, indent="  "),
            f"  {result_data} = load ptr, ptr {result_field}",
            f"  {row_index_ptr} = alloca i64",
            f"  store i64 0, ptr {row_index_ptr}",
            f"  {col_index_ptr} = alloca i64",
            f"  br label %{labels.outer_loop}",
            f"{labels.outer_loop}:",
        ]

        row_index = self._synthetic_temp("outer.product.row.index")
        outer_cond = self._synthetic_temp("outer.product.outer.cond")
        lines.extend(
            self._double_loop_outer_check(
                row_index,
                row_index_ptr,
                outer_cond,
                instruction.rows,
                labels,
                indent="  ",
            )
            + [
                f"  store i64 0, ptr {col_index_ptr}",
                f"  br label %{labels.inner_loop}",
                f"{labels.inner_loop}:",
            ]
        )

        col_index = self._synthetic_temp("outer.product.col.index")
        inner_cond = self._synthetic_temp("outer.product.inner.cond")
        lines.extend(
            self._double_loop_inner_check(
                col_index,
                col_index_ptr,
                inner_cond,
                instruction.cols,
                labels,
                indent="  ",
            )
        )

        column_ptr = self._synthetic_temp("outer.product.column.elem")
        row_ptr = self._synthetic_temp("outer.product.row.elem")
        loaded_column = self._synthetic_temp("outer.product.column")
        loaded_row = self._synthetic_temp("outer.product.row")
        row_offset = self._synthetic_temp("outer.product.row.offset")
        result_index = self._synthetic_temp("outer.product.result.index")
        result_ptr = self._synthetic_temp("outer.product.result.elem")
        lines.extend(
            [
                self._element_pointer_line(column_ptr, column_element_type, column_data, row_index, indent="  "),
                self._load_element_line(loaded_column, column_element_type, column_ptr, indent="  "),
                self._element_pointer_line(row_ptr, row_element_type, row_data, col_index, indent="  "),
                self._load_element_line(loaded_row, row_element_type, row_ptr, indent="  "),
            ]
        )
        column_operand = self._coerce_scalar(
            lines,
            loaded_column,
            instruction.column.type.element,
            instruction.result.type.element,
            "outer.product.column.cast",
        )
        row_operand = self._coerce_scalar(
            lines,
            loaded_row,
            instruction.row.type.element,
            instruction.result.type.element,
            "outer.product.row.cast",
        )
        product = self._synthetic_temp("outer.product.product")
        col_next = self._synthetic_temp("outer.product.col.next")
        row_next = self._synthetic_temp("outer.product.row.next")
        lines.extend(
            [
                f"  {product} = {multiply_operator} {result_element_type} {column_operand}, {row_operand}",
                f"  {row_offset} = mul i64 {row_index}, {instruction.cols}",
                f"  {result_index} = add i64 {row_offset}, {col_index}",
                self._element_pointer_line(result_ptr, result_element_type, result_data, result_index, indent="  "),
                self._store_element_line(result_element_type, product, result_ptr, indent="  "),
                f"  {col_next} = add i64 {col_index}, 1",
                f"  store i64 {col_next}, ptr {col_index_ptr}",
                f"  br label %{labels.inner_loop}",
                f"{labels.inner_exit}:",
                f"  {row_next} = add i64 {row_index}, 1",
                f"  store i64 {row_next}, ptr {row_index_ptr}",
                f"  br label %{labels.outer_loop}",
                f"{labels.exit}:",
            ]
        )
        return lines

    def _validate_outer_product(self, instruction: SSAOuterProduct) -> None:
        if not isinstance(instruction.result.type, MatrixType):
            raise LLVMBackendError("LLVM outer_product result must be MatrixType")
        if not isinstance(instruction.column.type, VectorType) or not isinstance(instruction.row.type, VectorType):
            raise LLVMBackendError("LLVM outer_product expects vector operands")
        if instruction.column.type.orientation != "column" or instruction.row.type.orientation != "row":
            raise LLVMBackendError("LLVM outer_product is only defined for Vector<Column> * Vector<Row>")
        if instruction.rows <= 0 or instruction.cols <= 0:
            raise LLVMBackendError("LLVM outer_product requires positive dimensions")
        if not isinstance(instruction.result.type.element, (IntType, DoubleType)):
            raise LLVMBackendError("LLVM outer_product only supports int or double results")
        if not isinstance(instruction.column.type.element, (IntType, DoubleType)):
            raise LLVMBackendError("LLVM outer_product only supports int or double column elements")
        if not isinstance(instruction.row.type.element, (IntType, DoubleType)):
            raise LLVMBackendError("LLVM outer_product only supports int or double row elements")

    def _coerce_scalar(
        self,
        lines: list[str],
        value: str,
        source_type: object,
        target_type: object,
        prefix: str,
    ) -> str:
        if source_type == target_type:
            return value
        if isinstance(source_type, IntType) and isinstance(target_type, DoubleType):
            result = self._synthetic_temp(prefix)
            lines.append(f"  {result} = sitofp i32 {value} to double")
            return result
        raise LLVMBackendError(f"LLVM backend cannot coerce {source_type} to {target_type}")

    def _print_matrix_add(self, instruction: SSAMatrixAdd) -> list[str]:
        self._validate_matrix_binary(instruction, "add")
        return self._print_contiguous_binary(
            instruction.result,
            instruction.left,
            instruction.right,
            instruction.result.type.element,
            instruction.rows * instruction.cols,
            "add",
        )

    def _print_matrix_sub(self, instruction: SSAMatrixSub) -> list[str]:
        self._validate_matrix_binary(instruction, "sub")
        return self._print_contiguous_binary(
            instruction.result,
            instruction.left,
            instruction.right,
            instruction.result.type.element,
            instruction.rows * instruction.cols,
            "sub",
        )

    def _validate_matrix_binary(
        self,
        instruction: SSAMatrixAdd | SSAMatrixSub,
        operation: str,
    ) -> None:
        if not isinstance(instruction.result.type, MatrixType):
            raise LLVMBackendError(f"LLVM matrix_{operation} result must be MatrixType")
        if instruction.result.type != instruction.left.type or instruction.result.type != instruction.right.type:
            raise LLVMBackendError(f"LLVM matrix_{operation} requires matching matrix operand and result types")
        if instruction.rows <= 0 or instruction.cols <= 0:
            raise LLVMBackendError(f"LLVM matrix_{operation} requires positive dimensions")

    def _print_matrix_scale(self, instruction: SSAMatrixScale) -> list[str]:
        self._validate_matrix_scale(instruction)
        return self._print_contiguous_scale(
            instruction.result,
            instruction.matrix,
            instruction.scalar,
            instruction.result.type.element,
            instruction.rows * instruction.cols,
            "matrix.scale",
        )

    def _validate_matrix_scale(self, instruction: SSAMatrixScale) -> None:
        if not isinstance(instruction.result.type, MatrixType):
            raise LLVMBackendError("LLVM matrix_scale result must be MatrixType")
        if instruction.result.type != instruction.matrix.type:
            raise LLVMBackendError("LLVM matrix_scale requires matching matrix operand and result types")
        if instruction.scalar.type != instruction.result.type.element:
            raise LLVMBackendError("LLVM matrix_scale scalar type must match matrix element type")
        if instruction.rows <= 0 or instruction.cols <= 0:
            raise LLVMBackendError("LLVM matrix_scale requires positive dimensions")

    def _print_matrix_matmul(self, instruction: SSAMatrixMatMul) -> list[str]:
        self._validate_matrix_matmul(instruction)
        self._uses_array_type = True
        self._uses_array_allocation = True

        result_element_type = llvm_type(instruction.result.type.element)
        length = instruction.rows * instruction.cols
        allocation = self._aggregate_allocation(
            instruction.result,
            instruction.result.type.element,
            length,
        )
        result = allocation.result
        multiply_operator = self._element_binary_operator(instruction.result.type.element, "mul")
        add_operator = self._element_binary_operator(instruction.result.type.element, "add")
        zero = "0.0" if isinstance(instruction.result.type.element, DoubleType) else "0"
        lines = [allocation.line]

        left_data = self._synthetic_temp("matrix.matmul.left.data")
        right_data = self._synthetic_temp("matrix.matmul.right.data")
        result_data = self._synthetic_temp("matrix.matmul.result.data")
        lines.extend(self._array_data_pointer(left_data, self._operand(instruction.left)))
        lines.extend(self._array_data_pointer(right_data, self._operand(instruction.right)))
        lines.extend(self._array_data_pointer(result_data, result))

        left_element_type = llvm_type(instruction.left.type.element)
        right_element_type = llvm_type(instruction.right.type.element)

        def emit_cell(row: int, col: int) -> None:
            accumulator = zero
            for inner in range(instruction.inner):
                left_index = row * instruction.inner + inner
                right_index = inner * instruction.cols + col
                left_ptr = self._synthetic_temp("matrix.matmul.left.elem")
                right_ptr = self._synthetic_temp("matrix.matmul.right.elem")
                loaded_left = self._synthetic_temp("matrix.matmul.left")
                loaded_right = self._synthetic_temp("matrix.matmul.right")
                lines.append(
                    self._element_pointer_line(left_ptr, left_element_type, left_data, left_index)
                )
                lines.append(self._load_element_line(loaded_left, left_element_type, left_ptr))
                lines.append(
                    self._element_pointer_line(right_ptr, right_element_type, right_data, right_index)
                )
                lines.append(self._load_element_line(loaded_right, right_element_type, right_ptr))
                left_operand = self._coerce_scalar(
                    lines,
                    loaded_left,
                    instruction.left.type.element,
                    instruction.result.type.element,
                    "matrix.matmul.left.cast",
                )
                right_operand = self._coerce_scalar(
                    lines,
                    loaded_right,
                    instruction.right.type.element,
                    instruction.result.type.element,
                    "matrix.matmul.right.cast",
                )
                product = self._synthetic_temp("matrix.matmul.product")
                summed = self._synthetic_temp("matrix.matmul.sum")
                lines.append(
                    f"{product} = {multiply_operator} {result_element_type} {left_operand}, {right_operand}"
                )
                lines.append(
                    f"{summed} = {add_operator} {result_element_type} {accumulator}, {product}"
                )
                accumulator = summed
            result_index = row * instruction.cols + col
            result_ptr = self._synthetic_temp("matrix.matmul.result.elem")
            lines.append(
                self._element_pointer_line(result_ptr, result_element_type, result_data, result_index)
            )
            lines.append(self._store_element_line(result_element_type, accumulator, result_ptr))

        self._for_each_matrix_element(instruction.rows, instruction.cols, emit_cell)

        return lines

    def _validate_matrix_matmul(self, instruction: SSAMatrixMatMul) -> None:
        if not isinstance(instruction.result.type, MatrixType):
            raise LLVMBackendError("LLVM matrix_matmul result must be MatrixType")
        if not isinstance(instruction.left.type, MatrixType) or not isinstance(instruction.right.type, MatrixType):
            raise LLVMBackendError("LLVM matrix_matmul expects matrix operands")
        if instruction.rows <= 0 or instruction.inner <= 0 or instruction.cols <= 0:
            raise LLVMBackendError("LLVM matrix_matmul requires positive dimensions")
        if not isinstance(instruction.result.type.element, (IntType, DoubleType)):
            raise LLVMBackendError("LLVM matrix_matmul only supports int or double results")
        if not isinstance(instruction.left.type.element, (IntType, DoubleType)):
            raise LLVMBackendError("LLVM matrix_matmul only supports int or double left elements")
        if not isinstance(instruction.right.type.element, (IntType, DoubleType)):
            raise LLVMBackendError("LLVM matrix_matmul only supports int or double right elements")

    def _print_matrix_vector_mul(self, instruction: SSAMatrixVectorMul) -> list[str]:
        self._validate_matrix_vector_mul(instruction)
        self._uses_array_type = True
        self._uses_array_allocation = True

        result_element_type = llvm_type(instruction.result.type.element)
        allocation = self._aggregate_allocation(
            instruction.result,
            instruction.result.type.element,
            instruction.rows,
            indent="  ",
        )
        result = allocation.result
        matrix_element_type = llvm_type(instruction.matrix.type.element)
        vector_element_type = llvm_type(instruction.vector.type.element)
        multiply_operator = self._element_binary_operator(instruction.result.type.element, "mul")
        add_operator = self._element_binary_operator(instruction.result.type.element, "add")
        zero = "0.0" if isinstance(instruction.result.type.element, DoubleType) else "0"
        labels = self._double_loop_labels("matrix.vector")

        matrix_field = self._synthetic_temp("matrix.vector.matrix.data.field")
        matrix_data = self._synthetic_temp("matrix.vector.matrix.data")
        vector_field = self._synthetic_temp("matrix.vector.vector.data.field")
        vector_data = self._synthetic_temp("matrix.vector.vector.data")
        result_field = self._synthetic_temp("matrix.vector.result.data.field")
        result_data = self._synthetic_temp("matrix.vector.result.data")
        row_ptr = self._synthetic_temp("matrix.vector.row.ptr")
        col_ptr = self._synthetic_temp("matrix.vector.col.ptr")
        acc_ptr = self._synthetic_temp("matrix.vector.acc.ptr")
        lines = [
            allocation.line,
            LLVMArrayRuntime.data_pointer_line(matrix_field, self._operand(instruction.matrix), indent="  "),
            f"  {matrix_data} = load ptr, ptr {matrix_field}",
            LLVMArrayRuntime.data_pointer_line(vector_field, self._operand(instruction.vector), indent="  "),
            f"  {vector_data} = load ptr, ptr {vector_field}",
            LLVMArrayRuntime.data_pointer_line(result_field, result, indent="  "),
            f"  {result_data} = load ptr, ptr {result_field}",
            f"  {row_ptr} = alloca i64",
            f"  store i64 0, ptr {row_ptr}",
            f"  {col_ptr} = alloca i64",
            f"  {acc_ptr} = alloca {result_element_type}",
            f"  br label %{labels.outer_loop}",
            f"{labels.outer_loop}:",
        ]

        row = self._synthetic_temp("matrix.vector.row")
        outer_cond = self._synthetic_temp("matrix.vector.outer.cond")
        lines.extend(
            self._double_loop_outer_check(
                row,
                row_ptr,
                outer_cond,
                instruction.rows,
                labels,
                indent="  ",
            )
            + [
                f"  store {result_element_type} {zero}, ptr {acc_ptr}",
                f"  store i64 0, ptr {col_ptr}",
                f"  br label %{labels.inner_loop}",
                f"{labels.inner_loop}:",
            ]
        )

        col = self._synthetic_temp("matrix.vector.col")
        inner_cond = self._synthetic_temp("matrix.vector.inner.cond")
        lines.extend(
            self._double_loop_inner_check(
                col,
                col_ptr,
                inner_cond,
                instruction.inner,
                labels,
                indent="  ",
            )
        )

        row_offset = self._synthetic_temp("matrix.vector.row.offset")
        matrix_index = self._synthetic_temp("matrix.vector.matrix.index")
        matrix_ptr = self._synthetic_temp("matrix.vector.matrix.elem")
        vector_ptr = self._synthetic_temp("matrix.vector.vector.elem")
        loaded_matrix = self._synthetic_temp("matrix.vector.matrix")
        loaded_vector = self._synthetic_temp("matrix.vector.vector")
        lines.extend(
            [
                f"  {row_offset} = mul i64 {row}, {instruction.inner}",
                f"  {matrix_index} = add i64 {row_offset}, {col}",
                self._element_pointer_line(matrix_ptr, matrix_element_type, matrix_data, matrix_index, indent="  "),
                self._load_element_line(loaded_matrix, matrix_element_type, matrix_ptr, indent="  "),
                self._element_pointer_line(vector_ptr, vector_element_type, vector_data, col, indent="  "),
                self._load_element_line(loaded_vector, vector_element_type, vector_ptr, indent="  "),
            ]
        )
        matrix_operand = self._coerce_scalar(
            lines,
            loaded_matrix,
            instruction.matrix.type.element,
            instruction.result.type.element,
            "matrix.vector.matrix.cast",
        )
        vector_operand = self._coerce_scalar(
            lines,
            loaded_vector,
            instruction.vector.type.element,
            instruction.result.type.element,
            "matrix.vector.vector.cast",
        )
        product = self._synthetic_temp("matrix.vector.product")
        acc_current = self._synthetic_temp("matrix.vector.acc")
        acc_next = self._synthetic_temp("matrix.vector.acc.next")
        col_next = self._synthetic_temp("matrix.vector.col.next")
        acc_final = self._synthetic_temp("matrix.vector.acc.final")
        result_ptr = self._synthetic_temp("matrix.vector.result.elem")
        row_next = self._synthetic_temp("matrix.vector.row.next")
        lines.extend(
            [
                f"  {product} = {multiply_operator} {result_element_type} {matrix_operand}, {vector_operand}",
                f"  {acc_current} = load {result_element_type}, ptr {acc_ptr}",
                f"  {acc_next} = {add_operator} {result_element_type} {acc_current}, {product}",
                f"  store {result_element_type} {acc_next}, ptr {acc_ptr}",
                f"  {col_next} = add i64 {col}, 1",
                f"  store i64 {col_next}, ptr {col_ptr}",
                f"  br label %{labels.inner_loop}",
                f"{labels.inner_exit}:",
                f"  {acc_final} = load {result_element_type}, ptr {acc_ptr}",
                self._element_pointer_line(result_ptr, result_element_type, result_data, row, indent="  "),
                self._store_element_line(result_element_type, acc_final, result_ptr, indent="  "),
                f"  {row_next} = add i64 {row}, 1",
                f"  store i64 {row_next}, ptr {row_ptr}",
                f"  br label %{labels.outer_loop}",
                f"{labels.exit}:",
            ]
        )
        return lines

    def _validate_matrix_vector_mul(self, instruction: SSAMatrixVectorMul) -> None:
        if not isinstance(instruction.result.type, VectorType):
            raise LLVMBackendError("LLVM matrix_vector_mul result must be VectorType")
        if instruction.result.type.orientation != "column":
            raise LLVMBackendError("LLVM matrix_vector_mul result must be Vector<Column>")
        if not isinstance(instruction.matrix.type, MatrixType) or not isinstance(instruction.vector.type, VectorType):
            raise LLVMBackendError("LLVM matrix_vector_mul expects matrix and vector operands")
        if instruction.vector.type.orientation != "column":
            raise LLVMBackendError("LLVM matrix_vector_mul only supports Matrix * Vector<Column>")
        if instruction.rows <= 0 or instruction.inner <= 0:
            raise LLVMBackendError("LLVM matrix_vector_mul requires positive dimensions")
        if not isinstance(instruction.result.type.element, (IntType, DoubleType)):
            raise LLVMBackendError("LLVM matrix_vector_mul only supports int or double results")
        if not isinstance(instruction.matrix.type.element, (IntType, DoubleType)):
            raise LLVMBackendError("LLVM matrix_vector_mul only supports int or double matrix elements")
        if not isinstance(instruction.vector.type.element, (IntType, DoubleType)):
            raise LLVMBackendError("LLVM matrix_vector_mul only supports int or double vector elements")

    def _print_vector_matrix_mul(self, instruction: SSAVectorMatrixMul) -> list[str]:
        self._validate_vector_matrix_mul(instruction)
        self._uses_array_type = True
        self._uses_array_allocation = True

        result_element_type = llvm_type(instruction.result.type.element)
        allocation = self._aggregate_allocation(
            instruction.result,
            instruction.result.type.element,
            instruction.cols,
            indent="  ",
        )
        result = allocation.result
        vector_element_type = llvm_type(instruction.vector.type.element)
        matrix_element_type = llvm_type(instruction.matrix.type.element)
        multiply_operator = self._element_binary_operator(instruction.result.type.element, "mul")
        add_operator = self._element_binary_operator(instruction.result.type.element, "add")
        zero = "0.0" if isinstance(instruction.result.type.element, DoubleType) else "0"
        labels = self._double_loop_labels("vector.matrix")

        vector_field = self._synthetic_temp("vector.matrix.vector.data.field")
        vector_data = self._synthetic_temp("vector.matrix.vector.data")
        matrix_field = self._synthetic_temp("vector.matrix.matrix.data.field")
        matrix_data = self._synthetic_temp("vector.matrix.matrix.data")
        result_field = self._synthetic_temp("vector.matrix.result.data.field")
        result_data = self._synthetic_temp("vector.matrix.result.data")
        col_ptr = self._synthetic_temp("vector.matrix.col.ptr")
        row_ptr = self._synthetic_temp("vector.matrix.row.ptr")
        acc_ptr = self._synthetic_temp("vector.matrix.acc.ptr")
        lines = [
            allocation.line,
            LLVMArrayRuntime.data_pointer_line(vector_field, self._operand(instruction.vector), indent="  "),
            f"  {vector_data} = load ptr, ptr {vector_field}",
            LLVMArrayRuntime.data_pointer_line(matrix_field, self._operand(instruction.matrix), indent="  "),
            f"  {matrix_data} = load ptr, ptr {matrix_field}",
            LLVMArrayRuntime.data_pointer_line(result_field, result, indent="  "),
            f"  {result_data} = load ptr, ptr {result_field}",
            f"  {col_ptr} = alloca i64",
            f"  store i64 0, ptr {col_ptr}",
            f"  {row_ptr} = alloca i64",
            f"  {acc_ptr} = alloca {result_element_type}",
            f"  br label %{labels.outer_loop}",
            f"{labels.outer_loop}:",
        ]

        col = self._synthetic_temp("vector.matrix.col")
        outer_cond = self._synthetic_temp("vector.matrix.outer.cond")
        lines.extend(
            self._double_loop_outer_check(
                col,
                col_ptr,
                outer_cond,
                instruction.cols,
                labels,
                indent="  ",
            )
            + [
                f"  store {result_element_type} {zero}, ptr {acc_ptr}",
                f"  store i64 0, ptr {row_ptr}",
                f"  br label %{labels.inner_loop}",
                f"{labels.inner_loop}:",
            ]
        )

        row = self._synthetic_temp("vector.matrix.row")
        inner_cond = self._synthetic_temp("vector.matrix.inner.cond")
        lines.extend(
            self._double_loop_inner_check(
                row,
                row_ptr,
                inner_cond,
                instruction.rows,
                labels,
                indent="  ",
            )
        )

        row_offset = self._synthetic_temp("vector.matrix.row.offset")
        matrix_index = self._synthetic_temp("vector.matrix.matrix.index")
        vector_ptr = self._synthetic_temp("vector.matrix.vector.elem")
        matrix_ptr = self._synthetic_temp("vector.matrix.matrix.elem")
        loaded_vector = self._synthetic_temp("vector.matrix.vector")
        loaded_matrix = self._synthetic_temp("vector.matrix.matrix")
        lines.extend(
            [
                f"  {row_offset} = mul i64 {row}, {instruction.cols}",
                f"  {matrix_index} = add i64 {row_offset}, {col}",
                self._element_pointer_line(vector_ptr, vector_element_type, vector_data, row, indent="  "),
                self._load_element_line(loaded_vector, vector_element_type, vector_ptr, indent="  "),
                self._element_pointer_line(matrix_ptr, matrix_element_type, matrix_data, matrix_index, indent="  "),
                self._load_element_line(loaded_matrix, matrix_element_type, matrix_ptr, indent="  "),
            ]
        )
        vector_operand = self._coerce_scalar(
            lines,
            loaded_vector,
            instruction.vector.type.element,
            instruction.result.type.element,
            "vector.matrix.vector.cast",
        )
        matrix_operand = self._coerce_scalar(
            lines,
            loaded_matrix,
            instruction.matrix.type.element,
            instruction.result.type.element,
            "vector.matrix.matrix.cast",
        )
        product = self._synthetic_temp("vector.matrix.product")
        acc_current = self._synthetic_temp("vector.matrix.acc")
        acc_next = self._synthetic_temp("vector.matrix.acc.next")
        row_next = self._synthetic_temp("vector.matrix.row.next")
        acc_final = self._synthetic_temp("vector.matrix.acc.final")
        result_ptr = self._synthetic_temp("vector.matrix.result.elem")
        col_next = self._synthetic_temp("vector.matrix.col.next")
        lines.extend(
            [
                f"  {product} = {multiply_operator} {result_element_type} {vector_operand}, {matrix_operand}",
                f"  {acc_current} = load {result_element_type}, ptr {acc_ptr}",
                f"  {acc_next} = {add_operator} {result_element_type} {acc_current}, {product}",
                f"  store {result_element_type} {acc_next}, ptr {acc_ptr}",
                f"  {row_next} = add i64 {row}, 1",
                f"  store i64 {row_next}, ptr {row_ptr}",
                f"  br label %{labels.inner_loop}",
                f"{labels.inner_exit}:",
                f"  {acc_final} = load {result_element_type}, ptr {acc_ptr}",
                self._element_pointer_line(result_ptr, result_element_type, result_data, col, indent="  "),
                self._store_element_line(result_element_type, acc_final, result_ptr, indent="  "),
                f"  {col_next} = add i64 {col}, 1",
                f"  store i64 {col_next}, ptr {col_ptr}",
                f"  br label %{labels.outer_loop}",
                f"{labels.exit}:",
            ]
        )
        return lines

    def _validate_vector_matrix_mul(self, instruction: SSAVectorMatrixMul) -> None:
        if not isinstance(instruction.result.type, VectorType):
            raise LLVMBackendError("LLVM vector_matrix_mul result must be VectorType")
        if instruction.result.type.orientation != "row":
            raise LLVMBackendError("LLVM vector_matrix_mul result must be Vector<Row>")
        if not isinstance(instruction.vector.type, VectorType) or not isinstance(instruction.matrix.type, MatrixType):
            raise LLVMBackendError("LLVM vector_matrix_mul expects vector and matrix operands")
        if instruction.vector.type.orientation != "row":
            raise LLVMBackendError("LLVM vector_matrix_mul only supports Vector<Row> * Matrix")
        if instruction.rows <= 0 or instruction.cols <= 0:
            raise LLVMBackendError("LLVM vector_matrix_mul requires positive dimensions")
        if not isinstance(instruction.result.type.element, (IntType, DoubleType)):
            raise LLVMBackendError("LLVM vector_matrix_mul only supports int or double results")
        if not isinstance(instruction.vector.type.element, (IntType, DoubleType)):
            raise LLVMBackendError("LLVM vector_matrix_mul only supports int or double vector elements")
        if not isinstance(instruction.matrix.type.element, (IntType, DoubleType)):
            raise LLVMBackendError("LLVM vector_matrix_mul only supports int or double matrix elements")

    def _print_contiguous_new(
        self,
        result_value: SSAValue,
        element_ir_type: object,
        elements: tuple[SSAValue, ...],
    ) -> str:
        self._uses_array_type = True
        self._uses_array_allocation = True

        element_type = llvm_type(element_ir_type)
        length = len(elements)
        allocation = self._aggregate_allocation(result_value, element_ir_type, length)
        element_layout = self._layouts.layout(element_ir_type)
        result = allocation.result
        lines = [allocation.line]
        data = self._synthetic_temp("array.data")
        lines.extend(self._array_data_pointer(data, result))

        def emit_element(index: int) -> None:
            element = elements[index]
            element_ptr = self._synthetic_temp("array.elem")
            lines.append(
                self._element_pointer_line(element_ptr, element_type, data, index)
            )
            stored = self._operand(element)
            if element_layout.needs_retain:
                stored = self._emit_arc_value(
                    lines, stored, element.type, retain=True
                )
            lines.append(self._store_element_line(element_type, stored, element_ptr))

        self._for_each_element(length, emit_element)
        return "\n  ".join(lines)

    def _print_contiguous_binary(
        self,
        result_value: SSAValue,
        left_value: SSAValue,
        right_value: SSAValue,
        element_ir_type: object,
        length: int,
        operator_name: str,
    ) -> list[str]:
        self._uses_array_type = True
        self._uses_array_allocation = True

        element_type = llvm_type(element_ir_type)
        allocation = self._aggregate_allocation(result_value, element_ir_type, length)
        result = allocation.result
        operator = self._element_binary_operator(element_ir_type, operator_name)
        lines = [allocation.line]

        left_data = self._synthetic_temp(f"{operator_name}.left.data")
        right_data = self._synthetic_temp(f"{operator_name}.right.data")
        result_data = self._synthetic_temp(f"{operator_name}.result.data")
        lines.extend(self._array_data_pointer(left_data, self._operand(left_value)))
        lines.extend(self._array_data_pointer(right_data, self._operand(right_value)))
        lines.extend(self._array_data_pointer(result_data, result))

        def emit_element(index: int) -> None:
            left_ptr = self._synthetic_temp(f"{operator_name}.left.elem")
            right_ptr = self._synthetic_temp(f"{operator_name}.right.elem")
            result_ptr = self._synthetic_temp(f"{operator_name}.result.elem")
            loaded_left = self._synthetic_temp(f"{operator_name}.left")
            loaded_right = self._synthetic_temp(f"{operator_name}.right")
            result_element = self._synthetic_temp(f"{operator_name}.value")
            lines.append(
                self._element_pointer_line(left_ptr, element_type, left_data, index)
            )
            lines.append(self._load_element_line(loaded_left, element_type, left_ptr))
            lines.append(
                self._element_pointer_line(right_ptr, element_type, right_data, index)
            )
            lines.append(self._load_element_line(loaded_right, element_type, right_ptr))
            lines.append(
                f"{result_element} = {operator} {element_type} {loaded_left}, {loaded_right}"
            )
            lines.append(
                self._element_pointer_line(result_ptr, element_type, result_data, index)
            )
            lines.append(self._store_element_line(element_type, result_element, result_ptr))

        self._for_each_element(length, emit_element)

        return lines

    def _print_contiguous_scale(
        self,
        result_value: SSAValue,
        aggregate_value: SSAValue,
        scalar_value: SSAValue,
        element_ir_type: object,
        length: int,
        operation_name: str,
    ) -> list[str]:
        self._uses_array_type = True
        self._uses_array_allocation = True

        element_type = llvm_type(element_ir_type)
        allocation = self._aggregate_allocation(result_value, element_ir_type, length)
        result = allocation.result
        operator = self._element_binary_operator(element_ir_type, "mul")
        scalar = self._operand(scalar_value)
        lines = [allocation.line]

        aggregate_data = self._synthetic_temp(f"{operation_name}.source.data")
        result_data = self._synthetic_temp(f"{operation_name}.result.data")
        lines.extend(self._array_data_pointer(aggregate_data, self._operand(aggregate_value)))
        lines.extend(self._array_data_pointer(result_data, result))

        def emit_element(index: int) -> None:
            aggregate_ptr = self._synthetic_temp(f"{operation_name}.source.elem")
            result_ptr = self._synthetic_temp(f"{operation_name}.result.elem")
            loaded_value = self._synthetic_temp(f"{operation_name}.source")
            result_element = self._synthetic_temp(f"{operation_name}.value")
            lines.append(
                self._element_pointer_line(aggregate_ptr, element_type, aggregate_data, index)
            )
            lines.append(self._load_element_line(loaded_value, element_type, aggregate_ptr))
            lines.append(
                f"{result_element} = {operator} {element_type} {loaded_value}, {scalar}"
            )
            lines.append(
                self._element_pointer_line(result_ptr, element_type, result_data, index)
            )
            lines.append(self._store_element_line(element_type, result_element, result_ptr))

        self._for_each_element(length, emit_element)

        return lines

    def _print_array_get(self, instruction: SSAArrayGet) -> list[str]:
        if not isinstance(instruction.array.type, ArrayType):
            raise LLVMBackendError("LLVM array_get expects an ArrayType source")
        self._uses_array_type = True
        self._uses_array_indexing = True

        result = self._new_temp(instruction.result)
        element_type = llvm_type(instruction.result.type)
        element_ptr = self._array_element_pointer(
            self._operand(instruction.array),
            instruction.index,
            instruction.result.type,
            check_bounds=instruction.bounds_checked,
        )
        lines = element_ptr.lines + [f"{result} = load {element_type}, ptr {element_ptr.value}"]
        if (
            not instruction.borrowed
            and self._layouts.layout(instruction.result.type).needs_retain
        ):
            copied = self._emit_arc_value(
                lines, result, instruction.result.type, retain=True
            )
            if copied != result:
                self._values[self._key(instruction.result)] = copied
        return lines

    def _print_array_slice(self, instruction: SSAArraySlice) -> str:
        if not isinstance(instruction.array.type, ArrayType):
            raise LLVMBackendError("LLVM array_slice expects an ArrayType source")
        self._uses_array_type = True
        self._uses_array_allocation = True
        self._uses_array_slicing = True
        result = self._new_temp(instruction.result)
        element_size = self._sizeof(instruction.array.type.element, collection="Array")
        lines = [
            f"{result} = call ptr @aether_array_slice(ptr {self._operand(instruction.array)}, "
            f"i32 {self._operand(instruction.start)}, i32 {self._operand(instruction.end)}, "
            f"i64 {element_size})"
        ]
        if self._layouts.layout(instruction.array.type.element).needs_retain:
            helper = self._require_collection_arc_helper("array", instruction.array.type.element, retain=True)
            lines.append(f"call void @{helper}(ptr {result})")
        return "\n  ".join(lines)

    def _print_list_slice(self, instruction: SSAListSlice) -> str:
        if not isinstance(instruction.list_value.type, ListType):
            raise LLVMBackendError("LLVM list_slice expects a ListType source")
        self._uses_list_type = True
        self._uses_list_allocation = True
        self._uses_list_slicing = True
        result = self._new_temp(instruction.result)
        element_size = self._sizeof(instruction.list_value.type.element, collection="List")
        lines = [
            f"{result} = call ptr @aether_list_slice(ptr {self._operand(instruction.list_value)}, "
            f"i32 {self._operand(instruction.start)}, i32 {self._operand(instruction.end)}, "
            f"i64 {element_size})"
        ]
        if self._layouts.layout(instruction.list_value.type.element).needs_retain:
            helper = self._require_collection_arc_helper(
                "list", instruction.list_value.type.element, retain=True
            )
            lines.append(f"call void @{helper}(ptr {result})")
        return "\n  ".join(lines)

    def _print_list_get(self, instruction: SSAListGet) -> list[str]:
        if not isinstance(instruction.list_value.type, ListType):
            raise LLVMBackendError("LLVM list_get expects a ListType source")
        self._uses_list_type = True
        self._uses_list_indexing = True

        result = self._new_temp(instruction.result)
        element_type = llvm_type(instruction.result.type)
        element_ptr = self._list_element_pointer(
            self._operand(instruction.list_value),
            instruction.index,
            instruction.result.type,
            check_bounds=instruction.bounds_checked,
        )
        lines = element_ptr.lines + [f"{result} = load {element_type}, ptr {element_ptr.value}"]
        if (
            not instruction.borrowed
            and self._layouts.layout(instruction.result.type).needs_retain
        ):
            copied = self._emit_arc_value(
                lines, result, instruction.result.type, retain=True
            )
            if copied != result:
                self._values[self._key(instruction.result)] = copied
        return lines

    def _print_vector_get(self, instruction: SSAVectorGet) -> list[str]:
        if not isinstance(instruction.vector.type, VectorType):
            raise LLVMBackendError("LLVM vector_get expects a VectorType source")
        self._uses_array_type = True
        self._uses_vector_indexing = True

        result = self._new_temp(instruction.result)
        element_type = llvm_type(instruction.result.type)
        element_ptr = self._vector_element_pointer(
            self._operand(instruction.vector),
            instruction.index,
            instruction.result.type,
            check_bounds=instruction.bounds_checked,
        )
        return element_ptr.lines + [
            f"{result} = load {element_type}, ptr {element_ptr.value}"
        ]

    def _print_matrix_get(self, instruction: SSAMatrixGet) -> list[str]:
        if not isinstance(instruction.matrix.type, MatrixType):
            raise LLVMBackendError("LLVM matrix_get expects a MatrixType source")
        if instruction.cols <= 0:
            raise LLVMBackendError("LLVM matrix_get requires a positive column count")
        self._uses_array_type = True
        self._uses_matrix_indexing = True

        result = self._new_temp(instruction.result)
        element_type = llvm_type(instruction.result.type)
        element_ptr = self._matrix_element_pointer(
            self._operand(instruction.matrix),
            instruction.row,
            instruction.column,
            instruction.cols,
            instruction.result.type,
            check_bounds=instruction.bounds_checked,
        )
        return element_ptr.lines + [
            f"{result} = load {element_type}, ptr {element_ptr.value}"
        ]

    def _print_array_set(self, instruction: SSAArraySet) -> list[str]:
        if not isinstance(instruction.array.type, ArrayType):
            raise LLVMBackendError("LLVM array_set expects an ArrayType source")
        self._uses_array_type = True
        self._uses_array_indexing = True

        element_type = llvm_type(instruction.value.type)
        element_ptr = self._array_element_pointer(
            self._operand(instruction.array),
            instruction.index,
            instruction.value.type,
            check_bounds=instruction.bounds_checked,
        )
        lines = list(element_ptr.lines)
        layout = self._layouts.layout(instruction.value.type)
        if layout.needs_retain:
            old = self._synthetic_temp("array.set.old")
            stored = self._emit_arc_value(
                lines,
                self._operand(instruction.value),
                instruction.value.type,
                retain=True,
            )
            lines.append(f"{old} = load {element_type}, ptr {element_ptr.value}")
            lines.append(f"store {element_type} {stored}, ptr {element_ptr.value}")
            self._emit_arc_value(lines, old, instruction.value.type, retain=False)
            return lines
        lines.append(f"store {element_type} {self._operand(instruction.value)}, ptr {element_ptr.value}")
        return lines

    def _print_vector_set(self, instruction: SSAVectorSet) -> list[str]:
        if not isinstance(instruction.vector.type, VectorType):
            raise LLVMBackendError("LLVM vector_set expects a VectorType source")
        if instruction.value.type != instruction.vector.type.element:
            raise LLVMBackendError("LLVM vector_set value type must match vector element type")
        self._uses_array_type = True
        self._uses_vector_indexing = True

        element_type = llvm_type(instruction.value.type)
        element_ptr = self._vector_element_pointer(
            self._operand(instruction.vector),
            instruction.index,
            instruction.value.type,
            check_bounds=instruction.bounds_checked,
        )
        lines = list(element_ptr.lines)
        layout = self._layouts.layout(instruction.value.type)
        if layout.needs_retain:
            old = self._synthetic_temp("list.set.old")
            stored = self._emit_arc_value(
                lines,
                self._operand(instruction.value),
                instruction.value.type,
                retain=True,
            )
            lines.append(f"{old} = load {element_type}, ptr {element_ptr.value}")
            lines.append(f"store {element_type} {stored}, ptr {element_ptr.value}")
            self._emit_arc_value(lines, old, instruction.value.type, retain=False)
            return lines
        lines.append(f"store {element_type} {self._operand(instruction.value)}, ptr {element_ptr.value}")
        return lines

    def _print_list_set(self, instruction: SSAListSet) -> list[str]:
        if not isinstance(instruction.list_value.type, ListType):
            raise LLVMBackendError("LLVM list_set expects a ListType source")
        if instruction.value.type != instruction.list_value.type.element:
            raise LLVMBackendError("LLVM list_set value type must match list element type")
        self._uses_list_type = True
        self._uses_list_indexing = True

        element_type = llvm_type(instruction.value.type)
        element_ptr = self._list_element_pointer(
            self._operand(instruction.list_value),
            instruction.index,
            instruction.value.type,
            check_bounds=instruction.bounds_checked,
        )
        lines = list(element_ptr.lines)
        layout = self._layouts.layout(instruction.value.type)
        if layout.needs_retain:
            old = self._synthetic_temp("list.set.old")
            stored = self._emit_arc_value(
                lines,
                self._operand(instruction.value),
                instruction.value.type,
                retain=True,
            )
            lines.append(f"{old} = load {element_type}, ptr {element_ptr.value}")
            lines.append(f"store {element_type} {stored}, ptr {element_ptr.value}")
            self._emit_arc_value(lines, old, instruction.value.type, retain=False)
            return lines
        lines.append(f"store {element_type} {self._operand(instruction.value)}, ptr {element_ptr.value}")
        return lines

    def _print_matrix_set(self, instruction: SSAMatrixSet) -> list[str]:
        if not isinstance(instruction.matrix.type, MatrixType):
            raise LLVMBackendError("LLVM matrix_set expects a MatrixType source")
        if instruction.cols <= 0:
            raise LLVMBackendError("LLVM matrix_set requires a positive column count")
        if instruction.value.type != instruction.matrix.type.element:
            raise LLVMBackendError("LLVM matrix_set value type must match matrix element type")
        self._uses_array_type = True
        self._uses_matrix_indexing = True

        element_type = llvm_type(instruction.value.type)
        element_ptr = self._matrix_element_pointer(
            self._operand(instruction.matrix),
            instruction.row,
            instruction.column,
            instruction.cols,
            instruction.value.type,
            check_bounds=instruction.bounds_checked,
        )
        return element_ptr.lines + [
            f"store {element_type} {self._operand(instruction.value)}, ptr {element_ptr.value}"
        ]

    def _print_array_length(self, instruction: SSAArrayLength) -> list[str]:
        self._uses_array_type = True
        self._uses_array_length_conversion = True
        result = self._new_temp(instruction.result)
        length64 = self._synthetic_temp("array.len64")
        lines = self._array_length64(length64, self._operand(instruction.array))
        lines.append(f"{result} = call i32 @aether_array_length_to_int(i64 {length64})")
        return lines

    def _print_list_length(self, instruction: SSAListLength) -> list[str]:
        if not isinstance(instruction.list_value.type, ListType):
            raise LLVMBackendError("LLVM list_length expects a ListType source")
        self._uses_list_type = True
        self._uses_list_length_conversion = True
        result = self._new_temp(instruction.result)
        length64 = self._synthetic_temp("list.len64")
        lines = self._list_length64(length64, self._operand(instruction.list_value))
        lines.append(f"{result} = call i32 @aether_list_length_to_int(i64 {length64})")
        return lines

    def _print_list_is_empty(self, instruction: SSAListIsEmpty) -> list[str]:
        if not isinstance(instruction.list_value.type, ListType):
            raise LLVMBackendError("LLVM list_is_empty expects a ListType source")
        self._uses_list_type = True
        result = self._new_temp(instruction.result)
        length64 = self._synthetic_temp("list.empty.len64")
        lines = self._list_length64(length64, self._operand(instruction.list_value))
        lines.append(f"{result} = icmp eq i64 {length64}, 0")
        return lines

    def _print_vector_length(self, instruction: SSAVectorLength) -> list[str]:
        if not isinstance(instruction.vector.type, VectorType):
            raise LLVMBackendError("LLVM vector_length expects a VectorType source")
        self._uses_array_type = True
        result = self._new_temp(instruction.result)
        length64 = self._synthetic_temp("vector.len64")
        lines = self._array_length64(length64, self._operand(instruction.vector))
        lines.append(f"{result} = trunc i64 {length64} to i32")
        return lines

    def _print_matrix_rows(self, instruction: SSAMatrixRows) -> str:
        if not isinstance(instruction.matrix.type, MatrixType):
            raise LLVMBackendError("LLVM matrix_rows expects a MatrixType source")
        result = self._new_temp(instruction.result)
        return f"{result} = add i32 0, {instruction.rows}"

    def _print_matrix_columns(self, instruction: SSAMatrixColumns) -> str:
        if not isinstance(instruction.matrix.type, MatrixType):
            raise LLVMBackendError("LLVM matrix_columns expects a MatrixType source")
        result = self._new_temp(instruction.result)
        return f"{result} = add i32 0, {instruction.columns}"

    @dataclass(frozen=True)
    class _ArrayPointer:
        value: str
        lines: list[str]

    @dataclass(frozen=True)
    class _AggregateAllocation:
        result: str
        line: str

    @dataclass(frozen=True)
    class _LoopLabels:
        loop: str
        body: str
        exit: str

    @dataclass(frozen=True)
    class _DoubleLoopLabels:
        outer_loop: str
        outer_body: str
        inner_loop: str
        inner_body: str
        inner_exit: str
        exit: str

    def _aggregate_allocation(
        self,
        result_value: SSAValue,
        element_ir_type: object,
        length: int,
        *,
        indent: str = "",
    ) -> _AggregateAllocation:
        result = self._new_temp(result_value)
        element_size = self._sizeof(element_ir_type, collection="Array")
        return self._AggregateAllocation(
            result,
            f"{indent}{result} = call ptr @aether_array_new(i64 {element_size}, i64 {length})",
        )

    def _linear_loop_labels(self, prefix: str) -> _LoopLabels:
        label_id = self._next_synthetic_temp
        self._next_synthetic_temp += 1
        return self._LoopLabels(
            f"{prefix}.loop.{label_id}",
            f"{prefix}.body.{label_id}",
            f"{prefix}.exit.{label_id}",
        )

    def _double_loop_labels(self, prefix: str) -> _DoubleLoopLabels:
        label_id = self._next_synthetic_temp
        self._next_synthetic_temp += 1
        return self._DoubleLoopLabels(
            f"{prefix}.outer.loop.{label_id}",
            f"{prefix}.outer.body.{label_id}",
            f"{prefix}.inner.loop.{label_id}",
            f"{prefix}.inner.body.{label_id}",
            f"{prefix}.inner.exit.{label_id}",
            f"{prefix}.exit.{label_id}",
        )

    def _linear_loop_check(
        self,
        index: str,
        index_ptr: str,
        condition: str,
        limit: int,
        labels: _LoopLabels,
        *,
        indent: str = "",
    ) -> list[str]:
        return [
            f"{indent}{index} = load i64, ptr {index_ptr}",
            f"{indent}{condition} = icmp slt i64 {index}, {limit}",
            f"{indent}br i1 {condition}, label %{labels.body}, label %{labels.exit}",
            f"{labels.body}:",
        ]

    def _double_loop_outer_check(
        self,
        index: str,
        index_ptr: str,
        condition: str,
        limit: int,
        labels: _DoubleLoopLabels,
        *,
        indent: str = "",
    ) -> list[str]:
        return [
            f"{indent}{index} = load i64, ptr {index_ptr}",
            f"{indent}{condition} = icmp slt i64 {index}, {limit}",
            f"{indent}br i1 {condition}, label %{labels.outer_body}, label %{labels.exit}",
            f"{labels.outer_body}:",
        ]

    def _double_loop_inner_check(
        self,
        index: str,
        index_ptr: str,
        condition: str,
        limit: int,
        labels: _DoubleLoopLabels,
        *,
        indent: str = "",
    ) -> list[str]:
        return [
            f"{indent}{index} = load i64, ptr {index_ptr}",
            f"{indent}{condition} = icmp slt i64 {index}, {limit}",
            f"{indent}br i1 {condition}, label %{labels.inner_body}, label %{labels.inner_exit}",
            f"{labels.inner_body}:",
        ]

    @staticmethod
    def _for_each_element(length: int, emit: Callable[[int], None]) -> None:
        for index in range(length):
            emit(index)

    @staticmethod
    def _for_each_matrix_element(
        rows: int,
        cols: int,
        emit: Callable[[int, int], None],
    ) -> None:
        for row in range(rows):
            for col in range(cols):
                emit(row, col)

    @staticmethod
    def _element_pointer_line(
        result: str,
        element_type: str,
        data: str,
        index: int | str,
        *,
        indent: str = "",
    ) -> str:
        return f"{indent}{result} = getelementptr {element_type}, ptr {data}, i64 {index}"

    @staticmethod
    def _load_element_line(
        result: str,
        element_type: str,
        pointer: str,
        *,
        indent: str = "",
    ) -> str:
        return f"{indent}{result} = load {element_type}, ptr {pointer}"

    @staticmethod
    def _store_element_line(
        element_type: str,
        value: str,
        pointer: str,
        *,
        indent: str = "",
    ) -> str:
        return f"{indent}store {element_type} {value}, ptr {pointer}"

    def _array_element_pointer(
        self,
        array: str,
        index: SSAValue,
        element_type: object,
        *,
        check_bounds: bool = False,
    ) -> _ArrayPointer:
        data = self._synthetic_temp("array.data")
        index64 = self._synthetic_temp("array.index64")
        element_ptr = self._synthetic_temp("array.elem")
        llvm_element_type = llvm_type(element_type)
        lines = [LLVMArrayRuntime.index64_line(index64, self._operand(index))]
        if check_bounds:
            lines.append(f"call void @aether_array_check_index(ptr {array}, i64 {index64})")
        lines.extend(self._array_data_pointer(data, array))
        lines.append(
            f"{element_ptr} = getelementptr {llvm_element_type}, ptr {data}, i64 {index64}"
        )
        return self._ArrayPointer(element_ptr, lines)

    def _list_element_pointer(
        self,
        list_value: str,
        index: SSAValue,
        element_type: object,
        *,
        check_bounds: bool = True,
    ) -> _ArrayPointer:
        data = self._synthetic_temp("list.data")
        index64 = self._synthetic_temp("list.index64")
        element_ptr = self._synthetic_temp("list.elem")
        llvm_element_type = llvm_type(element_type)
        lines = [self._list_index64_line(index64, self._operand(index))]
        if check_bounds:
            lines.append(f"call void @aether_list_check_index(ptr {list_value}, i64 {index64})")
        lines.extend(self._list_data_pointer(data, list_value))
        lines.append(
            f"{element_ptr} = getelementptr {llvm_element_type}, ptr {data}, i64 {index64}"
        )
        return self._ArrayPointer(element_ptr, lines)

    def _vector_element_pointer(
        self,
        vector: str,
        index: SSAValue,
        element_type: object,
        *,
        check_bounds: bool = True,
    ) -> _ArrayPointer:
        data = self._synthetic_temp("vector.data")
        public_index64 = self._synthetic_temp("vector.index64")
        offset = self._synthetic_temp("vector.offset")
        element_ptr = self._synthetic_temp("vector.elem")
        llvm_element_type = llvm_type(element_type)
        lines = [LLVMArrayRuntime.index64_line(public_index64, self._operand(index))]
        if check_bounds:
            lines.append(
                f"{offset} = call i64 @aether_vector_check_index(ptr {vector}, i64 {public_index64})"
            )
        else:
            lines.append(f"{offset} = sub i64 {public_index64}, 1")
        lines.extend(self._array_data_pointer(data, vector))
        lines.append(
            f"{element_ptr} = getelementptr {llvm_element_type}, ptr {data}, i64 {offset}"
        )
        return self._ArrayPointer(element_ptr, lines)

    def _matrix_element_pointer(
        self,
        matrix: str,
        row: SSAValue,
        column: SSAValue,
        cols: int,
        element_type: object,
        *,
        check_bounds: bool = True,
    ) -> _ArrayPointer:
        data = self._synthetic_temp("matrix.data")
        row64 = self._synthetic_temp("matrix.row64")
        column64 = self._synthetic_temp("matrix.column64")
        linear_index = self._synthetic_temp("matrix.index")
        element_ptr = self._synthetic_temp("matrix.elem")
        llvm_element_type = llvm_type(element_type)
        lines = [f"{row64} = sext i32 {self._operand(row)} to i64"]
        lines.append(f"{column64} = sext i32 {self._operand(column)} to i64")
        if check_bounds:
            lines.append(
                f"{linear_index} = call i64 @aether_matrix_check_index("
                f"ptr {matrix}, i64 {row64}, i64 {column64}, i64 {cols})"
            )
        else:
            row_offset = self._synthetic_temp("matrix.row.offset")
            column_offset = self._synthetic_temp("matrix.column.offset")
            row_start = self._synthetic_temp("matrix.row.start")
            lines.extend([
                f"{row_offset} = sub i64 {row64}, 1",
                f"{column_offset} = sub i64 {column64}, 1",
                f"{row_start} = mul i64 {row_offset}, {cols}",
                f"{linear_index} = add i64 {row_start}, {column_offset}",
            ])
        lines.extend(self._array_data_pointer(data, matrix))
        lines.append(
            f"{element_ptr} = getelementptr {llvm_element_type}, ptr {data}, i64 {linear_index}"
        )
        return self._ArrayPointer(element_ptr, lines)

    def _array_data_pointer(self, result: str, array: str) -> list[str]:
        field_ptr = self._synthetic_temp("array.data.field")
        return [
            LLVMArrayRuntime.data_pointer_line(field_ptr, array),
            f"{result} = load ptr, ptr {field_ptr}",
        ]

    def _list_field_pointer_line(
        self,
        result: str,
        list_value: str,
        field_index: int,
    ) -> str:
        return (
            f"{result} = getelementptr {self._LIST_STRUCT_TYPE}, "
            f"ptr {list_value}, i32 0, i32 {field_index}"
        )

    def _load_list_data(
        self,
        result: str,
        list_value: str,
        field_ptr: str,
    ) -> list[str]:
        return [
            self._list_field_pointer_line(field_ptr, list_value, 2),
            f"{result} = load ptr, ptr {field_ptr}",
        ]

    def _list_data_pointer(self, result: str, list_value: str) -> list[str]:
        return self._load_list_data(
            result,
            list_value,
            self._synthetic_temp("list.data.field"),
        )

    def _array_length64(self, result: str, array: str) -> list[str]:
        field_ptr = self._synthetic_temp("array.len.field")
        return [
            LLVMArrayRuntime.length_pointer_line(field_ptr, array),
            f"{result} = load i64, ptr {field_ptr}",
        ]

    def _list_length64(self, result: str, list_value: str) -> list[str]:
        field_ptr = self._synthetic_temp("list.len.field")
        return [
            self._list_field_pointer_line(field_ptr, list_value, 0),
            f"{result} = load i64, ptr {field_ptr}",
        ]

    def _store_list_length(
        self,
        value: str,
        list_value: str,
        field_ptr: str,
    ) -> list[str]:
        return [
            self._list_field_pointer_line(field_ptr, list_value, 0),
            f"store i64 {value}, ptr {field_ptr}",
        ]

    @staticmethod
    def _list_index64_line(result: str, index: str) -> str:
        return f"{result} = sext i32 {index} to i64"

    def _sizeof(self, type_: object, *, collection: str = "collection") -> str:
        layout = self._layouts.collection_element(collection, type_)
        assert layout.size_operand is not None
        return layout.size_operand

    @staticmethod
    def _element_binary_operator(type_: object, operator: str) -> str:
        operations = {
            (IntType, "add"): "add",
            (IntType, "sub"): "sub",
            (IntType, "mul"): "mul",
            (DoubleType, "add"): "fadd",
            (DoubleType, "sub"): "fsub",
            (DoubleType, "mul"): "fmul",
        }
        if isinstance(type_, IntType):
            selected = operations.get((IntType, operator))
            if selected is not None:
                return selected
        if isinstance(type_, DoubleType):
            selected = operations.get((DoubleType, operator))
            if selected is not None:
                return selected
        raise LLVMBackendError(
            f"LLVM backend does not support vector/matrix {operator} for {type_}"
        )

    def _operand(self, value: SSAValue) -> str:
        key = self._key(value)
        if key in self._constants:
            return self._constants[key]
        if key in self._function_references:
            return self._function_references[key]
        if key in self._values:
            return self._values[key]
        return self._local_name(value.name)

    def _new_temp(self, value: SSAValue) -> str:
        existing = self._values.get(self._key(value))
        if existing is not None:
            return existing
        return self._reserve_temp(value)

    def _reserve_temp(self, value: SSAValue) -> str:
        key = self._key(value)
        existing = self._values.get(key)
        if existing is not None:
            return existing
        name = f"%{self._next_temp}"
        self._next_temp += 1
        self._values[key] = name
        return name

    def _synthetic_temp(self, prefix: str) -> str:
        name = f"%{prefix}.{self._next_synthetic_temp}"
        self._next_synthetic_temp += 1
        return name

    def _literal(self, value: Any, result: SSAValue) -> str:
        if isinstance(result.type, NullableType):
            if value is not None:
                raise LLVMBackendError(
                    "LLVM nullable constants only represent the absent state"
                )
            return "zeroinitializer"
        if isinstance(result.type, EnumType):
            if not isinstance(value, IREnumConstant):
                raise LLVMBackendError(
                    "LLVM enum constants require nominal IREnumConstant metadata"
                )
            if value.enum_name != result.type.name:
                raise LLVMBackendError("LLVM enum constant identity mismatch")
            return str(value.discriminant)
        if isinstance(result.type, IntType):
            if isinstance(value, bool) or not isinstance(value, int):
                raise LLVMBackendError(
                    "LLVM backend does not support non-int SSAConst values"
                )
            if not is_aether_int(value):
                raise LLVMBackendError(
                    f"LLVM backend refuses out-of-range i32 constant {value!r}; "
                    f"expected [{INT_MIN}, {INT_MAX}]"
                )
            return str(value)
        if isinstance(result.type, BoolType):
            if not isinstance(value, bool):
                raise LLVMBackendError(
                    "LLVM backend does not support non-bool SSAConst values"
                )
            return "1" if value else "0"
        if isinstance(result.type, (FloatType, DoubleType)):
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise LLVMBackendError(
                    "LLVM backend does not support non-double SSAConst values"
                )
            return self._double_literal(float(value))
        if isinstance(result.type, StringType):
            if not isinstance(value, str):
                raise LLVMBackendError(
                    "LLVM backend does not support non-string SSAConst values"
                )
            return self._string_global(value).name
        raise LLVMBackendError(
            f"LLVM backend does not support SSAConst of type {result.type}"
        )

    def _enum_text_selection(self, type_: EnumType, value: str) -> tuple[list[str], str]:
        invalid = self._string_global(f"<invalid {type_.display_name or type_.name}>")
        selected = invalid.name
        lines: list[str] = []
        display_name = type_.display_name or type_.name
        for discriminant, member_name in enumerate(type_.variants):
            matches = self._synthetic_temp("print.enum.match")
            updated = self._synthetic_temp("print.enum.text")
            member = self._string_global(f"{display_name}.{member_name}")
            lines.extend(
                [
                    f"{matches} = icmp eq i32 {value}, {discriminant}",
                    f"{updated} = select i1 {matches}, ptr {member.name}, ptr {selected}",
                ]
            )
            selected = updated
        return lines, selected

    def _string_global(self, value: str) -> _StringGlobal:
        existing = self._string_globals_by_value.get(value)
        if existing is not None:
            return existing

        try:
            content = value.encode("utf-8", errors="strict")
        except UnicodeEncodeError as exc:
            raise LLVMBackendError("LLVM string literal is not valid UTF-8") from exc
        self._uses_string_runtime = True
        if not content:
            global_ = _StringGlobal(
                name="@.aether.string.empty",
                byte_length=0,
                payload_size=1,
                initializer="\\00",
            )
            self._string_globals_by_value[value] = global_
            return global_
        encoded = content + b"\x00"
        global_ = _StringGlobal(
            name=f"@.aether.str.{self._next_string_global}",
            byte_length=len(content),
            payload_size=len(encoded),
            initializer=self._escape_string_initializer(encoded),
        )
        self._next_string_global += 1
        self._string_globals_by_value[value] = global_
        return global_

    def _print_witness_metadata(self) -> list[str]:
        if not self._witnesses and not self._uses_interface_dispatch:
            return []
        sections = [
            "%AetherWitnessHeader = type { ptr, ptr, i32, i32, ptr, ptr }",
            "%AetherWitnessSlot = type { i32, ptr, ptr }",
        ]
        for witness in sorted(
            self._witnesses.values(),
            key=lambda item: (
                item.interface_id,
                item.concrete_type_id,
                item.symbol,
            ),
        ):
            if witness.carrier_kind == "box":
                layout = witness.box_layout
                if layout is None:
                    raise LLVMBackendError(
                        f"Box witness '{witness.symbol}' has no erased layout"
                    )
                padding = layout.payload_offset - 16
                if padding < 0:
                    raise LLVMBackendError(
                        f"Box witness '{witness.symbol}' has an invalid payload offset"
                    )
                sections.append(
                    f"{box_type_symbol(witness.interface_id, witness.concrete_type_id)} "
                    f"= type {{ i64, i32, i32, [{padding} x i8], "
                    f"{llvm_type(StructType(witness.concrete_type_id))} }}"
                )
            identifiers = [
                (f"@{witness.symbol}.interface_id", witness.interface_id),
                (f"@{witness.symbol}.concrete_type_id", witness.concrete_type_id),
                *[
                    (f"@{witness.symbol}.method.{slot.index}.id", slot.method_id)
                    for slot in witness.method_slots
                ],
            ]
            for name, value in identifiers:
                encoded = value.encode("utf-8") + b"\0"
                sections.append(
                    f"{name} = private unnamed_addr constant "
                    f"[{len(encoded)} x i8] c\"{self._escape_string_initializer(encoded)}\""
                )
            interface_size = len(witness.interface_id.encode("utf-8")) + 1
            concrete_size = len(witness.concrete_type_id.encode("utf-8")) + 1
            header = (
                "%AetherWitnessHeader { "
                f"ptr getelementptr ([{interface_size} x i8], "
                f"ptr @{witness.symbol}.interface_id, i64 0, i64 0), "
                f"ptr getelementptr ([{concrete_size} x i8], "
                f"ptr @{witness.symbol}.concrete_type_id, i64 0, i64 0), "
                f"i32 {witness.abi_version}, "
                f"i32 {len(witness.method_slots)}, "
                f"ptr @{copy_owned_symbol(witness.interface_id, witness.concrete_type_id)}, "
                f"ptr @{drop_owned_symbol(witness.interface_id, witness.concrete_type_id)} }}"
            )
            slot_type = (
                f"[{len(witness.method_slots)} x %AetherWitnessSlot]"
            )
            if witness.method_slots:
                slot_values = []
                for slot in witness.method_slots:
                    method_size = len(slot.method_id.encode("utf-8")) + 1
                    slot_values.append(
                        "%AetherWitnessSlot { "
                        f"i32 {slot.index}, "
                        f"ptr getelementptr ([{method_size} x i8], "
                        f"ptr @{witness.symbol}.method.{slot.index}.id, "
                        f"i64 0, i64 0), ptr @{slot.thunk_symbol} }}"
                    )
                slots = f"{slot_type} [ " + ", ".join(slot_values) + " ]"
            else:
                slots = f"{slot_type} zeroinitializer"
            sections.append(
                f"@{witness.symbol} = private constant "
                f"{{ %AetherWitnessHeader, {slot_type} }} "
                f"{{ {header}, {slots} }}"
            )
            sections.extend(self._print_ownership_adapters(witness))
            for slot in witness.method_slots:
                sections.append(self._print_dispatch_thunk(witness, slot))
        return sections

    def _print_ownership_adapters(self, witness: IRWitnessTable) -> list[str]:
        copy_symbol = copy_owned_symbol(
            witness.interface_id, witness.concrete_type_id
        )
        drop_symbol = drop_owned_symbol(
            witness.interface_id, witness.concrete_type_id
        )
        if witness.carrier_kind == "class":
            class_type = ClassRefType(witness.concrete_type_id)
            self._class_types.add(class_type)
            return [
                "\n".join(
                    [
                        f"define private ptr @{copy_symbol}(ptr %carrier) {{",
                        "entry:",
                        "  call void @aether_class_retain(ptr %carrier)",
                        "  ret ptr %carrier",
                        "}",
                    ]
                ),
                "\n".join(
                    [
                        f"define private void @{drop_symbol}(ptr %carrier) {{",
                        "entry:",
                        "  call void @aether_class_release(ptr %carrier)",
                        "  ret void",
                        "}",
                    ]
                ),
            ]
        if witness.carrier_kind != "box" or witness.box_layout is None:
            raise LLVMBackendError(
                f"Unsupported ownership carrier kind '{witness.carrier_kind}'"
            )
        self._uses_interface_boxing = True
        concrete = StructType(witness.concrete_type_id)
        rendered = llvm_type(concrete)
        box_type = box_type_symbol(witness.interface_id, witness.concrete_type_id)
        layout = witness.box_layout
        box_size = (
            f"ptrtoint (ptr getelementptr ({box_type}, ptr null, i64 1) to i64)"
        )
        copy_lines: list[str] = [
            f"define private ptr @{copy_symbol}(ptr %carrier) {{",
            "entry:",
            f"  %source_payload_ptr = getelementptr {box_type}, ptr %carrier, i32 0, i32 4",
            f"  %payload = load {rendered}, ptr %source_payload_ptr",
        ]
        payload_copy: list[str] = []
        copied_payload = self._emit_arc_value(
            payload_copy, "%payload", concrete, retain=True
        )
        copy_lines.extend(f"  {line}" for line in payload_copy)
        copy_lines.extend(
            [
                f"  %box = call ptr @aether_alloc(i64 {box_size})",
                f"  %size_ptr = getelementptr {box_type}, ptr %box, i32 0, i32 0",
                f"  store i64 {layout.payload_size}, ptr %size_ptr",
                f"  %alignment_ptr = getelementptr {box_type}, ptr %box, i32 0, i32 1",
                f"  store i32 {layout.payload_alignment}, ptr %alignment_ptr",
                f"  %offset_ptr = getelementptr {box_type}, ptr %box, i32 0, i32 2",
                f"  store i32 {layout.payload_offset}, ptr %offset_ptr",
                f"  %payload_ptr = getelementptr {box_type}, ptr %box, i32 0, i32 4",
                f"  store {rendered} {copied_payload}, ptr %payload_ptr",
                "  ret ptr %box",
                "}",
            ]
        )
        destroy_lines: list[str] = []
        self._emit_arc_value(destroy_lines, "%payload", concrete, retain=False)
        drop_lines = [
            f"define private void @{drop_symbol}(ptr %carrier) {{",
            "entry:",
            f"  %payload_ptr = getelementptr {box_type}, ptr %carrier, i32 0, i32 4",
            f"  %payload = load {rendered}, ptr %payload_ptr",
            *(f"  {line}" for line in destroy_lines),
            "  call void @free(ptr %carrier)",
            "  ret void",
            "}",
        ]
        return ["\n".join(copy_lines), "\n".join(drop_lines)]

    def _print_dispatch_thunk(
        self,
        witness: IRWitnessTable,
        slot: IRWitnessMethodSlot,
    ) -> str:
        if not slot.thunk_symbol:
            raise LLVMBackendError(
                f"Interface witness slot '{slot.method_id}' has no dispatch thunk"
            )
        method_name = slot.method_id.rsplit(".", 1)[-1]
        target_name = f"{witness.concrete_type_id}.{method_name}"
        target = self._functions_by_name.get(target_name)
        concrete_receiver: object
        expected_return: object
        if witness.carrier_kind == "box":
            concrete_receiver = StructType(witness.concrete_type_id)
            expected_return = MethodResultType(concrete_receiver, slot.return_type)
        else:
            concrete_receiver = ClassRefType(witness.concrete_type_id)
            expected_return = slot.return_type
        expected_parameters = (concrete_receiver, *slot.parameter_types)
        if (
            target is None
            or tuple(parameter.type for parameter in target.parameters)
            != expected_parameters
            or target.return_type != expected_return
        ):
            raise LLVMBackendError(
                f"Interface thunk '{slot.thunk_symbol}' target signature mismatch"
            )
        parameters = [
            "ptr %carrier",
            *[
                f"{llvm_type(type_)} %arg{index}"
                for index, type_ in enumerate(slot.parameter_types)
            ],
        ]
        throwing_slot = slot.may_throw
        if target.may_throw and not throwing_slot:
            raise LLVMBackendError(
                f"LLVM interface slot '{slot.method_id}' lost may_throw metadata"
            )
        uses_event_out = (
            target.may_throw
            and self._exception_strategy is ExceptionLoweringStrategy.EVENT_OUT
        )
        if throwing_slot and self._exception_strategy is ExceptionLoweringStrategy.EVENT_OUT:
            parameters.append("ptr %__ae_exception_out")
        arguments = [
            "ptr %carrier",
            *[
                f"{llvm_type(type_)} %arg{index}"
                for index, type_ in enumerate(slot.parameter_types)
            ],
        ]
        target_arguments = list(arguments)
        if uses_event_out:
            target_arguments.append("ptr %__ae_exception_out")
        rendered_return = llvm_type(slot.return_type)
        if witness.carrier_kind == "box":
            box_type = box_type_symbol(
                witness.interface_id, witness.concrete_type_id
            )
            receiver_type = StructType(witness.concrete_type_id)
            receiver_llvm = llvm_type(receiver_type)
            result_pair = llvm_type(
                MethodResultType(receiver_type, slot.return_type)
            )
            source_arguments = [
                f"{receiver_llvm} %receiver",
                *target_arguments[1:],
            ]
            result_body = [
                f"  %payload_ptr = getelementptr {box_type}, ptr %carrier, i32 0, i32 4",
                f"  %receiver = load {receiver_llvm}, ptr %payload_ptr",
                f"  %pair = call {result_pair} {self._global_name(target_name)}"
                f"({', '.join(source_arguments)})",
            ]
            if uses_event_out:
                result_body.extend(
                    [
                        "  %event = load ptr, ptr %__ae_exception_out, align 8",
                        "  %failed = icmp ne ptr %event, null",
                        "  br i1 %failed, label %exceptional, label %normal",
                        "normal:",
                    ]
                )
            result_body.extend(
                [
                    f"  %updated = extractvalue {result_pair} %pair, 0",
                    f"  store {receiver_llvm} %updated, ptr %payload_ptr",
                ]
            )
            if isinstance(slot.return_type, VoidType):
                result_body.append("  ret void")
            else:
                result_body.extend(
                    [
                        f"  %result = extractvalue {result_pair} %pair, 1",
                        f"  ret {rendered_return} %result",
                    ]
                )
            if uses_event_out:
                result_body.extend(
                    [
                        "exceptional:",
                        f"  {self._exceptional_return(slot.return_type)}",
                    ]
                )
            body = "\n".join(result_body)
        else:
            call = (
                f"call {rendered_return} {self._global_name(target_name)}"
                f"({', '.join(target_arguments)})"
            )
            body = (
                f"  {call}\n  ret void"
                if isinstance(slot.return_type, VoidType)
                else f"  %result = {call}\n  ret {rendered_return} %result"
            )
        personality = (
            " personality ptr @__gxx_personality_v0"
            if target.may_throw
            and self._exception_strategy
            is ExceptionLoweringStrategy.LLVM_EH_PROTOTYPE
            else ""
        )
        nonthrowing_attribute = (
            " nounwind" if slot.method_id == "Error.message" else ""
        )
        return (
            f"define private {rendered_return} @{slot.thunk_symbol}"
            f"({', '.join(parameters)}){personality}{nonthrowing_attribute} "
            f"{{\nentry:\n{body}\n}}"
        )

    @staticmethod
    def _print_string_global(global_: _StringGlobal) -> str:
        if global_.name == "@.aether.string.empty":
            return ""
        return (
            f"{global_.name} = private constant "
            f"{{ i64, i64, i32, i32, [{global_.payload_size} x i8] }} "
            f"{{ i64 {global_.byte_length}, i64 0, i32 3, i32 0, "
            f"[{global_.payload_size} x i8] c\"{global_.initializer}\" }}, align 8"
        )

    @staticmethod
    def _escape_string_initializer(value: bytes) -> str:
        chunks: list[str] = []
        for byte in value:
            if byte in {0x22, 0x5C} or byte < 0x20 or byte > 0x7E:
                chunks.append(f"\\{byte:02X}")
            else:
                chunks.append(chr(byte))
        return "".join(chunks)

    @staticmethod
    def _double_literal(value: float) -> str:
        if value != value or value in {float("inf"), float("-inf")}:
            bits = struct.unpack(">Q", struct.pack(">d", value))[0]
            return f"0x{bits:016X}"
        literal = repr(value)
        if "e" in literal or "E" in literal:
            return format(value, ".17e")
        if "." not in literal:
            return f"{literal}.0"
        return literal

    @classmethod
    def _parameter_name(cls, parameter: SSAParameter) -> str:
        raw = cls._strip_percent(parameter.name)
        if raw.isdigit():
            return f"%arg{raw}"
        return cls._local_name(raw)

    @classmethod
    def _local_name(cls, name: str) -> str:
        raw = cls._strip_percent(name)
        if not raw:
            raise LLVMBackendError("LLVM backend does not support empty SSA value names")
        if cls._IDENTIFIER_RE.match(raw) or raw.isdigit():
            return f"%{raw}"
        raise LLVMBackendError(f"LLVM backend does not support SSA value name '{name}'")

    @classmethod
    def _label_operand(cls, name: str) -> str:
        raw = cls._strip_percent(name)
        if not raw:
            raise LLVMBackendError("LLVM backend does not support empty block labels")
        if cls._IDENTIFIER_RE.match(raw) or raw.isdigit():
            return f"label %{raw}"
        raise LLVMBackendError(f"LLVM backend does not support block label '{name}'")

    @classmethod
    def _label_definition(cls, name: str) -> str:
        raw = cls._strip_percent(name)
        if not raw:
            raise LLVMBackendError("LLVM backend does not support empty block labels")
        if cls._IDENTIFIER_RE.match(raw) or raw.isdigit():
            return f"{raw}:"
        raise LLVMBackendError(f"LLVM backend does not support block label '{name}'")

    @classmethod
    def _label_name(cls, name: str) -> str:
        raw = cls._strip_percent(name)
        if not raw:
            raise LLVMBackendError("LLVM backend does not support empty block labels")
        if cls._IDENTIFIER_RE.match(raw) or raw.isdigit():
            return raw
        raise LLVMBackendError(f"LLVM backend does not support block label '{name}'")

    def _global_name(self, name: str) -> str:
        raw = name[1:] if name.startswith("@") else name
        if not raw:
            raise LLVMBackendError("LLVM backend does not support empty function names")
        if self._native_entry and raw == "main":
            return f"@{self._entry_symbol}"
        return f"@{raw}"

    @staticmethod
    def _strip_percent(name: str) -> str:
        return name[1:] if name.startswith("%") else name

    @staticmethod
    def _key(value: SSAValue) -> str:
        return value.name[1:] if value.name.startswith("%") else value.name

    @staticmethod
    def _unsupported(feature: str) -> None:
        raise LLVMBackendError(f"LLVM backend does not support {feature}")


def print_llvm(module: SSAModule) -> str:
    return LLVMPrinter().print_module(module)
